import axios from 'axios';
import API_DOMAIN from '../constants';

export const getAuctionDetails = async (auctionId) => {
    try {
        const response = await axios.get(`${API_DOMAIN}/get/auction/details?auction_id=${auctionId}`);
        return response;
    } catch (error) {
        return error;
    }
};

export const placeBid = async (auctionId, userId, bid_amount) => {
    try {
        const data = {
            "auction_id": auctionId,
            "user_id": userId,
            "price": { "currency": "RUPEES", "value": Number(bid_amount) }
        }
        const response = await axios.post(`${API_DOMAIN}/place/bid`, data);
        return response;
    } catch (error) {
        return error;
    }
};

export const getBidDetails = async (auctionId, userId) => {
    try {
        const response = await axios.get(`${API_DOMAIN}/get/bid/details?auction_id=${auctionId}&user_id=${userId}`);
        return response;
    } catch (error) {
        return error;
    }
};

export const getBidList = async (auctionId, skip, limit) => {
    try {
        const response = await axios.get(`${API_DOMAIN}/get/all/bids?auction_id=${auctionId}&skip=${skip}&limit=${limit}`);
        return response;
    } catch (error) {
        return error;
    }
};

export const checkIfBiddingAllowed = async (auctionId, userId) => {
    try {
        const response = await axios.get(`${API_DOMAIN}/check/bidding/allowed?auction_id=${auctionId}&user_id=${userId}`);
        return response;
    } catch (error) {
        return error;
    }
}

export const getAuctionStatus = async (auctionId) => {
    try {
        const response = await axios.get(`${API_DOMAIN}/get/auction/status?auction_id=${auctionId}`);
        return response;
    } catch (error) {
        return error;
    }
}

export const getAuctionWinner = async (auctionId) => {
    try {
        const response = await axios.get(`${API_DOMAIN}/get/auction/winner?auction_id=${auctionId}`);
        return response;
    } catch (error) {
        return error;
    }
}

export const getUserAuctionResult = async (auctionId, userId) => {
    try {
        const response = await axios.get(`${API_DOMAIN}/get/user/auction/result?auction_id=${auctionId}&user_id=${userId}`);
        return response;
    } catch (error) {
        return error;
    }
}

export const editAuctionConfig = async (payload) => {
    try {
        const response = await axios.post(`${API_DOMAIN}/edit/auction`, payload);
        return response;
    } catch (error) {
        return error;
    }
} 

export const getAuctionSummary = async (auctionId, sellerId) => {
    try {
        const response = await axios.get(`${API_DOMAIN}/get/auction/summary?auction_id=${auctionId}&seller_id=${sellerId}`);
        return response;
    } catch (error) {
        return error;
    }
} 
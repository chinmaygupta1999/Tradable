import axios from 'axios';
import API_DOMAIN from '../constants';

export const getAccountDetails = async (userId) => {
    try {
        const response = await axios.get(`${API_DOMAIN}/get/account/details?user_id=${userId}`);
        return response;
    } catch (error) {
        return error;
    }
};

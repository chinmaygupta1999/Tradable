import axios from 'axios';
import API_DOMAIN from '../constants';

export const updateAuctionWinnerForm = async (data) => {
    try {
        const response = await axios.post(`${API_DOMAIN}/auction/winner/form/update`, data);
        return response;
    } catch (error) {
        return error;
    }
};

export const getAuctionWinnerFormDetails = async (userId, auctionId) => {
    try {
        const response = await axios.get(`${API_DOMAIN}/get/auction/winner/form/details?user_id=${userId}&auction_id=${auctionId}`);
        return response;
    } catch (error) {
        return error;
    }
};
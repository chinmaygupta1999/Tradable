import axios from 'axios';
import API_DOMAIN from '../constants';

export const viewWishlist = async (userId) => {
    try {
      const response = await axios.get(`${API_DOMAIN}/get/wishlist?user_id=${userId}`);
      return response;
    } catch (error) {
      console.error('Error:', error);
    }
};

export const modifyWishlist = async (userId, propertyId, deleted=false) => {
    try {
      const response = await axios.post(`${API_DOMAIN}/modify/wishlist`, {"user_id": userId, "property_id": propertyId, "deleted": deleted});
      return response;
    } catch (error) {
      console.error('Error:', error);
    }
};
import axios from 'axios';
import API_DOMAIN from '../constants';

export const requestOtp = async (phoneNumber) => {
    try {
    const data = new FormData();
    data.append('phone_number', phoneNumber);
      const response = await axios.post(`${API_DOMAIN}/request/otp`, data);
      return response;
    } catch (error) {
      console.error('Error:', error);
    }
  };

  export const verifyOTP = async (phoneNumber, otp) => {
    try {
    const data = new FormData();
    data.append('phone_number', phoneNumber);
    data.append('otp', otp);
    const response = await axios.post(`${API_DOMAIN}/verify/otp`, data);
    return response;
    } catch (error) {
      return error;
    }
  };
  export const signupUser = async (phoneNumber, userName) => {
    try {
    const data = new FormData();
    data.append('phone_number', phoneNumber);
    data.append('user_name', userName);
    const response = await axios.post(`${API_DOMAIN}/signup`, data,);
    return response;
    } catch (error) {
      return error;
    }
  };
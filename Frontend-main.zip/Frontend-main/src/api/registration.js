import axios from 'axios';
import API_DOMAIN from '../constants';

export const registerInAuction = async (data) => {
    try {
        const response = await axios.post(`${API_DOMAIN}/register`, data);
        return response;
    } catch (error) {
        console.error('Error:', error);
    }
};

export const getRegistrationDetails = async (userId, auctionId) => {
    try {
        const response = await axios.get(`${API_DOMAIN}/get/registration/details?user_id=${userId}&auction_id=${auctionId}`);
        return response;
    } catch (error) {
        console.error('Error:', error);
    }
};

export const getAllRegistrationDetails = async (userId, auctionId) => {
    try {
        const response = await axios.get(`${API_DOMAIN}/get/all/registration/details?user_id=${userId}&auction_id=${auctionId}`);
        return response;
    } catch (error) {
        console.error('Error:', error);
    }
};

export const changeApprovalStatus = async (userId, auctionId, approvalStatus, sellerId) => {
    try {
        const response = await axios.get(`${API_DOMAIN}/change/approval/status?user_id=${userId}&auction_id=${auctionId}&approval_status=${approvalStatus}&seller_id=${sellerId}`);
        return response;
    } catch (error) {
        console.log("Error: ", error);
    }
};
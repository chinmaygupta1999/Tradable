// axiosInstance.js
import axios from 'axios';

const axiosInstance = axios.create();

// Add a request interceptor to include the JWT token in every request
axiosInstance.interceptors.request.use(
    (config) => {
        const jwtToken = localStorage.getItem('jwtToken');

        if (jwtToken) {
            config.headers.Authorization = `Bearer ${jwtToken}`;
        }
        return config;
    },
    (error) => {
        return Promise.reject(error);
    }
);

// Add a response interceptor to handle token expiration
axiosInstance.interceptors.response.use(
    (response) => {
        return response;
    },
    (error) => {
        // Check if the error is due to an expired token
        if (error.response && error.response.status === 401) {
            // Token expired, redirect to the login page
            window.location.href = '/login';
        }

        return Promise.reject(error);
    }
);

export default axiosInstance;

import axios from 'axios';
import API_DOMAIN from '../constants';

export const getUploadSignedUrl = async (filePath) => {
    try {
        const response = await axios.get(`${API_DOMAIN}/get/upload/url?file_path=${filePath}`);
        return response;
    } catch (error) {
        return error;
    }
};

import axios from 'axios';
import axiosInstance from './axios-instance';
import API_DOMAIN from '../constants';

export const getMapProperties = async (north, south, east, west, userId) => {
    try {
        const response = await axiosInstance.get(`${API_DOMAIN}/get/map/property?north=${north}&south=${south}&east=${east}&west=${west}&user_id=${userId}`);
        return response;
    } catch (error) {
        return error;
    }
};

export const getPropertyDetails = async (propertyId) => {
    try {
        const response = await axiosInstance.get(`${API_DOMAIN}/get/property?property_id=${propertyId}`);
        return response;
    } catch (error) {
        return error;
    }
};

export const getUserPropertyList = async (userId) => {
    try {
        const response = await axiosInstance.get(`${API_DOMAIN}/get/user/property/list?user_id=${userId}`);
        return response;
    } catch (error) {
        return error;
    }
};
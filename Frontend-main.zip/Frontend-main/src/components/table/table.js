import { useEffect, useState } from 'react';
import photoIcon from '../../images/photo-icon.svg';
import leftArrowIcon from '../../images/left-arrow-icon.svg';
import rightArrowIcon from '../../images/right-arrow-icon.svg';
import NoBid from '../no-bid/no-bid';
import dropDownIcon from '../../images/dropdown-icon.svg';
import viewDetailsIcon from '../../images/view-details-icon.svg';
import './table.css';
import { getAllRegistrationDetails } from '../../api/registration';
import { formatCurrencyIndianSystem } from '../../utils/property';
import RegistrationFormViewer from '../registration-form/registration-form-viewer';
import { useSelector } from 'react-redux';
import Modal from 'react-modal';

const Table = (props) => {
    const [bidTableHeading, setBidTableHeading] = useState([]);
    const [bidderTableHeading, setBidderTableHeading] = useState(['Bidder Details', 'Pre Auction Offer', 'Approval Status', 'Take Action']);
    const [bidTableData, setBidTableData] = useState([]);
    const [bidderTableData, setBidderTableData] = useState([]);
    const [hideBidsTable, setHideBidsTable] = useState(!props?.isUserOwner);
    const [hideBidderTable, setHideBidderTable] = useState(true);
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [registrationDetails, setRegistrationDetails] = useState();
    const user = useSelector(state => state.user);


    const getDateString = (timestamp) => {
        const date = new Date(timestamp);
        const year = date.getFullYear();
        const month = String(date.getMonth() + 1).padStart(2, '0');
        const day = String(date.getDate()).padStart(2, '0');
        let hours = String(date.getHours()).padStart(2, '0');
        const minutes = String(date.getMinutes()).padStart(2, '0');
        const seconds = String(date.getSeconds()).padStart(2, '0');

        // Determine AM/PM
        const ampm = hours >= 12 ? 'PM' : 'AM';

        // Convert hours to 12-hour format
        hours = hours % 12 || 12;

        const formattedDateTimeString = `${hours}:${minutes} ${ampm}, ${day}/${month}/${year}`;
        return formattedDateTimeString;
    };

    const changePage = (n) => {
        props?.fetchTableData(n);
    };

    const openModal = (registrationDetails) => {
        setIsModalOpen(true);
        document.body.style.overflow = 'hidden';
        setRegistrationDetails(registrationDetails);
    };

    const closeModal = () => {
        setIsModalOpen(false);
        document.body.style.overflow = 'auto';
    };

    const RegistrationStatusMapping = {
        "APPROVED": { "text": "Approved", "bgColor": "#1CC900" },
        "REJECTED": { "text": "Rejected", "bgColor": "#CE5757" },
        "APPROVAL_PENDING": { "text": "Pending", "bgColor": "#FA8C16" },
    };

    useEffect(() => {
        setBidTableHeading(props?.isUserOwner ? props?.bidTableHeading : props?.bidTableHeading.filter((heading)=>heading!="Bidder Details"));
        let updatedTableData = props?.bidTableData?.map((bid, index) => {
            if (index === props?.bidTableData.length - 1) {
                // For the first bid, there's no previous bid to compare
                return { "user_name": bid?.user_name, "user_phone_no": bid?.user_phone_no, "bid_increment": "₹ 0", "bid_amount": "₹ " + formatCurrencyIndianSystem(bid?.price?.value), "bid_time": getDateString(bid?.c * 1000) };
            }

            const previousBid = props?.bidTableData[index + 1];
            const difference = "₹ " + formatCurrencyIndianSystem(bid?.price?.value - previousBid?.price?.value); // Note the reversed order

            return { "user_name": bid?.user_name, "user_phone_no": bid?.user_phone_no, "bid_increment": difference, "bid_amount": "₹ " + formatCurrencyIndianSystem(bid?.price?.value), "bid_time": getDateString(bid?.c * 1000) };
        });
        setBidTableData(updatedTableData?.slice(0, Math.min(updatedTableData?.length, 10)));

        const fetchData = async () => {
            if (props?.isUserOwner) {
                const auctionRegistrationData = await getAllRegistrationDetails(user._id, props?.auctionData?._id);
                const registrationDataList = auctionRegistrationData?.data?.map((registrationData, index) => {
                    return {
                        "bidderDetails": { "name": registrationData?.user_name, "imgUrl": registrationData?.img_url, "phoneNumber": registrationData?.phone_no },
                        "preAuctionOffer": registrationData?.price?.value,
                        "approvalStatus": registrationData?.registration_status,
                        ...registrationData
                    }
                });
                setBidderTableData(registrationDataList);
            }
        };
        fetchData();
    }, [props?.bidTableData, isModalOpen]);

    return (
        <div>
            <div className="table-container" style={{ marginBottom: "20px" }}>
                <div className='table-heading' style={{ display: "flex", justifyContent: "space-between", alignItems: "center", cursor: "pointer" }} onClick={() => setHideBidsTable(!hideBidsTable)}>
                    <div>Bid History</div>
                    <div>
                        <img src={dropDownIcon} style={hideBidsTable ? {} : { transform: "scaleY(-1)" }} />
                    </div>
                </div>
                <div style={hideBidsTable ? {} : { display: "none" }}>
                    <div className='table-header-container'>
                        {bidTableHeading.map((heading) => <div className='table-header'>{heading}</div>)}
                    </div>
                    {bidTableData.length > 0 && <div>
                        {bidTableData.map((data) => <div className='table-content-container'>
                            {props?.isUserOwner&&<div className='table-content-1'>
                                <div style={{ fontWeight: "600" }}>
                                    {data?.user_name}
                                </div>
                                <div>
                                    {data?.user_phone_no}
                                </div>
                            </div>}
                            <div className='table-content-1'>
                                {data?.bid_amount}
                            </div>
                            <div className='table-content-2'>
                                {data?.bid_increment}
                            </div>
                            <div className='table-content-2'>
                                {data?.bid_time}
                            </div>
                        </div>)}
                    </div>}
                    {bidTableData.length != 0 && <div className='table-navigation'>
                        <div className='table-navigation-btn' onClick={() => changePage(props?.currentPage - 1)}
                            style={props?.currentPage == 1 ? { 'visibility': 'hidden' } : {}}>
                            <img src={rightArrowIcon} />
                            Previous
                        </div>
                        <div className='index-info'>
                            Page {props?.currentPage} of {props?.totalPage}
                        </div>
                        <div className='table-navigation-btn' onClick={() => changePage(props?.currentPage + 1)}
                            style={props?.currentPage == props?.totalPage ? { 'visibility': 'hidden' } : {}}>
                            Next
                            <img src={leftArrowIcon} />
                        </div>
                    </div>}
                    {
                        bidTableData.length == 0 && <NoBid />
                    }
                </div>
            </div>
            {props?.isUserOwner && <div className="table-container">
                <div className='table-heading' style={{ display: "flex", justifyContent: "space-between", alignItems: "center", cursor: "pointer" }} onClick={() => setHideBidderTable(!hideBidderTable)}>
                    <div>Bidder List</div>
                    <div>
                        <img src={dropDownIcon} style={hideBidderTable ? {} : { transform: "scaleY(-1)" }} />
                    </div>
                </div>
                <div style={hideBidderTable ? {} : { display: "none" }}>
                    <div className='table-header-container'>
                        {bidderTableHeading.map((heading) => <div className='table-header'>{heading}</div>)}
                    </div>
                    {bidderTableData.length > 0 && <div>
                        {bidderTableData.map((data) => <div className='table-content-container'>
                            <div className='table-content-1'>
                                <div style={{ fontWeight: "600" }}>
                                    {data?.bidderDetails?.name}
                                </div>
                                <div>
                                    {data?.bidderDetails?.phoneNumber}
                                </div>
                            </div>
                            <div className='table-content-2'>
                                ₹ {formatCurrencyIndianSystem(data?.preAuctionOffer)}
                            </div>
                            <div className='table-content-2'>
                                <div className='auction-status-tag' style={{ background: RegistrationStatusMapping[data?.approvalStatus].bgColor }}>
                                    {RegistrationStatusMapping[data?.approvalStatus].text}
                                </div>
                            </div>
                            <div className='table-content-2' style={{ display: "flex", alignItems: "center", cursor: "pointer", width: "fit-content" }} onClick={() => openModal(data)}>
                                <img src={viewDetailsIcon} style={{ marginRight: "5px" }} />
                                <span className='view-registration-details'>View Details</span>
                            </div>
                        </div>)}
                    </div>}
                    {
                        bidderTableData.length == 0 && <NoBid />
                    }
                </div>
                {
                    isModalOpen && <Modal
                        isOpen={isModalOpen}
                        className="modal"
                        overlayClassName="overlay"
                    >
                        <RegistrationFormViewer auctionId={props?.auctionData?._id} closeModal={closeModal} registrationDetails={registrationDetails} auctionStatus={props?.auctionStatus} />
                    </Modal>
                }
            </div>}
        </div>

    );
};
export default Table;
import React, { forwardRef, useState, useEffect } from 'react';
import { Document, Page, pdfjs } from 'react-pdf';
import SectionHeading from "../section-heading/section-heading";
import "./documents.css";
import CarouselComponent from "../carousel/carousel";
import pdf from '../../pdf/demo.pdf';

const DocumentsCard = (props) => {
    pdfjs.GlobalWorkerOptions.workerSrc = `//cdnjs.cloudflare.com/ajax/libs/pdf.js/${pdfjs.version}/pdf.worker.js`;
    const openPdf = (pdf) => {
        window?.open(pdf)
    }
    return (<div className="documents-card" onClick={() => { openPdf(props.pdfUrl) }}>
        <div className="document-thumbnail">
            <Document
                file={props.pdfUrl}
                width={20}
            >
                <Page pageNumber={1} />
            </Document>
        </div>
        <div className='document-title'>
            {props.title}
        </div>
    </div>)
}

const Documents = forwardRef((props, ref) => {
    const [documentList, setDocumentList] = useState([]); 
    useEffect(()=>{
        setDocumentList(Object.keys(props?.propertyData?.related_document_urls).map(key => ([
            key, props?.propertyData?.related_document_urls[key]
        ])));
        }, []);
    const corouselList = documentList.map((related_document) => {return <DocumentsCard title={related_document[0]} pdfUrl={related_document[1]}/>})
    return (<div ref={ref}>
        <SectionHeading heading="Documents" />
        <CarouselComponent items={corouselList} />
    </div>)
});
export default Documents;
import { useEffect, useState } from 'react';
import PropertyCard from '../property-card/property-card.js';
import {getUserPropertyList} from '../../api/property.js';
import './user-listing.css';
import { useSelector } from 'react-redux';
const UserListing = () => {
    const [propertyList, setPropertyList] = useState([]);
    const user = useSelector(state=>state.user);
    useEffect(() => {
        const fetchDetails = async () => {
            let resp = await getUserPropertyList(user?._id);
            setPropertyList(resp?.data)
        };
        fetchDetails();
    }, []);
    return (
        <div className='user-listing-section'>
           { propertyList.map((property)=>{
                return  <PropertyCard property={property} hideWishlistIcon={true}/>
            })}
        </div>
    )
};
export default UserListing;
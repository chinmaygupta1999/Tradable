import {forwardRef} from 'react';
import SectionHeading from '../section-heading/section-heading';
import './seller-info.css';

const SellerInfo = forwardRef((props, ref) => {
return (
    <div ref={ref}>
        <SectionHeading heading="Bank Details" />
        <div className='seller-info-container' style={{marginTop: "10px"}}>
            <div className='seller-info-heading'>
                State Bank Of India - Noida
            </div>
            <div className='seller-info-contact-heading'>
                Contact Details
            </div>
            <div className='seller-info-description'>
                <div>
                Seller’s Name : <span>{props?.auctionData?.config?.seller_name}</span>
                </div>
                <div>
                Mobile No: <span>{props?.auctionData?.config?.seller_mobile_no}</span>
                </div>
                <div>
                Email Id: <span>{props?.auctionData?.config?.seller_email}</span>
                </div>
            </div>
        </div>
    </div>
)
});
export default SellerInfo;
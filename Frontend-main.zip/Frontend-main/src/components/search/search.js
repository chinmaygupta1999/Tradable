import React, { useState, useEffect } from 'react';
import { GoogleMap, OverlayView, OverlayViewF } from '@react-google-maps/api';
import { getMapProperties } from '../../api/property';
import PropertyCard from '../property-card/property-card.js';
import './search.css';
import { useSelector } from 'react-redux';

const Search = ({ place }) => {
  const [properties, setProperties] = useState([]);
  const [selectedProperty, setSelectedProperty] = useState(null);
  const [map, setMap] = useState(null);
  const [mapCenter, setMapCenter] = useState({ lat: place?.geometry?.location?.lat(), lng: place?.geometry?.location?.lng() });
  const user = useSelector(state=>state.user);

  const setViewPort = () => {
    if (place?.geometry && place?.geometry?.viewport) {
      const bounds = new window.google.maps.LatLngBounds(
        new window.google.maps.LatLng(place.geometry.viewport.getSouthWest().lat(), place.geometry.viewport.getSouthWest().lng()),
        new window.google.maps.LatLng(place.geometry.viewport.getNorthEast().lat(), place.geometry.viewport.getNorthEast().lng())
      );
      if (map) {
        map.fitBounds(bounds);
      }
    }
  };

  useEffect(() => {
    setViewPort();
  }, [place, map]);

  const mapContainerStyle = {
    // width: '100%',
    height: '100vh',
  };
  const getPixelPositionOffset = (width, height) => ({
    x: -(width / 1),
    y: -(height / 1),
  });
  const onLoad = (map) => {
    setMap(map);
  };
  const onZoomChanged = () => {
    if (map) {
      handleBoundsChanged();
    }
  };
  const handleBoundsChanged = async () => {
    if (map) {
      const bounds = map.getBounds();
      const ne = bounds.getNorthEast();
      const sw = bounds.getSouthWest();
      const north = ne.lat();
      const south = sw.lat();
      const east = ne.lng();
      const west = sw.lng();
      setMap(map);
      setMapCenter({ lat: map.getCenter().lat(), lng: map.getCenter().lng() });
      let resp = await getMapProperties(north, south, east, west, user?._id||null)
      setProperties(resp?.data.map((property) => { return { ...property, wishlisted: property?.wishlisted, latitude: property?.location[0], longitude: property?.location[1] } }));
    }
  };

  return (
    <div className='search-result'>
      <div className='map-result'>
        <GoogleMap
          center={{
            lat: mapCenter?.lat,
            lng: mapCenter?.lng
          }}
          zoom={8}
          mapContainerStyle={mapContainerStyle}
          onLoad={onLoad}
          onZoomChanged={onZoomChanged}
          onChange={handleBoundsChanged}
          onDragEnd={handleBoundsChanged}
        >
          {properties.map((property) => (
            <div onClick={() => setSelectedProperty(property)}>
              <OverlayViewF
                position={{ lat: property.latitude, lng: property.longitude }}
                mapPaneName={OverlayView.OVERLAY_MOUSE_TARGET}
                getPixelPositionOffset={getPixelPositionOffset}
              >
                <div className="price-tag">
                  {property.price?.value}
                </div>
              </OverlayViewF>
            </div>
          ))}

          {selectedProperty && (
            <OverlayViewF
              position={{ lat: selectedProperty.latitude, lng: selectedProperty.longitude }}
              mapPaneName={OverlayView.OVERLAY_MOUSE_TARGET}
              getPixelPositionOffset={getPixelPositionOffset}
            >
              <div style={{ display: 'relative', background: 'white', padding: '10px', border: '1px solid #ccc', borderRadius: '5px', width: '200px' }}>
                <button
                  onClick={() => setSelectedProperty(null)}
                  style={{
                    background: 'none',
                    border: 'none',
                    color: 'red',
                    cursor: 'pointer',
                    fontSize: '16px',
                    position: 'absolute',
                    top: '0px',
                    left: '200px',
                  }}
                >
                  &times;
                </button>

                <h2 style={{ marginBottom: '5px' }}>{selectedProperty.title}</h2>
                <img
                  src={selectedProperty.image}
                  alt={selectedProperty.title}
                  style={{ width: '100%', height: 'auto', marginBottom: '10px' }}
                />
                <p style={{ fontSize: '14px', marginBottom: '5px' }}>{selectedProperty.description}</p>
                <span style={{ fontSize: '12px', color: 'gray' }}>Price: ${selectedProperty?.price?.value}</span>
              </div>
            </OverlayViewF>
          )}
        </GoogleMap>
      </div>
      <div className='card-result'>

        <div className='card-result-heading'>
        Properties for sale in {place?.address_components[0]?.long_name}
        </div>
        {properties.length?<div className='card-result-grid'>
          {properties.map((property) => (
            <PropertyCard property={property} />
          ))}
        </div>:<div style={{color: "red"}}>
          * No properties listing in the selected location, try searching some other location
        </div>}
      </div>
    </div>
  );
};

export default Search;

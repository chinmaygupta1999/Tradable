import SectionHeading from "../section-heading/section-heading";
import { GoogleMap, MarkerF, PolygonF } from '@react-google-maps/api';
import "./location";
import { useEffect, useState, forwardRef } from "react";


const Location = forwardRef((props, ref) => {
    const containerStyle = {
        width: '100%',
        height: '400px',
        marginTop: '10px'
    };
    const [center, setCenter] = useState(null);
    const [propertyBorderPath, setPropertyBorderPath] = useState([]);
    useEffect(() => {
        setCenter({ lat: props?.center[0], lng: props?.center[1] });
          setPropertyBorderPath(props?.property_outline.map((outline)=>{return {"lat": outline[0], "lng": outline[1]}}))       
    }, [])
    return (
        <div ref={ref}>
            <SectionHeading heading="Location" />
                <GoogleMap
                    mapContainerStyle={containerStyle}
                    center={center}
                    zoom={18}
                >
                    <MarkerF position={center} />
                    <PolygonF
                        path={propertyBorderPath}
                        options={{
                            fillColor: 'rgba(255, 0, 0, 0.3)', // Fill color inside the border
                            strokeColor: 'red', // Border color
                            strokeOpacity: 1, // Border opacity (0 to 1)
                            strokeWeight: 2, // Border thickness
                        }}
                    />
                </GoogleMap>
        </div>)
});

export default Location;

// import React from 'react';
// 
// 



// const MapComponent = () => {
//   return (
//    
//   );
// };

// export default MapComponent;
import React, { useState, useEffect } from 'react';
import './toast-message.css'; // Import the CSS file for styling

const ToastMessage = ({ message, type, setToastVisible}) => {
  const [visible, setVisible] = useState(true);

  useEffect(() => {
    const timer = setTimeout(() => {
      setVisible(false);
      setToastVisible(false);
    }, 5000); // Toast will disappear after 5 seconds

    return () => clearTimeout(timer);
  }, []);

  const handleClose = () => {
    setVisible(false);
    setToastVisible(false);
  };

  return (
    <div className={`toast ${type} ${visible ? 'show' : ''}`}>
    <span>{message}</span>
      <button onClick={handleClose}>&times;</button>
    </div>
  );
};

export default ToastMessage;
// src/components/Carousel.js
import React, { useState, useRef, useEffect } from 'react';
import rightArrowIcon from '../../images/right-icon.svg';
import leftArrowIcon from '../../images/left-icon.svg'
import './carousel.css';

const Carousel = ({ items }) => {
    const scrollContainerRef = useRef(null);
    const [showLeftBtn, setShowLeftBtn] = useState(false);
    const [showRightBtn, setShowRightBtn] = useState(false);

    const isRightScrollPossible = () => {
        const scrollContainer = scrollContainerRef.current;
        if (scrollContainer) {
          return scrollContainer.scrollLeft < scrollContainer.scrollWidth - scrollContainer.clientWidth;
        }
        return false;
      };

    const isLeftScrollPossible = () => {
        const scrollContainer = scrollContainerRef.current;
        if (scrollContainer) {
          return scrollContainer.scrollLeft > 0;
        }
        return false;
      };

    useEffect(()=>{
        setShowRightBtn(isRightScrollPossible());
        setShowLeftBtn(isLeftScrollPossible());
    });

    const nextSlide = () => {
        const scrollContainer = scrollContainerRef.current;
        if (scrollContainer) {
            scrollContainer.scrollTo({
              left: scrollContainer.scrollLeft + 100, // Adjust the scroll distance as needed
              behavior: 'smooth',
            });
          }
    };

    const prevSlide = () => {
        const scrollContainer = scrollContainerRef.current;
        if (scrollContainer) {
            scrollContainer.scrollTo({
                left: scrollContainer.scrollLeft - 100, // Adjust the scroll distance as needed
                behavior: 'smooth',
            });
        }
    };
    const handleScroll = () => {
        setShowRightBtn(isRightScrollPossible());
        setShowLeftBtn(isLeftScrollPossible());
    }

    return (
        <div className="carousel-container">
            <div className="carousel-wrapper" ref={scrollContainerRef} onScroll={handleScroll}>
                {items.map((item, index) => (
                    <div key={index} className="carousel-item">
                        {item}
                    </div>
                ))}
            </div>
            {showLeftBtn&&<div className='prev-btn' onClick={prevSlide}>
                <img src={leftArrowIcon}/></div>}
            {showRightBtn&&<img className='nxt-btn' onClick={nextSlide} src={rightArrowIcon}/>}
        </div>
    );
};

export default Carousel;

import './heading.css';
import { useEffect, useState } from 'react';
import save from '../../images/save.svg'
import share from '../../images/share.svg';
import calendar from '../../images/calendar.svg';
import orangeCalendar from '../../images/calendar-orange-icon.svg';
import locationLogo from '../../images/location-icon.svg';
import RejectionIcon from '../../images/rejection-icon.svg';
import Modal from 'react-modal';
import RegistrationForm from '../registration-form/registration-form';
import { useDispatch, useSelector } from 'react-redux';
import { useNavigate } from 'react-router-dom';
import { clearLoginRedirectUrl, setLoginRedirectUrl } from '../../store/action';
import PlaceBidModal from '../place-bid-modal/place-bid-modal';
import { checkIfBiddingAllowed, getAuctionWinner } from '../../api/auction';
import { modifyWishlist } from "../../api/wishlist";

const getCtaBtnConfig = (registrationDetails, isAuctionEnded, auctionWinner, user) => {
    if (!isAuctionEnded) {
        let text = registrationDetails?.registration_status == "APPROVAL_PENDING" ? "Approval Pending" : registrationDetails?.registration_status == "REJECTED" ? "Approval Rejected" : registrationDetails?.registration_status == "APPROVED" ? "Approved" : "Register to Bid";
        let icon = registrationDetails?.registration_status == "REJECTED" ? RejectionIcon : calendar;
        let statusToBgColorMapping = {
            'REJECTED': 'linear-gradient(90deg, #E7493D 0%, #D63124 202.92%)',
            'APPROVED': 'linear-gradient(90deg, #BCDF58 0%, #A09900 100%)',
            'APPROVAL_PENDING': 'linear-gradient(90deg, #BCDF58 0%, #A09900 100%)'
        };
        return {
            "text": text,
            "icon": icon,
            "bgColor": statusToBgColorMapping[registrationDetails?.registration_status] || 'linear-gradient(90deg, #FA8C16 0%, #D46B08 100%)'
        };
    }
    else {
        let text = auctionWinner?.user_id == user?._id ? "You Won" : "You Lost";
        let icon = auctionWinner?.user_id == user?._id ? calendar : RejectionIcon;
        let statusToBgColorMapping = {
            'You Won': 'linear-gradient(90deg, #32E244 0%, #0B7549 202.92%)',
            'You Lost': 'linear-gradient(90deg, #E7493D 0%, #D63124 202.92%)',
        };
        return {
            "text": text,
            "icon": icon,
            "bgColor": statusToBgColorMapping[text]
        };
    }
}

const Heading = (props) => {
    const [isModalOpen, setIsModalOpen] = useState(useSelector(state => state.open_registration_modal) == 1);
    const navigate = useNavigate();
    const [ctaText, setCtaText] = useState('Register to Bid');
    const user = useSelector(state => state.user);
    const dispatch = useDispatch();
    const [isBiddingModalOpen, setIsBiddingModalOpen] = useState(false);
    const [isBiddingAllowed, setIsBiddingAllowed] = useState(false);
    const [auctionWinner, setAuctionWinner] = useState();
    const [isWishlisted, setIsWishlisted] = useState(false);
    const [showCtaBtn, setShowCtaBtn] = useState(false);
    const openModal = (ctaText) => {
        if (ctaText == "Approval Pending" || ctaText == "Approval Rejected" || ctaText == "Approved") {
            return;
        }
        if (!user) {
            dispatch(setLoginRedirectUrl(`/property/${props?.propertyId}`));
            navigate("/login");
        }
        else {
            setIsModalOpen(true);
            document.body.style.overflow = 'hidden';
        }
    };
    const closeModal = () => {
        setIsModalOpen(false);
        document.body.style.overflow = 'auto';
    };
    const saveToWishList = async () => {
        if (!user) {
            dispatch(setLoginRedirectUrl(`/property/${props?.propertyId}`));
            navigate("/login");
        }
        const deleted = isWishlisted;
        modifyWishlist(user?._id, props?.property?._id, deleted);
        setIsWishlisted(!isWishlisted);
    };
    useEffect(() => {
        dispatch(clearLoginRedirectUrl());
        const fetchData = async () => {
            let resp = await checkIfBiddingAllowed(props?.auctionData?._id, user?._id);
            let isUserLoggedIn = user != null;
            setIsBiddingAllowed(resp?.data?.is_bidding_allowed);
            if (props?.isAuctionEnded) {
                const auctionWinner = await getAuctionWinner(props?.auctionData?._id);
                setAuctionWinner(auctionWinner?.data);
                setShowCtaBtn(isUserLoggedIn);
            }
            if (isUserLoggedIn) {
                setShowCtaBtn(true);
            }
            else {
                setShowCtaBtn(!props?.isAuctionEnded);
            }
        };
        fetchData();
    }, [])
    return (
        <div>
            <div>
                <div className='heading-section'>
                    <div className='main-heading'>
                        {props.heading}
                    </div>
                    <div className='cta-section' style={showCtaBtn ? {} : { visibility: "hidden" }}>
                        {props.showActionBtn && !props?.isUserOwner && <div className='action-items-section'>
                            <div className='action-items' onClick={saveToWishList}>
                                <img src={save} className="icons" />
                                <div >Save</div>
                            </div>
                            {/* <div className='action-items'>
                                <img src={share} className="icons" />
                                <div>Share</div>
                            </div> */}
                        </div>}
                        {!props?.isUserOwner &&
                            <div>
                                {isBiddingAllowed ? <div className='place-bid-btn' onClick={() => setIsBiddingModalOpen(true)}>
                                    <img src={orangeCalendar} className="icons" />
                                    <div>Place Bid</div>
                                </div> : <div className='cta-btn' style={{ background: getCtaBtnConfig(props?.registrationDetails, props?.isAuctionEnded, auctionWinner, user)?.bgColor }} onClick={() => { if (!props?.isAuctionEnded) openModal(getCtaBtnConfig(props?.registrationDetails, props?.isAuctionEnded, auctionWinner, user)?.text) }}>
                                    <img src={getCtaBtnConfig(props?.registrationDetails, props?.isAuctionEnded, auctionWinner, user)?.icon} className="icons" />
                                    <div>{getCtaBtnConfig(props?.registrationDetails, props?.isAuctionEnded, auctionWinner, user)?.text}</div>
                                </div>}
                            </div>
                        }
                    </div>
                </div>
            </div>
            <div className='location-section'>
                <img src={locationLogo} />
                <div className='location-text'>Location: {props.address}</div>
            </div>
            {isModalOpen && <Modal
                isOpen={isModalOpen}
                className="registration-modal"
                overlayClassName="overlay"
            >
                <RegistrationForm setCtaText={setCtaText} closeModal={closeModal} auctionId={props?.auctionData?._id} reservePrice={props?.auctionData?.config?.price?.value} auctionData={props?.auctionData}/>
            </Modal>}
            {
                isBiddingModalOpen && <Modal
                    isOpen={isBiddingModalOpen}
                    className="modal"
                    overlayClassName="overlay"
                >
                    <PlaceBidModal auctionId={props?.auctionData?._id} isModalOpen={setIsBiddingModalOpen} auctionData={props?.auctionData} />
                </Modal>
            }
        </div>
    )
};
export default Heading;
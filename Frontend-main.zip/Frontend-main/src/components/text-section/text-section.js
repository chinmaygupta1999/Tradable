import './text-section.css';
const TextSection = (props) => {
    return (<div className='text-section'>
        {props.text}
    </div>)
}
export default TextSection;
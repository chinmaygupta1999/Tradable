import React, { useState } from 'react';
import toggleIcon from '../../images/toggle-icon.svg';
import './toggle.css';

const ToggleButton = (props) => {
    const [isToggled, setToggled] = useState(false);

    const handleToggle = () => {
        props?.setToggled((prevToggled) => !prevToggled);
    };

    return (
        <div className='toogle-container-wrapper' style={props?.isToggled?{backgroundColor: "#D46B08"}:{backgroundColor: "#D9D9D9"}}>
            <div className={`toggle-container ${props?.isToggled ? 'on' : 'off'}`}>
                <div className="toggle-button" onClick={handleToggle}>
                    <img style={{width: "20px"}}src={toggleIcon}/>
                </div>
            </div>
        </div>
    );
};

export default ToggleButton;

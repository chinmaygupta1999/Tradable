import { useEffect, useState } from 'react';
import AutoCompleteSearch from '../search-bar/autocomplete';
import SearchResult from '../search-result/search-result';
import { toast } from 'react-toastify';
import './homepage.css';

const Homepage = () => {
    const [place, setPlace] = useState();
    return (
        <div>
                {!place ? <div style={{ display: "flex", justifyContent: "center" }}>
                    <div className='homepage-container'>
                        <div className='homepage-heading-1'>
                            Simplified Property Search
                        </div>
                        <div className='homepage-heading-2'>
                            Where Dreams Nest
                        </div>
                        <div className='homepage-description'>
                            A highly transparent approach to discovering and bidding on the property of your preference.
                        </div>
                        <div style={{ width: "600px" }}>
                            <AutoCompleteSearch setPlace={setPlace} />
                        </div>
                    </div>
                </div> : <SearchResult place={place} setPlace={setPlace}/>}
        </div>
    )
};
export default Homepage;
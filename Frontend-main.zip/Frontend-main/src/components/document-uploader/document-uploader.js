import { useState, useRef, useEffect } from 'react';
import { getUploadSignedUrl } from '../../api/upload';
import axios from 'axios';
import pdfIcon from '../../images/pdf-icon.svg';
import deleteFileIcon from '../../images/delete-file-icon.svg';
import uploadingFileIcon from '../../images/upload-file-icon.svg';
import { useSelector } from 'react-redux';

const DocumentUploader = (props) => {
    const fileInputRef = useRef(null);
    const [uploadPercentage, setUploadPercentage] = useState(0);
    const [fileName, setFileName] = useState('');
    const [fileSize, setFileSize] = useState('');
    const [signedUrl, setSignedUrl] = useState(null);
    const user = useSelector(state=>state.user);

    const formatFileSize = (sizeInBytes) => {
        const KB = 1024;
        const MB = KB * 1024;
        const GB = MB * 1024;

        if (sizeInBytes < KB) {
            return `${sizeInBytes} B`;
        } else if (sizeInBytes < MB) {
            return `${(sizeInBytes / KB).toFixed(2)} KB`;
        } else if (sizeInBytes < GB) {
            return `${(sizeInBytes / MB).toFixed(2)} MB`;
        } else {
            return `${(sizeInBytes / GB).toFixed(2)} GB`;
        }
    };
    const uploadFile = () => {
        if (fileInputRef.current) {
            fileInputRef.current.click();
            handleFileUpload();
        }
    };
    const handleFileUpload = async () => {
        const fileInput = fileInputRef.current;
        if (fileInput && fileInput.files.length > 0) {
            const file = fileInput.files[0];
            let userId = user?._id;
            const filePath = "registration/" + props?.auctionId + "/" + userId + "/" + file?.name; //TODO: change this
            let uploadSignedUrl = await getUploadSignedUrl(filePath);
            uploadSignedUrl = uploadSignedUrl?.data?.upload_signed_url;
            setSignedUrl(uploadSignedUrl);
            setFileName(file?.name);
            setFileSize(formatFileSize(file?.size));
            const options = {
                onUploadProgress: (progressEvent) => {
                    const percentage = Math.round((progressEvent.loaded * 100) / progressEvent.total);
                    setUploadPercentage(percentage);
                },
                headers: {
                    'Content-Type': 'application/pdf', // Adjust content type as needed
                },
            };
            if (uploadSignedUrl) {
                try {
                    // Use axios to make the PUT request with the signed URL
                    await axios.put(uploadSignedUrl, file, options);
                    props?.setUploadUrl(`https://storage.googleapis.com/tradable-public-bucket/${filePath}`);
                } catch (error) {
                    console.error('Error uploading file:', error);
                    setUploadPercentage(0);
                }
            }
        };
    };
    const handleDeleteFile = async () => {
        if (uploadPercentage == 100) {
            setUploadPercentage(0);
            setFileName('');
            setFileSize('');
            props?.setUploadUrl(null);
        }
    };
    return (
        <div>
            <div className='registration-document-upload-section '>
                {uploadPercentage == 0 && <div className='document-upload-btn' onClick={uploadFile}>
                    Click here to upload
                    <div className='document-upload-btn-description'>
                        PDF File only
                    </div>
                    <input
                        type="file"
                        ref={fileInputRef}
                        style={{ display: 'none' }}
                        onInput={uploadFile}
                        accept="application/pdf"
                    />
                </div>}
                {uploadPercentage != 0 &&
                    <div style={{ display: "flex", justifyContent: "space-between", width: "100%" }}>
                        <div style={{ display: "flex" }}>
                            <div style={{ marginRight: "10px" }}>
                                <img src={pdfIcon} />
                            </div>
                            <div>
                                <div className='uploaded-file-name'>
                                    {fileName}
                                </div>
                                <div className='upload-file-description '>
                                    {fileSize} - {uploadPercentage}% uploaded
                                </div>
                            </div>
                        </div>
                        <div>
                            <img src={uploadPercentage != 100 ? uploadingFileIcon : deleteFileIcon}
                                style={{ cursor: "pointer" }}
                                onClick={handleDeleteFile} />
                        </div>
                    </div>
                }
            </div>
            <div className='registration-form-input-error-message' style={props?.showErrorMessage ? { visibility: "visible" } : { visibility: "hidden" }}>
                {props?.errorMessage}
            </div>
        </div>
    )
};

export default DocumentUploader;
import Search from "../search/search";
import AutoCompleteSearch from "../search-bar/autocomplete";
import { useEffect, useState } from "react";
import { toast } from 'react-toastify';

const SearchResult = (props) => {
    const [place, setPlace] = useState(props?.place);
    useEffect(() => {
        setPlace(props?.place);
        console.log(place);

    }, [place])
    return (
        <div style={{ display: 'flex', justifyContent: 'center', background: "rgb(252, 252, 252)" }}>
            <div style={{ width: "1440px" }}>
                <div style={{ margin: "20px 0px" }}>
                    <AutoCompleteSearch setPlace={props?.setPlace} />
                </div>
                <Search place={props?.place} />
            </div>
        </div>
    )
};

export default SearchResult;
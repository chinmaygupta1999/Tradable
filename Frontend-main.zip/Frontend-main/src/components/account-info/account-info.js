import uploadIcon from "../../images/upload-icon.svg";
import logoutIcon from "../../images/logout-icon.svg";
import saveIcon from "../../images/save-icon.svg";
import { useDispatch, useSelector } from 'react-redux';
import "./account-info.css";
import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { clearUser } from "../../store/action";

const AccountInfoInput = (props) => {
    return (
        <div className="account-info-details">
            <div className="account-info-title">{props?.title}</div>
            <div style={{ display: "flex", flexDirection: "column" }}>
                <input className="account-info-input" placeholder={props?.placeholder} value={props?.value} onChange={props?.handleTextInputChange} />
                <div className='account-info-input-error-message' style={props?.showErrorMessage ? { visibility: "visible" } : { visibility: "hidden" }}>
                    {props?.errorMessage}
                </div>
            </div>
        </div>
    )
};

const AccountInfoBtn = (props) => {
    return (<div className="account-info-btn">
        <img src={props?.icon} />
        {props?.text}
    </div>)
};

const AccountInfo = () => {
    const [name, setName] = useState("");
    const [phoneNo, setPhoneNo] = useState("");
    const [address, setAddress] = useState("");
    const [aadharNo, setAadharNo] = useState("");
    const [panNo, setPanNo] = useState("");
    const [accountNo, setAccountNo] = useState("");
    const [IFSC, setIFSC] = useState("");
    const dispatch = useDispatch();
    const user = useSelector((state) => state.user);
    const navigate = useNavigate();

    useEffect(() => {
        setName(user?.user_name);
        setPhoneNo(user?.phone_number);
        setAddress(user?.address);
        setAadharNo(user?.aadhar_no);
        setPanNo(user?.pan_no);
        setAccountNo(user?.account_no);
        setIFSC(user?.ifsc_code);
    }, [])

    const logOutUser = () => {
        dispatch(clearUser());
        navigate("/")
    };

    return (<div>
        {/* <div className="account-header-section">
            <div className="upload-profile-picture-section">
                <img className="account-profile-picture" src="https://storage.cloud.google.com/tradable-public-bucket/nishchay-profile?authuser=1" />
                <AccountInfoBtn icon={uploadIcon} text="Upload new picture" />
            </div>
            <div className="account-logout-section" onClick={logOutUser}>
                <img src={logoutIcon} style={{ marginRight: "4px" }} />
                <div>Logout Account</div>
            </div>
        </div> */}
        <div className="account-basic-details-section">
            <div style={{display: "flex", justifyContent: "space-between", }}>
                Account Details
                <div className="account-logout-section" onClick={logOutUser}>
                    <img src={logoutIcon} style={{ marginRight: "4px" }} />
                    <div>Logout Account</div>
                </div>
            </div>
            <div style={{marginTop: "20px"}}>
            <AccountInfoInput title="Full name" placeholder="Enter your full name" handleTextInputChange={(e) => setName(e.target.value)} value={name} showErrorMessage={name?.length <= 0} errorMessage="Full Name is mandatory" />
            {/* <AccountInfoInput title="Address" placeholder="Enter your address" handleTextInputChange={(e) => setName(e.target.value)} value={address} /> */}
            <AccountInfoInput title="Mobile number" placeholder="Enter your mobile number" value={phoneNo} />
            {/* <AccountInfoInput title="Aadhar Card" placeholder="Enter your aadhar card number" value={aadharNo} handleTextInputChange={(e) => setName(e.target.value)} showErrorMessage={/^[2-9]{1}[0-9]{11}$/.test(aadharNo)} errorMessage="Invalid Aadhar Number" />
            <AccountInfoInput title="Pan Card" placeholder="Enter your pan card number" value={panNo} />
            <AccountInfoInput title="Account number" placeholder="Enter your account number" value={accountNo} />
            <AccountInfoInput title="IFSC Code" placeholder="Enter your IFSC code" value={IFSC} /> */}
            </div>
            {/* <div style={{ marginTop: "30px" }}>
                <AccountInfoBtn icon={saveIcon} text="Save Profile" />
            </div> */}
        </div>
    </div>)
}
export default AccountInfo;
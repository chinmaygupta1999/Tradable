import React, { useEffect, useState } from 'react';
import closeIcon from '../../../images/close-icon.svg'
import './modal.css';

const Modal = ({ onClose, propertyData }) => {
  const [selectedCategory, setSelectedCategory] = useState("All");
  const [categories, setCategories] = useState([]);
  const [urlList, setUrlList] = useState([]);
  const [categoryToUrlListMap, setCategoryToUrlListMap] = useState([]);

  useEffect(() => {
    const propertyImages = propertyData?.property_images;
    const sortedFloors = Object.keys(propertyImages).sort((a, b) => {
      return propertyImages[a].order - propertyImages[b].order;
    });

    // Create a new object with sorted floors
    const sortedPropertyImages = {};
    sortedFloors.forEach(floor => {
      sortedPropertyImages[floor] = propertyImages[floor].url_list;
    });
    const valuesArray = Object.values(sortedPropertyImages).flat();
    const updatedObject = { All: valuesArray, ...sortedPropertyImages };
    setCategories(Object.keys(updatedObject));
    setUrlList(updatedObject[selectedCategory]);
    setCategoryToUrlListMap(updatedObject);
  }, []);

  const onHeaderClick = async (category) => {
    setSelectedCategory(category);
    setUrlList(categoryToUrlListMap[category]);
  };

  return (
    <div className='modal-parent'>
      <div className='modal-alignment'>
        <div>
          <div className='img-frame-header-section'>
            <div className='img-from-header-list'>
              {
                categories.map((category) => {
                  return (
                    <div className={selectedCategory == category ? 'img-frame-header img-frame-header-selected' : 'img-frame-header'}
                      onClick={() => onHeaderClick(category)}>
                      {category}
                    </div>
                  )
                })
              }
            </div>
            <img src={closeIcon} onClick={onClose} style={{ height: "24px", width: "24px", cursor: "pointer" }} />
          </div>
          <div className='img-frame-section'>
            {
              urlList.map((url) => {
                return (
                  <img className='img-in-frame' src={url} />
                )
              })
            }
          </div>
        </div>
      </div>
    </div>
  );
};

export default Modal;

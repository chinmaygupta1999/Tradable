import React, { useEffect, useState } from 'react';
import './frame.css';
import Modal from './image-modal/modal';

const Frame = (props) => {
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [imgUrl, setImgUrl] = useState([]);
    const openModal = () => {
        setIsModalOpen(true);
    };

    const closeModal = () => {
        setIsModalOpen(false);
    };

    useEffect(() => {
        const propertyImages = props?.propertyData?.property_images;
        const sortedFloors = Object.keys(propertyImages).sort((a, b) => {
            return propertyImages[a].order - propertyImages[b].order;
        });

        // Create a new object with sorted floors
        const sortedPropertyImages = {};
        sortedFloors.forEach(floor => {
            sortedPropertyImages[floor] = propertyImages[floor].url_list;
        });
        const valuesArray = Object.values(sortedPropertyImages).flat();
        const updatedObject = { All: valuesArray, ...sortedPropertyImages };
        setImgUrl(updatedObject?.All);
    }, []);

    return (
        <div>
            <div className="main-frame">
                <div className='view-all-btn' onClick={openModal}>
                    View All
                </div>
                <div className='sub-frame-1' >
                    <img src={imgUrl[0]} className='img' />
                </div>
                <div className='sub-frame-2'>
                    <div className='sub-frame-2-1'>
                        <img src={imgUrl[1]} className='img' />
                    </div>
                    <div className='sub-frame-2-2'>
                        <div className='sub-frame-2-2-1'>
                            <img src={imgUrl[2]} className='img' />
                        </div>
                        <div className='sub-frame-2-2-2'>
                            <img src={imgUrl[3]} className='img' />
                        </div>

                    </div>
                </div>
            </div>

            {isModalOpen && <Modal onClose={closeModal} propertyData={props?.propertyData} />}
        </div>
    )
}
export default Frame;
// AutocompleteComponent.js
import React, { useState } from 'react';
import { Autocomplete } from '@react-google-maps/api';
import searchIcon from "../../images/search-icon.svg";
import { toast } from 'react-toastify';
import "./autocomplete.css";

const AutoCompleteSearch = (props) => {
  const [autocomplete, setAutocomplete] = useState(null);
  const onLoad = (auto) => setAutocomplete(auto);

  return (
    <div>
      <div className='search-page'>
        <Autocomplete
          onLoad={onLoad}
          onPlaceChanged={async () => {
            toast.dismiss();
            let place = await autocomplete?.getPlace();
            if (place) {
              if (place?.geometry) {
                props?.setPlace(place);
              }
              else {
                // alert("Invalid Selection, please select an option from the dropdown")
                toast.error("Invalid Selection, please select an option from the dropdown", {
                  toastId: "error"
                });
              }
            }
          }}
          options={{ componentRestrictions: { country: 'IN' } }}
          style={{ width: "100%" }}
        >
          <div className='search-box'>
            <input
              type="text"
              placeholder="Search Places..."
              className='seach-box-input'
              style={{ width: "80%", border: "none" }}
            />
            <div className='search-box-btn'>
              <img src={searchIcon} />
            </div>
          </div>
        </Autocomplete>
      </div>
    </div>
  );
};

export default AutoCompleteSearch;

import { useEffect, useState } from 'react';
import placeBidIcon from '../../images/place-bid-green-icon.svg';
import closeBtn from '../../images/close-modal-icon.svg';
import { placeBid } from '../../api/auction';
import { getBidDetails } from '../../api/auction';
import io from 'socket.io-client';
import './place-bid-modal.css';
import API_DOMAIN from '../../constants';
import { useSelector } from 'react-redux';

const PlaceBidModal = (props) => {
    const [bidValue, setBidValue] = useState('');
    const [isSubmitDisabled, setIsSubmitDisabled] = useState(true);
    const [bidDetails, setBidDetails] = useState();
    const user = useSelector(state => state.user);

    // const showToast = (message, type) => {
    //     props.setToastMessage(message);
    //     props.setToastType(type);
    //     props.setToastVisible(true);
    // };

    const handleBidChange = (event) => {
        let newBid = event.target.value;
        let currentHighestBid = bidDetails?.auction_highest_bid?.price?.value;
        setBidValue(newBid);
        if (newBid > currentHighestBid) {
            setIsSubmitDisabled(false);
        }
        else
            setIsSubmitDisabled(true);
    };

    const closeModal = () => {
        props.isModalOpen(false);
    }

    const placeNewBid = async () => {
        const resp = await placeBid(props?.auctionId, user?._id, bidValue);
        if (resp?.data) {
            // showToast('Bid Placed Successfully!', 'success');
        }
        else {
            // showToast('Something went wrong', 'error');
        }
        closeModal();
    };
    useEffect(() => {
        // Connect to the Socket.IO server
        const socket = io(API_DOMAIN);

        const fetchData = async () => {
            const bidDetails = await getBidDetails(props?.auctionId, user?._id);
            setBidDetails(bidDetails?.data);
            // Connect to the Socket.IO server
            socket.on('bid_update', function (msg) {
                // console.log("socket message=", msg);
                setBidDetails(msg)
            })
        }
        fetchData();

        // Clean up the socket connection on component unmount
        return () => {
            socket.disconnect();
        };

        // Clean up the socket connection on component unmount
    }, [])

    return (<div className='place-bid-modal'>
        <div className='modal-icons'>
            <img src={placeBidIcon} />
            <img src={closeBtn} className='modal-close-icon' onClick={closeModal} />
        </div>
        <div className='modal-heading'>
            Place your bid
        </div>
        <div className='modal-description'>
            Current highest bid: <span className='highlight'>Rs. {JSON.stringify(bidDetails?.auction_highest_bid?.price?.value)}</span>
        </div>
        <div className='modal-description'>
            Auction reserve price: <span className='highlight'>Rs. {JSON.stringify(props?.auctionData?.config?.min_bid_increment?.value)}</span>
        </div>
        <div className='modal-description'>
            Next acceptable bid: <span className='highlight'>Rs. {JSON.stringify(bidDetails?.auction_highest_bid?.price?.value+props?.auctionData?.config?.min_bid_increment?.value)}</span>
        </div>
        <div className='modal-input-description'>
            Enter the increased bid amount(in <span className='highlight'>INR</span>)
        </div>
        <input className='modal-input' type="number" value={bidValue} onChange={handleBidChange} />
        {isSubmitDisabled && <div className='modal-warning'>Enter {JSON.stringify(bidDetails?.auction_highest_bid?.price?.value+props?.auctionData?.config?.min_bid_increment?.value)} or more</div>}
        <div className='modal-disclaimer'>By selecting Bid, you are committing to buy this item if you are the winning bidder</div>
        <div className={isSubmitDisabled ? 'disabled-submit-btn' : 'submit-btn'} onClick={placeNewBid}>Increase Bid</div>
    </div>)
}
export default PlaceBidModal;
import React, { useEffect, useState } from 'react';
import logo from '../../images/tradable-logo.svg';
import { requestOtp, verifyOTP, signupUser } from '../../api/login';
import { useNavigate } from "react-router-dom";
import {setUser, setOpenRegistrationModal} from '../../store/action';
import { useDispatch, useSelector } from 'react-redux';
import './login.css';

const NumberInput = (props) => {
    const [value, setValue] = useState('');

    const handleInputChange = (e) => {
        // Remove any non-numeric characters
        const sanitizedValue = e.target.value.replace(/\D/g, '');

        // Limit the input to 10 characters
        const trimmedValue = sanitizedValue.slice(0, 10);

        setValue(trimmedValue);
        if(trimmedValue.length === 10) {
            props.setIsBtnDisabled(false); // Enable the submit button when 10 digits are entered
            props.setPhoneNumber(trimmedValue);
        } else {
            props.setIsBtnDisabled(true); // Disable the submit button otherwise
        }
    };

    return (
        <div>
            <input
                className='custom-input'
                type="text"
                value={value}
                onChange={handleInputChange}
                placeholder="Enter 10-digit number"
            />
        </div>
    );
};

const TextInput = (props) => {
    const [value, setValue] = useState('');
    const handleInputChange = (e) => {
        setValue(e.target.value);
        props.callback(e.target.value);
    }
    return (
        <div>
            <input
                className='custom-input'
                type="text"
                value={value}
                placeholder={props.placeholder}
                onChange={handleInputChange}
            />
        </div>
    );
};

const OTPInput = (props) => {
    const [otp, setOTP] = useState(['', '', '', '', '', '']);
    const inputRefs = [];
    useEffect(() => {
        if (isValidOtp()) { props.isOtpBtnDisabled(false); }
        else { props.isOtpBtnDisabled(true); }
        props.setOtp(otp.join(''))
    }, [otp])

    const isValidOtp = () => {
        let isValidOtp = true;
        for (let i = 0; i < otp.length; ++i) {
            if (otp[i] == '') { isValidOtp = false }
        }
        return isValidOtp;
    }
    const handleInputChange = (e, index) => {
        const value = e.target.value;
        if (value.match(/^\d*$/)) {
            otp[index] = value;
            setOTP([...otp]);

            if (index < 5 && value !== '') {
                inputRefs[index + 1].focus();
            }
        }
    };

    const onEditClick = () => {
        props.setIsPhoneNoAdded(false);
    }

    return (
        <div>
            <div className='input-field-name'>OTP Sent to</div>
            <div className='otp-phone-number-section'>
                <div>+91 {props.phoneNumber}</div>
                <div className='edit-phone-no-btn' onClick={onEditClick}>Edit</div>
            </div>
            <div className='input-field-name'>Enter OTP</div>
            <div className="otp-container">
                {otp.map((digit, index) => (
                    <input
                        type="text"
                        value={digit}
                        maxLength="1"
                        className="otp-input"
                        onChange={(e) => handleInputChange(e, index)}
                        ref={(el) => (inputRefs[index] = el)}
                        key={index}
                    />
                ))}
            </div>
        </div>
    );
};

const Botton = (props) => {
    return (
        <div className={props.isBtnDisabled ? "next-btn-disabled" : "next-btn"} disabled={false} onClick={props.onBtnClick}>
            {props.text}
        </div>)
};

const LoginPage = () => {
    const [isBtnDisabled, setIsBtnDisabled] = useState(true);
    const [isOtpBtnDisabled, setIsOtpBtnDisabled] = useState(true);
    const [phoneNumber, setPhoneNumber] = useState("");
    const [isPhoneNoAdded, setIsPhoneNoAdded] = useState(false);
    const [otp, setOtp] = useState("");
    const [invalidOtpMessage, setInvalidOtpMessage] = useState("");
    const [showSignupScreen, setShowSignupScreen] = useState(false);
    const [userName, setUserName] = useState("");
    const navigate = useNavigate();
    const dispatch = useDispatch();
    const postLoginRedirectUrl = useSelector(state=>state.post_login_redirect_url)||'/';
    if (postLoginRedirectUrl != '/'){
        dispatch(setOpenRegistrationModal(1))
    }

    const setUserData = (user) => {
        dispatch(setUser({ ...user }));
    };

    const onNextBtnClick = async () => {
        setIsPhoneNoAdded(true);
        let response = await requestOtp(phoneNumber);
    };

    const onOtpBtnClick = async () => {
        let response = await verifyOTP(phoneNumber, otp);
        if (response?.data?.message == "Invalid OTP") {
            setInvalidOtpMessage("Invalid OTP");
        }
        if (response?.data?.user) {
            navigate(postLoginRedirectUrl);
            setUserData(response?.data?.user)
        }
        else {
            setShowSignupScreen(true);
        }
    }
    
    const onSignUpBtnClick = async () => {
        let response = await signupUser(phoneNumber, userName);
        if (response?.data?.user) {
            setUserData(response?.data?.user);
            navigate(postLoginRedirectUrl);
        }
    }
    return (
        <div className='main-container'>
            <div className='main-container-border'>
            <img src={logo} />
            {/* <div className='heading'>
                Welcome back
            </div> */}
            <div className='description'>
                Welcome back! Please enter your details.
            </div>
            {!isPhoneNoAdded && <div className='phone-no-section'>
                <div className='input-field-name'>
                    Mobile Number
                </div>
                <NumberInput setIsBtnDisabled={setIsBtnDisabled} setPhoneNumber={setPhoneNumber} />
                <Botton text="Next" isBtnDisabled={isBtnDisabled} onBtnClick={onNextBtnClick} />
            </div>}
            {!showSignupScreen&&isPhoneNoAdded && <div className='otp-section'>
                <OTPInput phoneNumber={phoneNumber} setOtp={setOtp} setIsPhoneNoAdded={setIsPhoneNoAdded} isOtpBtnDisabled={setIsOtpBtnDisabled} />
                {invalidOtpMessage.length != 0 && <div className='error-message'>{invalidOtpMessage}</div>}
                <Botton text="Submit" isBtnDisabled={isOtpBtnDisabled} onBtnClick={onOtpBtnClick} />
            </div>}
            {showSignupScreen && <div>
                <div className='input-field-name'>
                    <div>
                    Phone Number 
                    </div>
                <div className='custom-input'>
                    {phoneNumber}
                </div>
                </div>
                <div className='input-field-name'>
                    Your Name
                </div>
                    <TextInput placeholder="Enter your name" callback={setUserName} />
                    <Botton text="Signup" isBtnDisabled={userName.length<=0} onBtnClick={onSignUpBtnClick}/>
                </div>
            }
            </div>
        </div>
    )
}

export default LoginPage;
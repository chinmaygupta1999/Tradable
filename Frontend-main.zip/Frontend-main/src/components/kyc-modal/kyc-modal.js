import placeBidIcon from '../../images/place-bid-green-icon.svg';
import closeBtn from '../../images/close-modal-icon.svg';
import './kyc-modal.css';

const KycModal = ()=>{
    return (
        <div>KYC Modal</div>
    )
}
export default KycModal;

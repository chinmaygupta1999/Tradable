import { useState } from "react";
import "./custom-input.css";
import dropdownIcon from '../../images/dropdown-icon.svg';

const CustomInput = (props) => {
    const [showDropDown, setShowDropDown] = useState(false);
    console.log(props?.selectedItem, props?.dropDownList)
    return (
        <div>
            <div className='registration-input-wrapper' style={props?.freezeInput?{pointerEvents: "none", background: "#F5F5F5"}:{}}>
                {
                    props?.hasDropDown && <div className="registration-input registration-input-dropdown" onClick={() => { setShowDropDown(!showDropDown); }}>
                        {props?.selectedItem}
                        <img src={dropdownIcon} />
                        {showDropDown && <div className='registration-input-dropdown-item-wrapper'>
                            {
                                props?.dropDownList.filter(item => item != props?.selectedItem).map(item => {
                                    return (<div className='registration-input-dropdown-item'
                                        onClick={() => { setShowDropDown(false); props?.setSelectedItem(item) }}>{item}</div>)
                                })
                            }
                        </div>}
                    </div>
                }
                <input className='registration-input'
                    placeholder={props?.placeholder}
                    value={props?.value}
                    onChange={props?.handleTextInputChange}
                    style={{background: "transparent"}}/>
            </div>
            <div className='registration-form-input-error-message' style={props?.showErrorMessage ? { visibility: "visible" } : { visibility: "hidden" }}>
                {props?.errorMessage}
            </div>
        </div>
    )
};
export default CustomInput;
import { useEffect, useState } from 'react';
import PropertyCard from '../property-card/property-card.js';
import { viewWishlist } from '../../api/wishlist.js';
import './wishlist.css';
import { useSelector } from 'react-redux';

const Wishlist = () => {
    const [propertyList, setPropertyList] = useState([]);
    const user = useSelector(state=>state.user);
    useEffect(() => {
        const fetchDetails = async () => {
            let resp = await viewWishlist(user?._id);
            setPropertyList(resp?.data)
        };
        fetchDetails();
    }, [])
    return (
        <div className='wishlist-section'>
           { propertyList.map((property)=>{
                return  <PropertyCard property={property}/>
            })}
        </div>
    )
};
export default Wishlist;
import React from 'react';
import './section-separator.css';
const SectionSeparator = () => {
    return (
        <div className='section-separator'>
        </div>)
}
export default SectionSeparator;
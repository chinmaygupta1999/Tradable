import pdfIcon from '../../images/pdf-icon.svg';
import "./document-viewer.css";

const DocumentViewer = (props) => {
    return (<div className='document-viewer' style={{ cursor: "pointer", background: "#F5F5F5" }} onClick={() => { window.open(props?.uploadUrl) }}>
        <div style={{ display: "flex", justifyContent: "space-between", width: "100%" }}>
            <div style={{ display: "flex", alignItems: "center" }}>
                <div style={{ marginRight: "10px" }}>
                    <img src={pdfIcon} />
                </div>
                <div className='document-file-name' style={{ color: "#434343" }}>
                    {props?.documentUrl}
                </div>
            </div>
        </div>
    </div>)
}
export default DocumentViewer;
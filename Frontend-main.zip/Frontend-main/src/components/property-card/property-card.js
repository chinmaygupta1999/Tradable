import { formatCurrencyIndianSystem } from "../../utils/property";
import whiteLocationIcon from "../../images/white-location-icon.svg";
import flatIcon from "../../images/flat-icon.svg"
import whiteCurrencyRupee from "../../images/white-currency-rupee.svg";
import greyDot from "../../images/grey-dot.svg";
import viewsIcon from "../../images/view-icon.svg";
import wishlistIcon from "../../images/wishlist-icon.svg";
import wishlistedIcon from "../../images/wishlisted-icon.svg"
import './property-card.css';
import { useState, useEffect } from "react";
import {modifyWishlist} from "../../api/wishlist";
import { useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";

const PropertyCard = (props) => {
  const [isWishlisted, setIsWishlisted] = useState();
  const cardStyle = {
    backgroundImage: `url('https://storage.cloud.google.com/tradable-public-bucket/Rectangle%201066.png?authuser=1')`,
    backgroundSize: 'cover',
    backgroundPosition: 'center',
    borderRadius: '8px',
    overflow: 'hidden',
    position: 'relative',
    width: '280px',
    height: '201px',
    margin: '10px',
    cursor: 'pointer'
  };

  const contentStyle = {
    position: 'absolute',
    bottom: '0',
    left: '0',
    right: '0',
    padding: '10px',
    background: 'rgba(0, 0, 0, 0.5)',
    color: '#ffffff',
    borderBottomLeftRadius: '8px',
    borderBottomRightRadius: '8px',
  };
  const user = useSelector(state=>state.user);
  const onWishlistClick = () => {
    const deleted = isWishlisted;
    modifyWishlist(user?._id, props?.property?._id, deleted);
    setIsWishlisted(!isWishlisted);
  }
  const navigate = useNavigate();
  useEffect(() => {
    setIsWishlisted(props?.property?.wishlisted);
  }, [])

  return (
    <div style={cardStyle} onClick={()=>{navigate(`/property/${props?.property?._id}`)}}>
      {<img className="property-card-wishlist-icon" style={props?.hideWishlistIcon?{display: "none"}: {}} src={isWishlisted ? wishlistedIcon : wishlistIcon} onClick={(e)=>{e.stopPropagation();onWishlistClick();}} />}
      <div style={contentStyle}>
        <div className="property-card-price">
          <img src={whiteCurrencyRupee} />
          {formatCurrencyIndianSystem(props?.property?.price?.value)} <span className="property-card-description">opening bid</span>
        </div>
        <div>
          <div className="property-card-meta">
            <img className="property-card-meta-icon" src={whiteLocationIcon} />{props?.property.address}
          </div>
          {/* <div className="property-card-meta">
            <img className="property-card-meta-icon" src={flatIcon} /> 3 BHK
            <img src={greyDot} style={{ margin: "0px 4px" }} />
            <img className="property-card-meta-icon" src={viewsIcon} />
            32
          </div> */}
        </div>
      </div>
    </div>
  )
};

export default PropertyCard;
import { useState, useEffect, React } from 'react';
import SectionHeading from '../section-heading/section-heading';
import star from '../../images/star.svg';
import AuctionDetails from '../../images/auction-details-icon.svg';
import './overview.css';
import currencyIcon from '../../images/currency-rupee.svg';
import { formatCurrencyIndianSystem, datetimeFromTimestamp, numberToWords } from '../../utils/property';

const CountdownTimer = (props) => {
    const calculateTimeLeft = () => {
        const now = new Date().getTime();
        const difference = props?.timerConfig?.targetDate - now;

        if (difference > 0) {
            const days = Math.floor(difference / (1000 * 60 * 60 * 24));
            const hours = Math.floor((difference % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
            const minutes = Math.floor((difference % (1000 * 60 * 60)) / (1000 * 60));
            const seconds = Math.floor((difference % (1000 * 60)) / 1000);

            return { days, hours, minutes, seconds };
        } else {
            return { days: 0, hours: 0, minutes: 0, seconds: 0 };
        }
    };

    const [timeLeft, setTimeLeft] = useState(calculateTimeLeft());

    useEffect(() => {
        const timerInterval = setInterval(() => {
            setTimeLeft(calculateTimeLeft());
        }, 1000);

        return () => {
            clearInterval(timerInterval);
        };
    }, [props?.timerConfig?.targetDate]);

    return (
        <div className='timer'>
            <div className='timer-heading'>
                {props?.timerConfig?.timerText}
            </div>
            <div className='timer-details'>
                <div className='timer-data'>
                    <div className='timer-value'>
                        {timeLeft?.days}
                    </div>
                    <div className='timer-unit'>
                        d
                    </div>
                </div>
                <div className='timer-separator'>:</div>
                <div className='timer-data'>
                    <div className='timer-value'>
                        {timeLeft?.hours}
                    </div>
                    <div className='timer-unit'>
                        hrs
                    </div>
                </div>
                <div className='timer-separator'>:</div>
                <div className='timer-data'>
                    <div className='timer-value'>
                        {timeLeft?.minutes}
                    </div>
                    <div className='timer-unit'>
                        mins
                    </div>
                </div>
                <div className='timer-separator'>:</div>
                <div className='timer-data'>
                    <div className='timer-value'>
                        {timeLeft?.seconds}
                    </div>
                    <div className='timer-unit'>
                        sec
                    </div>
                </div>
            </div>
        </div>
    );
};
const OverviewItem = (props) => {
    return (
        <div className='overview-item'>
            <img src={star} className='icons' />
            <div>
                <div className='overview-item-title'>
                    {props.title}
                </div>
                <div className='overview-item-description'>
                    {props.description}
                </div>
            </div>
        </div>)
}
const Overview = (props) => {
    const [timerConfig, setTimerConfig] = useState();
    const getTimerConfig = (auctionConfig) => {
        const currentTime = Math.floor(Date.now() / 1000);
        let targetDate;
        let timerText = "";
        if (currentTime < auctionConfig.start_time) {
            targetDate = auctionConfig.start_time * 1000;
            timerText = "Starts in (IST)"
        } else {
            targetDate = auctionConfig.end_time * 1000;
            timerText = "Ends in (IST)"
        }
        setTimerConfig({
            timerText,
            targetDate
        })
    };
    useEffect(() => {
        getTimerConfig(props?.auctionConfig);
    }, [])
    return (
        <div className='overview-section'>
            <div className='overview-details'>
                <SectionHeading heading="Overview" />
                <div className='overview-items-container'>
                    <OverviewItem title={"Commercial"} description={"Property Type"} />
                    <OverviewItem title={"1000 sq ft"} description={"Front row width"} />
                    <OverviewItem title={"1200 sq ft"} description={"Area"} />
                    <OverviewItem title={"If Any"} description={"Payment Terms"} />
                    <OverviewItem title={"2022"} description={"Construction"} />
                </div>
            </div>
            <div className='pricing-details'>
                <div className='pricing-heading-section'>
                    <div className='pricing-heading'>RESERVE PRICE</div>
                    {props?.isAuctionEnded ? <div className='timer timer-heading'>
                        Auction has ended
                    </div> : <CountdownTimer timerConfig={timerConfig} />}
                </div>
                <div className='pricing-amount-section'>
                    <img src={currencyIcon} style={{ width: "25px" }} />
                    <div>
                        <div className='pricing-amount'> {formatCurrencyIndianSystem(props?.price)}</div>
                        <div className='pricing-amount-in-words'>{numberToWords(props?.price)}</div>
                    </div>
                </div>
                <div className='auction-time-details'><span>Auction start date : </span>{datetimeFromTimestamp(props?.auctionStartTime * 1000)}</div>
                <div className='auction-time-details'>Auction end date : {datetimeFromTimestamp(props?.auctionEndTime * 1000)}</div>
                <div className='auction-time-details'>EMD amount : <img src={currencyIcon} style={{ width: "14px" }} />{formatCurrencyIndianSystem(props?.emd)}</div>
                <div className='auction-details-btn' onClick={() => {
                props?.setSelectedBreadcrum("Auction Details");
                }}>
                    <img src={AuctionDetails} className='icons' />View Auction Details</div>
            </div>
        </div>);

};
export default Overview;
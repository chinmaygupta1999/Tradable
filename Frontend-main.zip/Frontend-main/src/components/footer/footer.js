import tradableIcon from '../../images/tradable-icon.svg';
import "./footer.css";
const Footer = () => {
    return (
        <div className="footer">
            <div className="footer-container">
                <div className="footer-logo">
                    <img src={tradableIcon} />
                </div>
                <div className="footer-redirection">
                    <div>
                        LinkedIn
                    </div>
                    <div>
                        Instagram
                    </div>
                    <div>
                        Twitter
                    </div>
                    <div>
                        Email
                    </div>
                    <div>
                        Facebook
                    </div>
                    <div>
                        Help
                    </div>
                </div>
                <div className="footer-border">
                    <div className="footer-legal">
                        <div className="footer-copywrite">
                            © 2023 Tradable. All rights reserved.
                        </div>
                        <div className="footer-legal-redirection">
                            <div>
                                Terms
                            </div>
                            <div>
                                Privacy
                            </div>
                            <div>
                                Cookie
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>)
}
export default Footer;
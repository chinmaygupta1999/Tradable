import { useDispatch } from 'react-redux';
import arrow from '../../images/right-arrow.svg';
import { setOpenRegistrationModal } from '../../store/action';
import "./breadcrum.css";

const Breadcrum = (props) => {
    const dispatch = useDispatch();
    const onBreadcrumClick = (breadcrum) => {
        props?.setSelectedBreadcrum(breadcrum);
        dispatch(setOpenRegistrationModal(0));
    }
    return (
        <div className="breadcrum-text breadcum-container">
            <div className="breadcrum-text-color" style={props.selectedBreadcrum == "Explore" ? { "color": "#D46B08" } : {}} onClick={()=>window.location.href=window.origin}>
                Explore
            </div>
            <img src={arrow} className='breadcrum-arrow' />
            <div className="breadcrum-text-color"
                style={props?.selectedBreadcrum == props?.propertyName ? { "color": "#D46B08" } : {}}
                onClick={() => { onBreadcrumClick(props?.propertyName); }}>
                {props?.propertyName}
            </div>
            <img src={arrow} className='breadcrum-arrow' />
            <div className="breadcrum-text-color"
                style={props?.selectedBreadcrum == "Auction Details" ? { "color": "#D46B08" } : {}}
                onClick={() => { onBreadcrumClick("Auction Details"); }}>
                Auction Details
            </div>
            { 
              props?.isUserOwner && <div style={{ display: "flex", justifyContent: "center", alignItems: "center" }}>
                    <img src={arrow} className='breadcrum-arrow' />
                    <div className="breadcrum-text-color"
                        style={props?.selectedBreadcrum == "Auction Configuration" ? { "color": "#D46B08" } : {}}
                        onClick={() => { onBreadcrumClick("Auction Configuration"); }}>
                        Auction Configuration
                    </div>
                </div>}
        </div>
    )
};
export default Breadcrum;
import SectionHeading from "../section-heading/section-heading";
import publicTransport from '../../images/public-transport.svg';
import "./amenities.css";
import CarouselComponent from "../carousel/carousel";
import React, { forwardRef } from 'react';

const AmenitiesCard = (props) => {
return (<div className="amenities-card">
<img src={props.img_src}/>
<div className="amenities-heading">{props.heading}</div>
<div className="amenities-description">{props.description}</div>
</div>)
}
const Amenities = forwardRef((props, ref) => {
const corouselList = [<AmenitiesCard img_src={publicTransport} heading='Public Transportation' description='Car stops, subway stations'/>, <AmenitiesCard  img_src={publicTransport} heading='Public Transportation' description='Bus stops, subway stations'/>, <AmenitiesCard img_src={publicTransport} heading='Public Transportation' description='Bus stops, subway stations'/>, <AmenitiesCard  img_src={publicTransport} heading='Public Transportation' description='Bus stops, subway stations'/>, <AmenitiesCard img_src={publicTransport} heading='Public Transportation' description='Bus stops, subway stations'/>, <AmenitiesCard img_src={publicTransport} heading='Public Transportation' description='Bus stops, subway stations'/>];
return (<div ref={ref} >
<SectionHeading heading="Amenities"/>
<CarouselComponent items={corouselList}/>
</div>)
})
export default Amenities;
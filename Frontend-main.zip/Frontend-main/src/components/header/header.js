import React from 'react';
import './header.css';
import Logo from './logo/logo';
import Feature from './feature/feature';
import Account from './account/account';
import { useNavigate } from "react-router-dom";

const Header = () => {
    let navigator = useNavigate();
    return (
        <div className='header-border'>
            <div className='header'>
                <div onClick={()=>navigator("/")} style={{cursor: "pointer"}}>
                    <Logo />
                </div>
                <Feature />
                <Account />
            </div>
        </div>
    )
}
export default Header;
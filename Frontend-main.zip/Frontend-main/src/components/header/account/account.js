import React, { useState } from 'react';
import { useNavigate } from "react-router-dom";
import { clearUser } from "../../../store/action";
import { useSelector, useDispatch } from 'react-redux';
import './account.css';

const AccountDropDown = () => {
    const dispatch = useDispatch();
    const logOutUser = () => {
        dispatch(clearUser());
        window.location.href = window.origin
    };

    return (
        <div className='account-dropdown-list'>
            <div style={{ padding: "10px" }} onClick={() => window.location.href = window.origin + '/account'}>
                My Account
            </div>
            <div style={{ borderBottom: "1px solid #D9D9D9", marginTop: "5px", marginBottom: "5px" }}>
            </div>
            <div style={{ padding: "10px" }} onClick={logOutUser}>
                Logout
            </div>
        </div>
    )
}
const LoginBtn = () => {
    const navigate = useNavigate();
    return (
        <div className='login-btn' onClick={() => navigate('/login')}>
            Login
        </div>)
}
const Account = () => {
    const user = useSelector(state => state.user);
    const [showDropDown, setShowDropDown] = useState(false);
    return (
        <div className='account'>
            {!user && <LoginBtn />}
            {user && <div className='logged-in-user-name' onClick={() => setShowDropDown(!showDropDown)}>{user?.user_name}</div>}
            {showDropDown && <AccountDropDown setShowDropDown={setShowDropDown} showDropDown={showDropDown}/>}
        </div>
    )
}
export default Account;
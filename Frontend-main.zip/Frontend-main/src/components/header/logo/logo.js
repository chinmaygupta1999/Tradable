import React from 'react';
import tradableLogo from '../../../images/tradable-logo.svg';
import './logo.css';
const Logo = () => {
    return (
        <img src={tradableLogo} className='logo' />
    )
}
export default Logo;
import React from 'react';
import './feature.css';
import coinsHand from '../../../images/coins-hand.svg';
import compass from '../../../images/compass.svg';
import rocket from '../../../images/rocket.svg';
import mark from '../../../images/mark.svg'

const Feature = () => {
    return (
        <div className='feature-list'>
            <div className='feature'>
                <img src={coinsHand} className='feature-img'></img>
                Explore
            </div>
            <div className='feature'>
                <img src={compass} className='feature-img'></img>
                Buy Property
            </div>
            <div className='feature'>
                <img src={mark} className='feature-img'></img>
                Sell Property
            </div>
        </div>
    )
}
export default Feature;
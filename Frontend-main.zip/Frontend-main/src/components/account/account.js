import { useState } from 'react';
import Header from '../header/header';
import SectionSeparator from '../section-separator/section-separator';
import './account.css';
import Wishlist from '../wishlist/wishlist';
import AccountInfo from '../account-info/account-info';
import UserListing from '../user-listing/user-listing';
import Footer from '../footer/footer';

const NavBar = (props) => {
    const handleSelection = (index) => {
        props?.setSelectedIndex(index);
    };
    return (
        <div>
            {
                props.navItems.map((element, index) => {
                    return (<div className='navbar-item' style={props?.selectedIndex == index ? { "background": "#FFE7BA" } : { "background": "#FCFCFC" }} onClick={() => handleSelection(index)}>
                        {element}
                    </div>)
                })
            }
        </div>
    )
}
const Account = () => {
    const [selectedIndex, setSelectedIndex] = useState(0);
    // const navbarItems = ['Account Info', 'Wishlist', 'Ongoing Auctions', 'Upcoming Auctions', 'My Listings'];
    const navbarItems = ['Account Info', 'Wishlist', 'My Listings'];
    const navbarItemsToDisplaySectionMapping = {
        'Account Info': <AccountInfo />,
        'Wishlist': <Wishlist />,
        // 'Ongoing Auctions': <div>Ongoing Auctions</div>,
        // 'Upcoming Auctions': <div>Upcoming Auctions</div>,
        'My Listings': <UserListing />,
    }

    return (
        <div>
            <div className='page-alignment' style={{ background: "#FCFCFC" }}>
                <div className='page-config'>
                    <div>
                        <div className='account-title'>
                            My Account
                        </div>
                        <SectionSeparator />
                        <div className='account'>
                            <div className='navigation-section'>
                                <NavBar setSelectedIndex={setSelectedIndex} selectedIndex={selectedIndex} navItems={navbarItems} />
                            </div>
                            <div className='display-section'>
                                {navbarItemsToDisplaySectionMapping[navbarItems[selectedIndex]]}
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
}
export default Account;
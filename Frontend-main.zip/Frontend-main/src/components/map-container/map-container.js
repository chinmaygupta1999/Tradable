


// // MapComponent.js
// // import React, { useState } from 'react';
// // import { GoogleMap, LoadScript, MarkerF } from '@react-google-maps/api';

// // const containerStyle = {
// //   width: '100%',
// //   height: '400px',
// // };

// // const center = {
// //   lat: 28.358665,
// //   lng: 75.588,
// // };

// // const defaultMarkerPosition = {
// //   lat: 28.358665,
// //   lng: 75.588,
// // };

// // const MapComponent = () => {
// //   const [markerPosition, setMarkerPosition] = useState(defaultMarkerPosition);
// //   const [clickedLatLng, setClickedLatLng] = useState(null);

// //   const handleMapClick = (event) => {
// //     const clickedLatLng = {
// //       lat: event.latLng.lat(),
// //       lng: event.latLng.lng(),
// //     };

// //     // Update marker position
// //     setMarkerPosition(clickedLatLng);

// //     // Update clicked coordinates
// //     setClickedLatLng(clickedLatLng);
// //   };

// //   return (
// //     <LoadScript googleMapsApiKey="AIzaSyBHKhA_C31CAgVkzNWswBuhIjgve81O6Tw">
// //       <GoogleMap
// //         mapContainerStyle={containerStyle}
// //         center={center}
// //         zoom={15}
// //         onClick={handleMapClick}
// //       >
// //         {/* Marker (Picker) */}
// //         {markerPosition && <MarkerF position={markerPosition} />}

// //         {/* Display Clicked Coordinates */}
// //         {clickedLatLng && (
// //           <div style={{ position: 'absolute', top: 10, left: 10, backgroundColor: 'white', padding: 10 }}>
// //             <p>Clicked Coordinates:</p>
// //             <p>Latitude: {clickedLatLng.lat.toFixed(6)}</p>
// //             <p>Longitude: {clickedLatLng.lng.toFixed(6)}</p>
// //           </div>
// //         )}
// //       </GoogleMap>
// //     </LoadScript>
// //   );
// // };

// // export default MapComponent;

// MapComponent.js
// MapComponent.js
import React, { useState } from 'react';
import { GoogleMap, LoadScript, Marker } from '@react-google-maps/api';

const containerStyle = {
  width: '100%',
  height: '400px',
};

const center = {
  lat: 28.358665,
  lng: 75.588,
};

const MapComponent = () => {
  const [markers, setMarkers] = useState([]);

  const handleMapClick = (event) => {
    const clickedLatLng = {
      lat: event.latLng.lat(),
      lng: event.latLng.lng(),
    };

    // Add the clicked coordinates to the list of markers
    setMarkers((prevMarkers) => [...prevMarkers, clickedLatLng]);
  };

  const handleMarkerClick = (index) => {
    // Remove the marker when it is clicked twice
    setMarkers((prevMarkers) => {
      const updatedMarkers = [...prevMarkers];
      const markerToRemove = updatedMarkers[index];

      // Check if the marker is the last clicked one
      if (markerToRemove && markerToRemove.clickedOnce) {
        updatedMarkers.splice(index, 1);
      } else {
        // If not the last clicked, mark it as clicked once
        updatedMarkers[index] = { ...markerToRemove, clickedOnce: true };
      }

      return updatedMarkers;
    });
  };

  return (
    <LoadScript googleMapsApiKey="AIzaSyBHKhA_C31CAgVkzNWswBuhIjgve81O6Tw">
      <GoogleMap
        mapContainerStyle={containerStyle}
        center={center}
        zoom={15}
        onClick={handleMapClick}
      >
        {/* Display all markers with click handling */}
        {markers.map((marker, index) => (
          <Marker
            key={index}
            position={marker}
            icon={{
              url: 'https://maps.google.com/mapfiles/ms/icons/red-dot.png', // Customize marker icon
            }}
            onClick={() => handleMarkerClick(index)}
          />
        ))}
      </GoogleMap>
    </LoadScript>
  );
};

export default MapComponent;

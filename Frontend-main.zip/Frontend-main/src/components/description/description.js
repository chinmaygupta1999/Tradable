import {forwardRef} from 'react';
import SectionHeading from '../section-heading/section-heading';
import TextSection from '../text-section/text-section';
import './description.css';

const Description = forwardRef((props, ref) => {
    return (
        <div ref={ref}>
            <SectionHeading heading="Description" />
            <TextSection text={props.description}/>
        </div>
    )
})
export default Description;
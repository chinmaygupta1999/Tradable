import { useState, useRef, useEffect } from 'react';
import closeBtn from '../../images/close-modal-icon.svg';
import registrationFormIcon from '../../images/registration-form-icon.svg';
import axios from 'axios';
import pdfIcon from '../../images/pdf-icon.svg';
import deleteFileIcon from '../../images/delete-file-icon.svg';
import uploadingFileIcon from '../../images/upload-file-icon.svg';
import dropdownIcon from '../../images/dropdown-icon.svg';
import { getUploadSignedUrl } from '../../api/upload';
import {formatCurrencyIndianSystem} from '../../utils/property';
import {registerInAuction} from '../../api/registration';
import { useSelector } from 'react-redux';
import './registration-form.css';
import CustomInput from '../custom-input/custom-input';


const RegistrationFormSectionSeparator = (props) => {
    return (<div style={{ borderTop: "1px solid #D9D9D9", width: "100%", margin: "17px -20px 17px -20px", width: "calc(100% + 40px)" }}>
    </div>)
};
const RegistrationFormInputTitle = (props) => {
    return (
        <div className='registration-form-input-title'>
            {props?.text}
        </div>
    )
};

const RegistrationInput = (props) => {
    const [showDropDown, setShowDropDown] = useState(false);
    return (
        <div>
            <div className='registration-input-wrapper'>
                {
                    props?.hasDropDown && <div className="registration-input registration-input-dropdown" onClick={() => { setShowDropDown(!showDropDown); }}>
                        {props?.selectedItem}
                        <img src={dropdownIcon} />
                        {showDropDown && <div className='registration-input-dropdown-item-wrapper'>
                            {
                                props?.dropDownList.filter(item => item != props?.selectedItem).map(item => {
                                    return (<div className='registration-input-dropdown-item'
                                        onClick={() => { setShowDropDown(false); props?.setSelectedItem(item) }}>{item}</div>)
                                })
                            }
                        </div>}
                    </div>
                }
                <input className='registration-input'
                    placeholder={props?.placeholder}
                    value={props?.value}
                    onChange={props?.handleTextInputChange}>
                </input>
            </div>
            <div className='registration-form-input-error-message' style={props?.showErrorMessage ? { visibility: "visible" } : { visibility: "hidden" }}>
                {props?.errorMessage}
            </div>
        </div>
    )
};

const RegistrationInputBox = (props) => {
    return (<div style={{ display: "flex", justifyContent: "space-between", alignItems: "start", margin: "10px 0px" }}>
        <RegistrationFormInputTitle text={props.text} />
        <div style={{ width: "78%" }}>
            <CustomInput {...props} />
        </div>
    </div>);
};

const RegistrationUploadBox = (props) => {
    return (<div style={{ display: "flex", justifyContent: "space-between", alignItems: "start", margin: "10px 0px" }}>
        <RegistrationFormInputTitle text={props.text} />
        <div style={{ width: "78%" }}>
            <DocumentUploader {...props} />
        </div>
    </div>);
};

const DocumentUploader = (props) => {
    const fileInputRef = useRef(null);
    const [uploadPercentage, setUploadPercentage] = useState(0);
    const [fileName, setFileName] = useState('');
    const [fileSize, setFileSize] = useState('');
    const [signedUrl, setSignedUrl] = useState(null);
    const user = useSelector(state=>state.user);

    const formatFileSize = (sizeInBytes) => {
        const KB = 1024;
        const MB = KB * 1024;
        const GB = MB * 1024;

        if (sizeInBytes < KB) {
            return `${sizeInBytes} B`;
        } else if (sizeInBytes < MB) {
            return `${(sizeInBytes / KB).toFixed(2)} KB`;
        } else if (sizeInBytes < GB) {
            return `${(sizeInBytes / MB).toFixed(2)} MB`;
        } else {
            return `${(sizeInBytes / GB).toFixed(2)} GB`;
        }
    };
    const uploadFile = () => {
        if (fileInputRef.current) {
            fileInputRef.current.click();
            handleFileUpload();
        }
    };
    const handleFileUpload = async () => {
        const fileInput = fileInputRef.current;
        if (fileInput && fileInput.files.length > 0) {
            const file = fileInput.files[0];
            let userId = user?._id;
            const filePath = "/registration/"+ props?.auctionId + "/" + userId + "/" + file?.name; //TODO: change this
            let uploadSignedUrl = await getUploadSignedUrl(filePath);
            uploadSignedUrl = uploadSignedUrl?.data?.upload_signed_url;
            setSignedUrl(uploadSignedUrl);
            setFileName(file?.name);
            setFileSize(formatFileSize(file?.size));
            const options = {
                onUploadProgress: (progressEvent) => {
                    const percentage = Math.round((progressEvent.loaded * 100) / progressEvent.total);
                    setUploadPercentage(percentage);
                },
                headers: {
                    'Content-Type': 'application/pdf', // Adjust content type as needed
                },
            };
            if (uploadSignedUrl) {
                try {
                    // Use axios to make the PUT request with the signed URL
                    await axios.put(uploadSignedUrl, file, options);
                    props?.setUploadUrl(`https://storage.googleapis.com/tradable-public-bucket${filePath}`);
                } catch (error) {
                    console.error('Error uploading file:', error);
                    setUploadPercentage(0);
                }
            }
        };
    }
    const handleDeleteFile = async () => {
        if (uploadPercentage == 100) {
            setUploadPercentage(0);
            setFileName('');
            setFileSize('');
            props?.setUploadUrl(null);
        }
    }
    return (
        <div>
            <div className='registration-document-upload-section '>
                {uploadPercentage == 0 && <div className='document-upload-btn' onClick={uploadFile}>
                    Click here to upload
                    <div className='document-upload-btn-description'>
                        PDF File only
                    </div>
                    <input
                        type="file"
                        ref={fileInputRef}
                        style={{ display: 'none' }}
                        onInput={uploadFile}
                        accept="application/pdf"
                    />
                </div>}
                {uploadPercentage != 0 &&
                    <div style={{ display: "flex", justifyContent: "space-between", width: "100%" }}>
                        <div style={{ display: "flex" }}>
                            <div style={{ marginRight: "10px" }}>
                                <img src={pdfIcon} />
                            </div>
                            <div>
                                <div className='uploaded-file-name'>
                                    {fileName}
                                </div>
                                <div className='upload-file-description '>
                                    {fileSize} - {uploadPercentage}% uploaded
                                </div>
                            </div>
                        </div>
                        <div>
                            <img src={uploadPercentage != 100 ? uploadingFileIcon : deleteFileIcon}
                                style={{ cursor: "pointer" }}
                                onClick={handleDeleteFile} />
                        </div>
                    </div>
                }
            </div>
            <div className='registration-form-input-error-message' style={props?.showErrorMessage ? { visibility: "visible" } : { visibility: "hidden" }}>
                {props?.errorMessage}
            </div>
        </div>
    )
};

const RegistrationForm = (props) => {
    const [fullName, setFullName] = useState('');
    const [address, setAddress] = useState('');
    const [mobileNo, setMobileNo] = useState('');
    const [panNo, setPanNo] = useState('');
    const [accountNo, setAccountNo] = useState('');
    const [accountHolderName, setAccountHolderName] = useState('');
    const [IFSC, setIFSC] = useState('');
    const [addressProof, setAdressProof] = useState(null);
    const [bidderDetails, setBidderDetails] = useState(null);
    const [bidderDeclaration, setBidderDeclaration] = useState(null);
    const [bidderTrainingConfirmation, setBidderTrainingConfirmation] = useState(null);
    const [transactionId, setTransactionId] = useState('');
    const [transactionType, setTransactionType] = useState('NEFT');
    const [paymentConfimation, setPaymentConfimation] = useState(null);
    const [isSubmitEnabled, setIsSubmitEnabled] = useState(false);
    const [bidAmount, setBidAmount] = useState(null);
    const user = useSelector(state=>state.user);

    const handleNumberInputChange = (e) => {
        // Remove any non-numeric characters
        const sanitizedValue = e.target.value.replace(/\D/g, '');

        // Limit the input to 10 characters
        const trimmedValue = sanitizedValue.slice(0, 10);

        setMobileNo(trimmedValue);
    };
    
    const onSubmitClick = async () => {
        if(isSubmitEnabled)
        {   let data = {
            "user_id": user?._id,
            "auction_id": props?.auctionId,
            "address": address,
            "pan_no": panNo,
            "transaction_id": transactionId,
            "transaction_type": transactionType,
            "payment_proof_url": paymentConfimation,
            "address_proof_url": addressProof,
            "bidder_details_form_url": bidderDetails,
            "bidder_declaration_form_url": bidderDeclaration,
            "bidder_training_confirmation_form_url": bidderTrainingConfirmation,
            "price": {"value": bidAmount, "currency": "RUPEES"},
            "account_holder_name": accountHolderName,
            "account_no": accountNo,
            "ifsc_code": IFSC
            }
            let resp = await registerInAuction(data);
            if (resp?.data) {
                props?.setCtaText('Approval Pending');
                props?.closeModal();
            }
            else {
                console.log('Something went wrong', 'error');
            } 
        }
    };
    useEffect(() => {
        let fullNameValidation = !fullName.length <= 0;
        let addressValidation = !address.length <= 0;
        let mobileNoValidation = !(mobileNo.length < 10);
        let panNoValidation = /^[A-Z]{5}[0-9]{4}[A-Z]$/.test(panNo);
        let accountNoValidation = !accountNo.length <= 0;
        let accountHolderNameValidation = !accountHolderName.length <= 0;
        let IFSCValidation = !IFSC.length <= 0;
        let addressProofValidation = addressProof != null;
        let bidderDetailsValidation = bidderDetails != null;
        let bidderDeclarationValidation = bidderDeclaration != null;
        let bidderTrainingConfirmationValidation = bidderTrainingConfirmation != null;
        let transactionIdValidation = !transactionId.length <= 0;
        let transactionTypeValidation = true;
        let paymentConfimationValidation = paymentConfimation != null;
        let bidAmountValidation = bidAmount >= props?.reservePrice;
        setFullName(user?.user_name)
        setMobileNo(user?.phone_number)
        setIsSubmitEnabled(fullNameValidation && addressValidation && mobileNoValidation && panNoValidation && accountNoValidation && accountHolderNameValidation
            && IFSCValidation && addressProofValidation && bidderDetailsValidation && bidderDeclarationValidation && bidderTrainingConfirmationValidation && transactionIdValidation && transactionTypeValidation && paymentConfimationValidation && bidAmountValidation);
    })
    return (
        <div>
            <div style={{ display: "flex", justifyContent: "space-between" }}>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                    <img src={registrationFormIcon} style={{ marginRight: "8px" }} />
                    <div>
                        <div className='registration-from-heading'>Register to Bid</div>
                        <div className='registration-from-description'>
                            Complete your EMD payment to register for bidding
                        </div>
                    </div>
                </div>
                <img src={closeBtn} onClick={props.closeModal} style={{ cursor: "pointer" }} />
            </div>
            <RegistrationFormSectionSeparator />
            <div className='registration-form-scroll'>
                <div className='bank-account-details-section'>
                    <div className='bank-account-details-section-heading'>Bank account details for EMD Deposit</div>
                    <div className='bank-account-details-section-details'>
                        <div style={{ width: "95px" }}>Holder's Name</div>&nbsp;:&nbsp;<div>{props?.auctionData?.config?.beneficiary_name}</div>
                    </div>
                    <div className='bank-account-details-section-details'>
                        <div style={{ width: "95px" }}>Account No.</div>&nbsp;:&nbsp;<div>{props?.auctionData?.config?.bank_account_number}</div>
                    </div>
                    <div className='bank-account-details-section-details'>
                        <div style={{ width: "95px" }}>IFSC Code</div>&nbsp;:&nbsp;<div>{props?.auctionData?.config?.ifsc_code}</div>
                    </div>
                </div>
                <div className='registration-form-input-section'>
                    <RegistrationInputBox text="Full Name" placeholder="Enter your name" handleTextInputChange={(e) => setFullName(e.target.value)} value={fullName} showErrorMessage={fullName.length <= 0} errorMessage="Full name is mandatory" freezeInput={true}/>
                    <RegistrationInputBox text="Address" placeholder="Enter your address" handleTextInputChange={(e) => setAddress(e.target.value)} value={address} showErrorMessage={address.length <= 0} errorMessage="Address is mandatory" />
                    <RegistrationInputBox text="Mobile Number" placeholder="Enter your mobile number" handleTextInputChange={handleNumberInputChange} value={mobileNo} showErrorMessage={mobileNo.length < 10} errorMessage="10 Digit mobile no. is mandatory"  freezeInput={true} />
                    <RegistrationInputBox text="Pan Card Number" placeholder="Enter your pan card number" handleTextInputChange={(e) => setPanNo(e.target.value)} value={panNo} showErrorMessage={!/^[A-Z]{5}[0-9]{4}[A-Z]$/.test(panNo)} errorMessage="Valid PAN card number is mandatory" />
                    <RegistrationUploadBox text="Address Proof" setUploadUrl={setAdressProof} showErrorMessage={!addressProof} errorMessage="Address Proof is mandatory" auctionId={props?.auctionId}/>
                </div>
                <RegistrationFormSectionSeparator />
                <div>
                    <div className='amount-refund-section'>
                        Download & upload signed copy of following forms
                    </div>
                    <div>
                        <RegistrationUploadBox text="Bidder Details" setUploadUrl={setBidderDetails} showErrorMessage={!bidderDetails} errorMessage="This form is mandatory" auctionId={props?.auctionId}/>
                        <RegistrationUploadBox text="Declaration by Bidder" setUploadUrl={setBidderDeclaration} showErrorMessage={!bidderDeclaration} errorMessage="This form is mandatory" auctionId={props?.auctionId}/>
                        <RegistrationUploadBox text="Training Confirmation" setUploadUrl={setBidderTrainingConfirmation} showErrorMessage={!bidderTrainingConfirmation} errorMessage="This form is mandatory" auctionId={props?.auctionId}/>
                    </div>
                </div>
                <RegistrationFormSectionSeparator />
                <div>
                    <div className='amount-refund-section'>
                        Earnest money details (EMD)
                    </div>
                    <RegistrationInputBox text="Transaction Id" placeholder="Enter Transaction Id" handleTextInputChange={(e) => setTransactionId(e.target.value)} value={transactionId} showErrorMessage={transactionId.length <= 0} errorMessage="Transaction ID is mandatory" hasDropDown={true} dropDownList={["NEFT", "DD", "RTGS", "CHALLAN"]} selectedItem={transactionType} setSelectedItem={setTransactionType} />
                    <RegistrationUploadBox text="Payment Receipt" setUploadUrl={setPaymentConfimation} showErrorMessage={!paymentConfimation} errorMessage="Payment Confirmation is mandatory" auctionId={props?.auctionId}/>

                </div>
                <RegistrationFormSectionSeparator />
                <div>
                    <div className='amount-refund-section'>
                        Your refund bank account details
                    </div>
                    <RegistrationInputBox text="Account Holder Name" placeholder="Enter account holder's name" handleTextInputChange={(e) => setAccountHolderName(e.target.value)} value={accountHolderName} showErrorMessage={accountHolderName.length <= 0} errorMessage="Account holder's name is mandatory" />
                    <RegistrationInputBox text="Account Number" placeholder="Enter account number" handleTextInputChange={(e) => setAccountNo(e.target.value)} value={accountNo} showErrorMessage={accountNo.length <= 0} errorMessage="Account no. is mandatory" />
                    <RegistrationInputBox text="IFSC Code" placeholder="Enter IFSC code" handleTextInputChange={(e) => setIFSC(e.target.value)} value={IFSC} showErrorMessage={IFSC.length <= 0} errorMessage="IFSC code is mandatory" />
                </div>
                <RegistrationFormSectionSeparator />
                <div>
                    <div className='amount-refund-section'>
                        Pre-Auction Bid
                    </div>
                    <RegistrationInputBox text="Bid Amount" placeholder="Enter Bid Amount" handleTextInputChange={(e) => setBidAmount(e.target.value.replace(/\D/g, ''))} value={bidAmount} showErrorMessage={bidAmount < props?.reservePrice} errorMessage={`Bid amount should be more than reserve price i.e. Rs. ${formatCurrencyIndianSystem(props?.reservePrice)}`} />
                </div>
                <RegistrationFormSectionSeparator />
                <div className='registration-form-submit-btn' style={isSubmitEnabled ? {} : { background: "#ccc", color: "#ffffff", cursor: "not-allowed" }} onClick={onSubmitClick}>
                    Submit verification request
                </div>
            </div>
        </div>
    )
};
export default RegistrationForm;
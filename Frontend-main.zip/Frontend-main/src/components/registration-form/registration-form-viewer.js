import closeBtn from '../../images/close-modal-icon.svg';
import { useSelector } from 'react-redux';
import { useState, useEffect } from 'react';
import { formatCurrencyIndianSystem } from '../../utils/property';
import CustomInput from '../custom-input/custom-input';
import DocumentViewer from '../document-viewer/document-viewer';
import { changeApprovalStatus } from '../../api/registration';
import './registration-form.css';

const RegistrationFormSectionSeparator = (props) => {
    return (<div style={{ borderTop: "1px solid #D9D9D9", width: "100%", margin: "10px -20px 10px -20px", width: "calc(100% + 40px)" }}>
    </div>)
};

const RegistrationFormViewerInputBox = (props) => {
    return (
        <div>
            <div className='registration-form-input-title' style={{ margin: "15px 0px" }}>
                {props?.text}
            </div>
            <CustomInput {...props} />
        </div>
    )
}

const RegistrationFormViewerDocumentBox = (props) => {
    return (
        <div>
            <div className='registration-form-input-title' style={{ margin: "15px 0px" }}>
                {props?.text}
            </div>
            <DocumentViewer {...props} />
        </div>
    )
};

const RegistrationFormViewer = (props) => {
    console.log(props?.registrationDetails)
    const [fullName, setFullName] = useState(props?.registrationDetails?.user_name);
    const [address, setAddress] = useState(props?.registrationDetails?.address);
    const [mobileNo, setMobileNo] = useState(props?.registrationDetails?.phone_no);
    const [panNo, setPanNo] = useState(props?.registrationDetails?.pan_no);
    const [accountNo, setAccountNo] = useState(props?.registrationDetails?.account_no);
    const [accountHolderName, setAccountHolderName] = useState(props?.registrationDetails?.account_holder_name);
    const [IFSC, setIFSC] = useState(props?.registrationDetails?.ifsc_code);
    const [addressProof, setAdressProof] = useState(props?.registrationDetails?.address_proof_url);
    const [bidderDetails, setBidderDetails] = useState(null);
    const [bidderDeclaration, setBidderDeclaration] = useState(null);
    const [bidderTrainingConfirmation, setBidderTrainingConfirmation] = useState(null);
    const [transactionId, setTransactionId] = useState(props?.registrationDetails?.transaction_id);
    const [transactionType, setTransactionType] = useState('NEFT');
    const [paymentConfimation, setPaymentConfimation] = useState(null);
    const [isSubmitEnabled, setIsSubmitEnabled] = useState(false);
    const [bidAmount, setBidAmount] = useState(formatCurrencyIndianSystem(props?.registrationDetails?.price?.value));
    const user = useSelector(state => state.user);

    const onCtaClick = async (approvalStatus) => {
        await changeApprovalStatus(props?.registrationDetails?.user_id, props?.auctionId, approvalStatus, user?._id);
        props.closeModal();
    }

    return (
        <div style={{ width: "600px" }}>
            <div style={{ display: "flex", justifyContent: "space-between" }}>
                <div className='registration-from-heading'>View Details</div>
                <img src={closeBtn} onClick={props.closeModal} style={{ cursor: "pointer" }} />
            </div>
            <RegistrationFormSectionSeparator />
            <div className='registration-form-scroll'>
                <div className='registration-form-input-section'>
                    <RegistrationFormViewerInputBox text="Full Name" value={fullName} freezeInput={true} />
                    <RegistrationFormViewerInputBox text="Address" value={address} freezeInput={true} />
                    <RegistrationFormViewerInputBox text="Mobile Number" value={mobileNo} freezeInput={true} />
                    <RegistrationFormViewerInputBox text="Pan Card Number" value={panNo} freezeInput={true} />
                    <RegistrationFormViewerDocumentBox text="Address Proof" uploadUrl={addressProof} documentUrl="Address Proof.pdf" />
                </div>
                <RegistrationFormSectionSeparator />
                <div>
                    <div className='amount-refund-section'>
                        Signed copy of mandatory forms
                    </div>
                    <div>
                        <RegistrationFormViewerDocumentBox text="Bidder Details" uploadUrl={bidderDetails} documentUrl="Bidder Details.pdf" />
                        <RegistrationFormViewerDocumentBox text="Declaration by Bidder" uploadUrl={bidderDeclaration} documentUrl="Bidder Declaration.pdf" />
                        <RegistrationFormViewerDocumentBox text="Training Confirmation" uploadUrl={bidderTrainingConfirmation} documentUrl="Training Confirmation.pdf" />
                    </div>
                </div>
                <RegistrationFormSectionSeparator />
                <div>
                    <div className='amount-refund-section'>
                        Earnest money details (EMD)
                    </div>
                    <RegistrationFormViewerInputBox text="Transaction Id" value={transactionId} hasDropDown={true} dropDownList={["NEFT", "DD", "RTGS", "CHALLAN"]} selectedItem={transactionType} setSelectedItem={setTransactionType} freezeInput={true} />
                    {/* <RegistrationUploadBox text="Payment Receipt" setUploadUrl={setPaymentConfimation} showErrorMessage={!paymentConfimation} errorMessage="Payment Confirmation is mandatory" auctionId={props?.auctionId}/> */}

                </div>
                <RegistrationFormSectionSeparator />
                <div>
                    <div className='amount-refund-section'>
                        Your refund bank account details
                    </div>
                    <RegistrationFormViewerInputBox text="Account Holder Name" value={accountHolderName} freezeInput={true} />
                    <RegistrationFormViewerInputBox text="Account Number" value={accountNo} freezeInput={true} />
                    <RegistrationFormViewerInputBox text="IFSC Code" value={IFSC} freezeInput={true} />
                </div>
                <RegistrationFormSectionSeparator />
                <div>
                    <div className='amount-refund-section'>
                        Pre-Auction Bid
                    </div>
                    <RegistrationFormViewerInputBox text="Bid Amount" value={bidAmount} freezeInput={true} />
                </div>
                {props?.auctionStatus=="Upcoming"&&<div>
                    {props?.registrationDetails?.registration_status == "APPROVAL_PENDING" &&
                        <div>
                            <RegistrationFormSectionSeparator />
                            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", width: "100%" }}>
                                <div className='registration-form-submit-btn' style={{ width: '45%', marginRight: "10px", background: "#FFF7E6", color: "#344054" }} onClick={() => { onCtaClick("REJECTED") }}>
                                    Reject
                                </div>
                                <div className='registration-form-submit-btn' style={{ width: '45%' }} onClick={() => { onCtaClick("APPROVED") }}>
                                    Approve
                                </div>
                            </div>
                        </div>}

                    {props?.registrationDetails?.registration_status != "APPROVAL_PENDING" &&
                        <div>
                            <RegistrationFormSectionSeparator />
                            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", width: "100%" }}>
                                {props?.registrationDetails?.registration_status == "APPROVED" && <div className='registration-form-submit-btn' onClick={() => { onCtaClick("REJECTED") }}>
                                    Reject
                                </div>}
                                {props?.registrationDetails?.registration_status == "REJECTED" && <div className='registration-form-submit-btn' onClick={() => { onCtaClick("APPROVED") }}>
                                    Approve
                                </div>}
                            </div>
                        </div>}
                </div>}
            </div>
        </div>
    )
};
export default RegistrationFormViewer;
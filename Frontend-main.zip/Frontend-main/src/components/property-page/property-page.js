import { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import Header from '../header/header';
import Breadcrum from '../breadcrum/breadcrum';
import PropertyDetails from './property-details';
import AuctionDetails from './auction-details';
import ToastMessage from '../toast-message/toast-message';
import { getPropertyDetails } from '../../api/property';
import { getRegistrationDetails } from '../../api/registration';
import './property-page.css';
import Footer from '../footer/footer';
import AuctionResult from './auction-result';
import { useSelector } from 'react-redux';
import { getAuctionStatus } from '../../api/auction';
import AuctionConfig from './auction-config';

const PropertyPage = () => {
    const { propertyId } = useParams();
    const [showPropertyDetails, setShowPropertyDetails] = useState(true);
    const [isModalOpen, setModalOpen] = useState(false);
    const [propertyData, setPropertyData] = useState();
    const [auctionData, setAuctionData] = useState();
    const [isLoading, setIsLoading] = useState(true);
    const [toastVisible, setToastVisible] = useState(false);
    const [toastType, setToastType] = useState('');
    const [toastMessage, setToastMessage] = useState('');
    const [auctionId, setAuctionId] = useState();
    const [registrationDetails, setRegistrationDetails] = useState();
    const [isAuctionEnded, setIsAuctionEnded] = useState(false);
    const [selectedBreadcrum, setSelectedBreadcrum] = useState();
    const [isUserOwner, setIsUserOwner] = useState(false);
    const [auctionStatus, setAuctionStatus] = useState("Completed");
    const user = useSelector(state => state.user);

    const openModal = () => {
        setModalOpen(true);
    };

    const closeModal = () => {
        setModalOpen(false);
    };

    const getCtaText = () => {
        return "Place Bid Now";
    }

    useEffect(() => {
        const fetchData = async () => {
            let resp = await getPropertyDetails(propertyId);
            let userId = user?._id;
            if (userId) {
                setIsUserOwner(resp?.data?.property?.owner_id == userId);
                console.log(resp?.data?.propertyData?.owner_id, userId)
                let registrationDetails = await getRegistrationDetails(userId, resp?.data?.auction?._id);
                setRegistrationDetails(registrationDetails?.data);
            }
            setPropertyData(resp?.data?.property);
            setSelectedBreadcrum(resp?.data?.property?.name);
            setAuctionData(resp?.data?.auction);
            setAuctionId(resp?.data?.auction?._id);
            let auctionStatus = await getAuctionStatus(resp?.data?.auction?._id);
            setIsAuctionEnded(auctionStatus?.data?.auction_status == "Completed");
            setAuctionStatus(auctionStatus?.data?.auction_status);
            setIsLoading(false);
        };
        fetchData();
    }, [isModalOpen])

    return (
        <div>
            {isLoading ? <div>Loading...</div> : <div>
                <div className='page-alignment'>
                    <div className='page-config'>
                        <Breadcrum selectedBreadcrum={selectedBreadcrum} setSelectedBreadcrum={setSelectedBreadcrum} propertyName={propertyData?.name} isUserOwner={isUserOwner} />
                        {selectedBreadcrum == propertyData?.name ?
                            <PropertyDetails isUserOwner={isUserOwner} showActionBtn={showPropertyDetails} ctaText={getCtaText()} openModal={openModal} setShowPropertyDetails={setShowPropertyDetails} propertyData={propertyData} auctionData={auctionData} registrationDetails={registrationDetails} isAuctionEnded={isAuctionEnded} setSelectedBreadcrum={setSelectedBreadcrum}/>
                            : selectedBreadcrum == "Auction Configuration" ?
                                <AuctionConfig auctionId={auctionId} auctionData={auctionData} propertyData={propertyData} />
                                : auctionStatus=="Completed" && user &&  registrationDetails?.status == "APPROVED" ?<AuctionResult propertyData={propertyData} auctionData={auctionData} registrationDetails={registrationDetails} isUserOwner={isUserOwner}/>:<AuctionDetails auctionId={auctionId} auctionData={auctionData} propertyData={propertyData} registrationDetails={registrationDetails} totalRegisteredBidders={auctionData?.total_registrations} isUserOwner={isUserOwner} auctionStatus={auctionStatus} />}
                    </div>
                </div>
                {toastVisible && <ToastMessage
                    message={toastMessage}
                    type={toastType}
                    setToastVisible={setToastVisible}
                />}
            </div>}
        </div>
    )
}
export default PropertyPage;

import { useState, useEffect } from "react";
import "./property-page-navbar.css";

const PropertyPageNavbar = (props) => {
    const [selectedIndex, setSelectedIndex] = useState(0);
    const navbarHeight = 60;
    const scrollToComponent = (index) => {
        const elementPosition = props?.navbarItems[index]?.ref?.current.getBoundingClientRect().top + window.scrollY;
        const offset = elementPosition - navbarHeight;
        window.scrollTo({
            top: offset,
            behavior: 'smooth',
        });
    };
    useEffect(() => {
        const handleScroll = () => {
            const isInView = (element) => {
                const rect = element.getBoundingClientRect();
                return rect.top - navbarHeight <= 0;;
            };
            props?.navbarItems.forEach((element, index) => {
                if (isInView(props?.navbarItems[index]?.ref?.current)) {
                    setSelectedIndex(index);
                }
            });
        };

        // Attach the scroll event listener
        window.addEventListener('scroll', handleScroll);

        // Cleanup event listener
        return () => {
            window.removeEventListener('scroll', handleScroll);
        };
    }, []);
    return (
        <div className="property-navbar-container">
            {props?.navbarItems.map((item, index) => {
                return (<div className={selectedIndex == index ? "property-navbar-item property-navbar-item-selected" : "property-navbar-item"}
                    onClick={() => scrollToComponent(index)}
                >
                    {item?.name}
                </div>)
            })}
        </div>
    )
};
export default PropertyPageNavbar;
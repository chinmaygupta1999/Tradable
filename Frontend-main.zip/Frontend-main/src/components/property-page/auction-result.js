import React, { useEffect, useState } from 'react';
import currencyIcon from '../../images/currency-rupee.svg';
import DocumentUploader from '../document-uploader/document-uploader';
import CustomInput from '../custom-input/custom-input';
import disclaimerIcon from '../../images/disclaimer-icon.svg';
import { updateAuctionWinnerForm, getAuctionWinnerFormDetails } from '../../api/auction-winner-form';
import { getAuctionWinner, getBidDetails, getUserAuctionResult, getAuctionSummary } from '../../api/auction';
import editIcon from '../../images/edit-icon.svg';
import DocumentViewer from '../document-viewer/document-viewer';
import { useSelector } from 'react-redux';
import { formatCurrencyIndianSystem, numberToWords } from '../../utils/property';
import "./auction-result.css";

const SellerDetails = (props) => {
    return (
        <div className='auction-result-bid-details'>
            <div className='auction-result-seller-details'>
                Sellers Details
            </div>
            <div>
                <span className='auction-result-seller-details-title'>
                    Seller’s Name&nbsp;&nbsp;:&nbsp;&nbsp;
                </span>
                <span className='auction-result-seller-details-desc'>
                    {props?.auctionData?.config?.seller_name}
                </span>
            </div>
            <div>
                <span className='auction-result-seller-details-title'>
                    Mobile No&nbsp;&nbsp;:&nbsp;&nbsp;
                </span>
                <span className='auction-result-seller-details-desc'>
                    {props?.auctionData?.config?.seller_mobile_no}
                </span>
            </div>
            <div>
                <span className='auction-result-seller-details-title'>
                    Email Id&nbsp;&nbsp;:&nbsp;&nbsp;
                </span>
                <span className='auction-result-seller-details-desc'>
                    {props?.auctionData?.config?.seller_email}
                </span>
            </div>
            <div>
                <span className='auction-result-seller-details-title'>
                    Account No. &nbsp;&nbsp;:&nbsp;&nbsp;
                </span>
                <span className='auction-result-seller-details-desc'>
                    {props?.auctionData?.config?.bank_account_number}
                </span>
            </div>
            <div>
                <span className='auction-result-seller-details-title'>
                    IFSC Code&nbsp;&nbsp;:&nbsp;&nbsp;
                </span>
                <span className='auction-result-seller-details-desc'>
                    {props?.auctionData?.config?.ifsc_code}
                </span>
            </div>
        </div>
    );
};

const BuyerDetails = (props) => {
    return (
        <div className='auction-result-bid-details'>
            <div className='auction-result-seller-details'>
                Buyer Details
            </div>
            <div>
                <span className='auction-result-seller-details-title'>
                    Buyer’s Name&nbsp;&nbsp;:&nbsp;&nbsp;
                </span>
                <span className='auction-result-seller-details-desc'>
                    {props?.auctionSummary?.winner?.user_name}
                </span>
            </div>
            <div>
                <span className='auction-result-seller-details-title'>
                    Mobile No&nbsp;&nbsp;:&nbsp;&nbsp;
                </span>
                <span className='auction-result-seller-details-desc'>
                    {props?.auctionSummary?.winner?.user_phone_number}
                </span>
            </div>
        </div>
    );
};

const BidNotSuccessfull = (props) => {
    const [userHighestBid, setUserHighestBid] = useState();
    useEffect(() => {
        const fetchDetails = async () => {
            let bidDetails = await getBidDetails(props?.auctionId, props?.userId);
            setUserHighestBid(bidDetails?.data);
        }
        fetchDetails();
    })
    return (
        <div>
            <div className='auction-result-bid-details'>
                <div className='auction-result-bid-details-heading'>
                    <div>
                        Bid Details
                    </div>
                </div>
                <div className='auction-result-bid-details-sub-heading'>
                    <div style={{ width: "240px", display: "flex", justifyContent: "space-between" }}>
                        Winning Bid Amount
                        <span> &nbsp; &nbsp;:&nbsp; &nbsp; ₹ {formatCurrencyIndianSystem(props?.auctionWinner?.price?.value)}</span>
                    </div>
                </div>
                <div className='auction-result-bid-details-sub-heading'>
                    <div style={{ width: "245px", display: "flex", justifyContent: "space-between" }}>
                        Your Highest Bid
                        <span>&nbsp; &nbsp;:&nbsp; &nbsp; ₹ {formatCurrencyIndianSystem(userHighestBid?.auction_highest_bid?.price?.value)}</span>
                    </div>
                </div>
                <div className='auction-result-bid-details-sub-heading'>
                    <div style={{ width: "260px", display: "flex", justifyContent: "space-between" }}>
                        Your Rank
                        <span>&nbsp; &nbsp;:&nbsp; &nbsp;{props?.userRank}</span>
                    </div>
                </div>
            </div>
            <div className='auction-result-whats-next'>
                Whats next?
            </div>
            <div className='auction-result-whats-next-desc'>
                EMD will be refunded within 15 business days in the account mentioned below
            </div>
            <div className='auction-result-refund-account-details' style={{ marginTop: "10px" }}>
                <div style={{ width: "250px", display: "flex", justifyContent: "start" }}>
                    Account Holder Name&nbsp;:&nbsp;
                    <span> {props?.registrationDetails?.account_holder_name}</span>
                </div>
                <div style={{ width: "200px", display: "flex", justifyContent: "start" }}>
                    Account No.&nbsp;:&nbsp;
                    <span> {props?.registrationDetails?.account_no}</span>
                </div>
                <div style={{ width: "200px", display: "flex", justifyContent: "start" }}>
                    IFSC Code&nbsp;: &nbsp;
                    <span> {props?.registrationDetails?.ifsc_code}</span>
                </div>
            </div>
        </div>
    )
};

const SubmitBtn = (props) => {
    return (
        <div className='auction-result-submit-btn' style={props?.isDisabled ? { background: "#ccc", color: "#ffffff", cursor: "not-allowed" } : {}}
            onClick={props?.isDisabled ? () => { } : props?.onSubmitClick}>
            Submit
        </div>
    )
};

const EditBtn = (props) => {
    const [isVisible, setIsVisible] = useState(true);
    return (
        <div>
            {isVisible && <div style={{ cursor: "pointer" }} onClick={() => { setIsVisible(false); props?.onEditClick(); }}>
                <img src={editIcon} style={{ width: "15px", marginRight: "2px" }} />
                <span className='auction-result-edit-text'>Edit</span>
            </div>}
        </div>
    )
}

const BidSuccessfull = (props) => {
    const [priceConfirmationForm, setPriceConfirmationForm] = useState(null);
    const [receiptNumber, setReceiptNumber] = useState('');
    const [receiptType, setReceiptType] = useState();
    const [paymentReceipt, setPaymentReceipt] = useState(null);
    const [showPriceConfirmationForm, setShowPriceConfirmationForm] = useState(false);
    const [showReceiptNumber, setShowReceiptNumber] = useState(false);
    const [showPaymentReceipt, setShowPaymentReceipt] = useState(false);
    const user = useSelector(state => state.user);
    const onSubmitClick = async () => {
        await updateAuctionWinnerForm({
            "user_id": user?._id,
            "auction_id": props?.auctionId,
            "transaction_id": receiptNumber,
            "transaction_type": receiptType,
            "price_confirmation_url": priceConfirmationForm,
            "advance_payment_receipt_url": paymentReceipt
        })
        setShowPriceConfirmationForm(true);
        setShowReceiptNumber(true);
        setShowPaymentReceipt(true);
    };
    const isSubmitDisabled = () => {
        if (priceConfirmationForm !== null && paymentReceipt !== null && receiptNumber?.length > 0) {
            return false;
        } else {
            return true;
        }
    };

    useEffect(() => {
        const fetchDetails = async () => {
            const resp = await getAuctionWinnerFormDetails(user?._id, props?.auctionId);
            setPriceConfirmationForm(resp?.data?.price_confirmation_url);
            setReceiptNumber(resp?.data?.transaction_id);
            setReceiptType(resp?.data?.transaction_type);
            setPaymentReceipt(resp?.data?.advance_payment_receipt_url);
            if (resp?.data?._id) { setShowPriceConfirmationForm(true); setShowReceiptNumber(true); setShowPaymentReceipt(true); }
        };
        fetchDetails();
    }, []);

    useEffect(() => {
        if (!receiptType) {
            setReceiptType("NEFT");
        }
    })

    return (
        <div>
            <div className='auction-result-bid-details'>
                <div className='auction-result-winner-heading'>
                    Winning Bid amount
                </div>
                <div style={{ display: "flex", alignItems: "baseline" }}>
                    <img src={currencyIcon} style={{ width: "25px" }} />
                    <div>
                        <div className='auction-result-winning-amount'>
                            {formatCurrencyIndianSystem(props?.auctionWinner?.price?.value)}
                        </div>

                        <div className='auction-result-winning-amount-words'>
                            {numberToWords(props?.auctionWinner?.price?.value)}
                        </div>
                    </div>
                </div>
            </div>
            <div className='auction-result-payment-terms-section'>
                <div className='auction-result-payment-terms-title'>
                    Payment terms: Pay the following amount in 24 hour
                </div>
                <div className='auction-result-payment-terms-sub-title'>
                    <span>25% of final price</span> = <span style={{ color: "#262626" }}>₹ {formatCurrencyIndianSystem(Math.round(0.25 * props?.auctionWinner?.price?.value))}</span>
                </div>
                <div className='auction-result-payment-terms-sub-title'>
                    <span>Amount received</span> = <span style={{ color: "#262626" }}>₹ {formatCurrencyIndianSystem(props?.auctionData?.config?.emd?.value)} (EMD)</span>
                </div>
                <div className='auction-result-payment-amount'>
                    <span> Amount to pay </span>= <span style={{ color: "#262626" }}>₹ {formatCurrencyIndianSystem(Math.round(0.25 * props?.auctionWinner?.price?.value) - props?.auctionData?.config?.emd?.value)}</span>
                </div>
            </div>
            <div>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                    <div className='auction-result-input-title'>
                        Upload signed copy of price confirmation form
                    </div>
                    <div style={showPriceConfirmationForm ? {} : { visibility: "hidden" }}>
                        <EditBtn onEditClick={() => { setShowPriceConfirmationForm(false); setPriceConfirmationForm(null); }} />
                    </div>
                </div>
                {!showPriceConfirmationForm && <DocumentUploader setUploadUrl={setPriceConfirmationForm} auctionId={props?.auctionId} showErrorMessage={false} errorMessage="" />}
                {showPriceConfirmationForm && <DocumentViewer documentUrl={"Price Conformation Form.pdf"} uploadUrl={priceConfirmationForm} />}
            </div>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                <div className='auction-result-input-title'>
                    Receipt Number
                </div>
                <div style={showPriceConfirmationForm ? {} : { visibility: "hidden" }}>
                    <EditBtn onEditClick={() => { setShowReceiptNumber(false); setReceiptNumber(''); }} />
                </div>
            </div>
            <div>
                <CustomInput freezeInput={showReceiptNumber} placeholder="Enter Receipt Number" handleTextInputChange={(e) => setReceiptNumber(e.target.value)} value={receiptNumber} showErrorMessage={false} errorMessage="" hasDropDown={true} dropDownList={["NEFT", "DD", "RTGS", "CHALLAN"]} selectedItem={receiptType} setSelectedItem={setReceiptType} />
            </div>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                <div className='auction-result-input-title'>
                    Upload Receipt
                </div>
                <div style={showPaymentReceipt ? {} : { visibility: "hidden" }}>
                    <EditBtn onEditClick={() => { setPaymentReceipt(null); setShowPaymentReceipt(false); }} />
                </div>
            </div>
            {!showPaymentReceipt && <DocumentUploader DocumentUploader setUploadUrl={setPaymentReceipt} auctionId={props?.auctionId} showErrorMessage={false} errorMessage="" />}
            {showPaymentReceipt && <DocumentViewer documentUrl={"Remaining Amount Receipt.pdf"} uploadUrl={paymentReceipt} />}
            {!(showPriceConfirmationForm && showReceiptNumber && showPaymentReceipt) && <SubmitBtn isDisabled={isSubmitDisabled()} onSubmitClick={onSubmitClick} />}
        </div>
    )
};

const SellerAuctionResult = (props) => {
    const [priceConfirmationForm, setPriceConfirmationForm] = useState();
    const [paymentReceipt, setPaymentReceipt] = useState();
    const [receiptNumber, setReceiptNumber] = useState();
    const [receiptType, setReceiptType] = useState('NEFT');
    const [showAuctionWinnerFormDetails, setShowAuctionWinnerFormDetails] = useState(false);

    useEffect(() => {
        const fetchDetails = async () => {
            const resp = await getAuctionWinnerFormDetails(props?.auctionWinner?.user_id, props?.auctionData?._id);
            setPriceConfirmationForm(resp?.data?.price_confirmation_url);
            setReceiptNumber(resp?.data?.transaction_id);
            setReceiptType(resp?.data?.transaction_type);
            setPaymentReceipt(resp?.data?.advance_payment_receipt_url);
            if (resp?.data?._id) { setShowAuctionWinnerFormDetails(true); }
        };
        fetchDetails();
    }, [props]);
    return (
        <div>
            <div className='seller-auction-result-wrapper'>
                <div className='seller-auction-result-heading'>
                    BID DETAILS
                </div>
                <div className='seller-auction-result-winning-bid-heading'>
                    Winning Bid Amount : <span style={{ color: "#262626" }}>₹ {formatCurrencyIndianSystem(props?.auctionSummary?.winning_bid?.value)}</span>
                </div>
                <div style={{ display: "flex", width: "240px", justifyContent: "space-between", alignItems: "center" }}>
                    <div className='seller-auction-result-data-points'>
                        Total Bids: <span style={{ fontWeight: "600" }}>{props?.auctionSummary?.total_bids}</span>
                    </div>
                    <div style={{ borderLeft: "solid 1px #BFBFBF", width: "7px", height: "14px" }}>

                    </div>
                    <div className='seller-auction-result-data-points'>
                        Total Bidders: <span style={{ fontWeight: "600" }}>{props?.auctionSummary?.total_bidders}</span>
                    </div>
                </div>
            </div>
            <div className='seller-auction-result-wrapper' style={{ marginTop: "10px" }}>
                <div className='seller-auction-result-heading'>
                    Payment terms
                </div>
                <div className='auction-result-payment-terms-sub-title'>
                    <span>25% of final price</span> = <span style={{ color: "#262626" }}>₹ {formatCurrencyIndianSystem(Math.round(0.25 * props?.auctionSummary?.winning_bid?.value))}</span>
                </div>
                <div className='auction-result-payment-terms-sub-title'>
                    <span>Amount received</span> = <span style={{ color: "#262626" }}>₹ {formatCurrencyIndianSystem(props?.auctionData?.config?.emd?.value)} (EMD)</span>
                </div>
                <div className='auction-result-payment-amount'>
                    <span> Amount to pay </span>= <span style={{ color: "#262626" }}>₹ {formatCurrencyIndianSystem(Math.round(0.25 * props?.auctionSummary?.winning_bid?.value) - props?.auctionData?.config?.emd?.value)}</span>
                </div>
            </div>
            {showAuctionWinnerFormDetails && <div>
                <div style={{ marginTop: "10px" }}>
                    <div className='auction-result-input-title'>
                        Price confirmation form
                    </div>
                    <DocumentViewer documentUrl={"Price Conformation Form.pdf"} uploadUrl={priceConfirmationForm} />
                </div>

                <div style={{ marginTop: "10px" }}>
                    <div className='auction-result-input-title'>
                        Receipt Number
                    </div>
                    <CustomInput freezeInput={true} placeholder="Enter Receipt Number" handleTextInputChange={(e) => setReceiptNumber(e.target.value)} value={receiptNumber} showErrorMessage={false} errorMessage="" hasDropDown={true} dropDownList={["NEFT", "DD", "RTGS", "CHALLAN"]} selectedItem={receiptType} />
                </div>

                <div style={{ marginTop: "10px" }}>
                    <div className='auction-result-input-title'>
                        Remaining amount receipt
                    </div>
                    <DocumentViewer documentUrl={"Remaining Amount Receipt.pdf"} uploadUrl={paymentReceipt} />
                </div>
            </div>}
        </div>
    )
};

const AuctionResult = (props) => {
    const [imgUrl, setImgUrl] = useState([]);
    const [isUserWinner, setIsUserWinner] = useState(false);
    const [auctionWinner, setAuctionWinner] = useState();
    const [userRank, setUserRank] = useState();
    const [auctionSummary, setAuctionSummary] = useState();
    const user = useSelector(state => state.user);
    useEffect(() => {
        const propertyImages = props?.propertyData?.property_images;
        const sortedFloors = Object.keys(propertyImages).sort((a, b) => {
            return propertyImages[a].order - propertyImages[b].order;
        });

        // Create a new object with sorted floors
        const sortedPropertyImages = {};
        sortedFloors.forEach(floor => {
            sortedPropertyImages[floor] = propertyImages[floor].url_list;
        });
        const valuesArray = Object.values(sortedPropertyImages).flat();
        const updatedObject = { All: valuesArray, ...sortedPropertyImages };
        setImgUrl(updatedObject?.All);
        const fetchData = async () => {
            const auctionWinner = await getAuctionWinner(props?.auctionData?._id);
            setAuctionWinner(auctionWinner?.data);
            setIsUserWinner(auctionWinner?.data?.user_id == user?._id);
            const userRank = await getUserAuctionResult(props?.auctionData?._id, user?._id);
            setUserRank(userRank?.data?.user_rank);
            const resp = await getAuctionSummary(props?.auctionData?._id, user?._id);
            setAuctionSummary(resp?.data);
        }
        fetchData();
    }, []);

    return (
        <div className="auction-result-container" style={{marginBottom: "20px"}}>
            <div className='auction-result-heading '>
                {props?.isUserOwner ? <div>Congratulations! Auction has been successfully concluded</div> :
                    <div>
                        {isUserWinner && <div>Congratulations! You won the Auction</div>}
                        {!isUserWinner && <div>Oops, your bid was not successful.</div>}
                    </div>}
            </div>
            <div className="auction-result-section ">
                <div className="auction-result-img-section">
                    <img className="auction-result-img" src={imgUrl[0]} />
                    {(isUserWinner || props?.isUserOwner) && <div>
                        {isUserWinner && <div style={{ display: "flex", alignItems: "center" }}>
                            <img src={disclaimerIcon} style={{ margin: "0px 4px 10px 0px" }} />
                            <span className='auction-result-disclaimer'>
                                <span style={{ color: "#434343", fontWeight: 600 }}>Note:</span> Contact Bank for making remaining payment
                            </span>
                        </div>}
                        {props?.isUserOwner ? <div style={{ marginTop: "10px" }}><BuyerDetails auctionSummary={auctionSummary} /></div> : <SellerDetails auctionData={props?.auctionData} />}
                    </div>}
                </div>
                <div className="auction-result-display-section">
                    {
                        props?.isUserOwner ? <SellerAuctionResult auctionSummary={auctionSummary} auctionData={props?.auctionData} auctionWinner={auctionWinner} /> :
                            <div>
                                {!isUserWinner && <BidNotSuccessfull auctionId={props?.auctionData?._id} userId={user?._id} auctionWinner={auctionWinner} registrationDetails={props?.registrationDetails} userRank={userRank} />}
                                {isUserWinner && <BidSuccessfull auctionId={props?.auctionData?._id} auctionWinner={auctionWinner} auctionData={props?.auctionData} />}
                            </div>
                    }
                </div>
            </div>
        </div>
    )
};

export default AuctionResult;
import { useEffect, useState } from 'react';
import { getBidList } from '../../api/auction';
import Table from '../table/table';
import io from 'socket.io-client';
import API_DOMAIN from '../../constants';
import locationLogo from '../../images/location-icon.svg';
import currencyIcon from '../../images/currency-rupee.svg';
import orangeCalendar from '../../images/calendar-orange-icon.svg';
import { datetimeFromTimestamp, formatCurrencyIndianSystem } from "../../utils/property";
import ToggleButton from '../toggle/toggle';
import "./auction-details.css";
import Modal from 'react-modal';
import RegistrationForm from '../registration-form/registration-form';
import PlaceBidModal from '../place-bid-modal/place-bid-modal';
import { checkIfBiddingAllowed, getUserAuctionResult } from '../../api/auction';
import { useSelector } from 'react-redux';

const AuctionDisplay = (props) => {
    return (
        <div className='auction-display'>
            <div className='auction-display-section'>
                <div className='auction-display-img'>
                    <img className="auction-display-img" src="https://storage.cloud.google.com/tradable-public-bucket/Rectangle%201140%20(1).jpg?authuser=1" />
                </div>
                <div className='auction-display-detail-section'>
                    <div style={{ display: "flex", justifyContent: "space-between" }}>
                        <div className='auction-display-main-heading'>
                            {props?.propertyData?.name}
                        </div>
                        {props?.isBiddingAllowed && <div className='place-bid-btn' onClick={() => props?.setIsBiddingModalOpen(true)}>
                            <img src={orangeCalendar} className="icons" />
                            <div>Place Bid</div>
                        </div>}
                    </div>

                    <div className='auction-display-address'>
                        <img src={locationLogo} style={{ marginRight: "10px" }} /> {props?.propertyData?.address}
                    </div>
                    <div className='auction-display-details'>
                        <div>Total Registered Bidders : <span>{props.totalRegisteredBidders}</span></div>
                        <div>Starting Details : <span>{datetimeFromTimestamp(props?.auctionData?.config?.start_time * 1000)}</span></div>
                        <div>Ending Details : <span>{datetimeFromTimestamp(props?.auctionData?.config?.end_time * 1000)}</span></div>
                        <div style={{ display: "flex", alignItems: "center" }}>Reserve Price : <span><img src={currencyIcon} style={{ height: "15px", width: "15px" }} />{formatCurrencyIndianSystem(props?.auctionData?.config?.price?.value)}</span></div>
                    </div>
                    <AuctionBanner bidList={props?.bidList} auctionData={props?.auctionData} listingPrice={props?.listingPrice} />
                </div>
            </div>
            <div className='auction-display-disclaimer'>
                Disclaimer - The property is sold "as-is, where-is" and no warranties or representations are made regarding its condition, including any potential for future returns, profitability, or performance so the Buyer is recommended to do his due diligence in researching the property prior to bidding  etc
            </div>
        </div>

    )
};

const CountdownTimer = ({ targetDate }) => {
    const calculateTimeLeft = () => {
        const now = new Date().getTime();
        const difference = targetDate - now;

        if (difference > 0) {
            const days = Math.floor(difference / (1000 * 60 * 60 * 24));
            const hours = Math.floor((difference % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
            const minutes = Math.floor((difference % (1000 * 60 * 60)) / (1000 * 60));
            const seconds = Math.floor((difference % (1000 * 60)) / 1000);
            return { days, hours, minutes, seconds };
        } else {
            return { days: 0, hours: 0, minutes: 0, seconds: 0 };
        }
    };

    const [timeLeft, setTimeLeft] = useState(calculateTimeLeft());

    useEffect(() => {
        const timerInterval = setInterval(() => {
            setTimeLeft(calculateTimeLeft());
        }, 1000);

        return () => {
            clearInterval(timerInterval);
        };
    }, [targetDate]);

    return (
        <div className='auction-primary-text'>
            <div>
                <div>{timeLeft.days}</div>
                <div className='auction-secondary-text'>
                    d
                </div>
            </div>
            <div>:</div>
            <div>
                <div>{timeLeft.hours}</div>
                <div className='auction-secondary-text'>hrs</div>
            </div>
            <div>:</div>
            <div>
                <div>{timeLeft.minutes}</div>
                <div className='auction-secondary-text'>min</div>
            </div>
            <div>:</div>
            <div>
                <div>{timeLeft.seconds}</div>
                <div className='auction-secondary-text'>sec</div>
            </div>
        </div>
    );
};

const AuctionBanner = (props) => {
    const [timerConfig, setTimerConfig] = useState();
    const getTimerConfig = (auctionConfig) => {
        const currentTime = Math.floor(Date.now() / 1000);
        let targetDate;
        let timerText = "";
        if (currentTime < auctionConfig.start_time) {
            targetDate = auctionConfig.start_time * 1000;
            timerText = "Auction starts in (IST)"
        } else {
            targetDate = auctionConfig.end_time * 1000;
            timerText = "Auction ends in (IST)"
        }
        setTimerConfig({
            timerText,
            targetDate
        })
    };
    useEffect(() => {
        getTimerConfig(props?.auctionData?.config)
    }, [])
    return (
        <div className='auction-banner'>
            <div className='auction-banner-card'>
                <div>
                    <div className='auction-banner-card-title'>
                        Highest Bid
                    </div>
                    <div className='auction-primary-text' style={{ display: "block" }}>
                        {props?.bidList[0]?.price?.value && <div>
                            <img src={currencyIcon} style={{ height: "15px", width: "15px" }} /> {props?.bidList[0]?.price?.value}
                        </div>}
                        {
                            !props?.bidList[0]?.price?.value && <div>
                                -
                            </div>
                        }
                    </div>
                </div>
                <div>
                    <div className='auction-banner-card-title'>
                        Minimum Increment Amount
                    </div>
                    <div className='auction-primary-text' style={{ display: "block" }}>
                        <img src={currencyIcon} style={{ height: "15px", width: "15px" }} /> {props?.auctionData?.config?.min_bid_increment?.value}
                    </div>
                </div>
            </div>
            <div className='auction-banner-card' style={{ marginLeft: "15px" }}>
                <div className='auction-banner-card-title'>
                    {timerConfig?.timerText}
                </div>
                <div>
                    <CountdownTimer targetDate={timerConfig?.targetDate} />
                </div>
            </div>
        </div>
    )
};

const RegistrationStatus = (props) => {
    const [approvalStatusMapping, setApprovalStatusMapping] = useState({
        "NOT_REGISTERED": "Not Registered",
        "APPROVAL_PENDING": "Approval Pending",
        "APPROVED": "Approved",
        "REJECTED": "Rejected"
    });
    const [isModalOpen, setIsModalOpen] = useState(false);
    const openModal = () => {
        setIsModalOpen(true);
        document.body.style.overflow = 'hidden';
    };
    const closeModal = () => {
        setIsModalOpen(false);
        document.body.style.overflow = 'auto';
    }
    useEffect(() => {

    });
    return (
        <div className='auction-details-registration-section'>
            <div className='auction-details-registration-section-heading'>
                {props?.isBiddingAllowed ? <div>Bidding Status</div> : <div>Registration Status</div>}
            </div>
            {!props?.isBiddingAllowed && <div style={{ borderTop: "1px solid #D9D9D9", width: "100%", margin: "0px -24px 0px -24px", width: "calc(100% + 48px)" }}>
            </div>}
            {props?.isBiddingAllowed ? <div>
                <div className='auction-details-registration-status-description' style={{ color: "#595959", fontSize: "18px", fontWeight: "400" }}>Your Previous Bid : ₹ {formatCurrencyIndianSystem(props?.userHighestBid?.value)}</div>
                <div className='auction-details-registration-status-description' style={{ color: "#595959", fontSize: "18px", fontWeight: "400" }}>Your Rank : <span style={{ color: "#E13629", fontWeight: "600" }}>{props?.userRank}</span></div>
            </div> : <div className='auction-details-registration-section-heading' style={{ color: "#595959", fontSize: "18px", fontWeight: "400" }}>
                Registration Status :
                <span className='auction-details-registration-status'>
                    {approvalStatusMapping[props?.registrationDetails?.registration_status]}
                </span>
            </div>}
            {!props?.isBiddingAllowed && <div className='auction-details-registration-status-description'>
                You will be allowed to place your bid once the auction starts
            </div>}
            {props?.isBiddingAllowed && <div className='place-bid-btn' style={{ width: "-webkit-fill-available" }} onClick={() => props?.setIsBiddingModalOpen(true)}>
                <img src={orangeCalendar} className="icons" />
                <div>Place Bid</div>
            </div>}
            {props?.registrationDetails?.registration_status == "NOT_REGISTERED" && <div className='auction-details-registration-cta' onClick={openModal}>
                Register to bid
            </div>}
            {isModalOpen && <Modal
                isOpen={isModalOpen}
                className="registration-modal"
                overlayClassName="overlay"
            >
                <RegistrationForm closeModal={closeModal} auctionId={props?.auctionData?._id} reservePrice={props?.auctionData?.config?.price?.value} />
            </Modal>}
        </div>
    )
};

const AutomaticBidding = (props) => {
    const [bid, setBid] = useState('');
    const [isToggleDisabled, setisToggleDisabled] = useState(true);
    const handleInputChange = (e) => {
        // Remove any non-numeric characters
        const sanitizedValue = e.target.value.replace(/\D/g, '');

        setBid(sanitizedValue);
        if (sanitizedValue.length > 0) {
            setisToggleDisabled(false);
        } else {
            setisToggleDisabled(true);
        }
    };
    return (
        <div className='auction-details-registration-section'>
            <div className='auction-details-registration-section-heading' style={{ width: "100%", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                Automatic Bidding
                <ToggleButton isToggled={!isToggleDisabled} setToggled={setisToggleDisabled} />
            </div>
            <div className='auction-details-registration-status-description'>
                Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua
            </div>
            <div className='auction-automatic-bidding-input-label'>
                Input Max Bid
            </div>
            <div className='auction-automatic-bidding-input-section'>
                <img src={currencyIcon} style={{ height: "13px", width: "13px" }} />
                <input className='auction-automatic-bidding-input'
                    placeholder='Enter bid in INR'
                    value={bid}
                    onChange={handleInputChange}
                    disabled={isToggleDisabled}
                />
            </div>
            <div className='auction-details-registration-cta' style={isToggleDisabled ? { "background": "#cccccc", "cursor": "not-allowed" } : {}}>
                Submit
            </div>
        </div>
    )
};

const AuctionDetails = (props) => {
    const totalRecordsPerPage = 11;
    const [pageNo, setPageNo] = useState(1);
    const [totalPage, setTotalPage] = useState(1);
    const [bidList, setBidList] = useState([]);
    const [isBiddingAllowed, setIsBiddingAllowed] = useState(false);
    const user = useSelector(state => state.user);
    const [isBiddingModalOpen, setIsBiddingModalOpen] = useState(false);
    const [userHighestBid, setUserHighestBid] = useState();
    const [userRank, setUserRank] = useState();

    useEffect(() => {
        const fetchData = async () => {
            const bidList = await getBidList(props?.auctionId, (pageNo - 1) * totalRecordsPerPage, totalRecordsPerPage);
            const isBiddingAllowed = await checkIfBiddingAllowed(props?.auctionData?._id, user?._id);
            const userAuctionResult = await getUserAuctionResult(props?.auctionData?._id, user?._id);
            setIsBiddingAllowed(isBiddingAllowed?.data?.is_bidding_allowed);
            setBidList(bidList?.data?.bid_list);
            setUserHighestBid(userAuctionResult?.data?.user_highest_bid);
            setUserRank(userAuctionResult?.data?.user_rank);
            setTotalPage(Math.ceil(bidList?.data?.total_bids / totalRecordsPerPage))
        };
        fetchData();

        // Connect to the Socket.IO server
        const socket = io(API_DOMAIN);
        socket.on('bid_update', function (msg) {
            setPageNo(1);
            fetchData();
        })
        // Clean up the socket connection on component unmount
        return () => {
            socket.disconnect();
        };
    }, [])

    const fetchTableData = async (pageNo) => {
        const bidList = await getBidList(props?.auctionId, (pageNo - 1) * totalRecordsPerPage, totalRecordsPerPage);
        setPageNo(pageNo);
        setBidList(bidList?.data?.bid_list);
        setTotalPage(Math.ceil(bidList?.data?.total_bids / totalRecordsPerPage))
    }

    return (<div>
        <AuctionDisplay totalRegisteredBidders={props?.totalRegisteredBidders} bidList={bidList} auctionData={props?.auctionData} propertyData={props?.propertyData} listingPrice={props?.propertyData?.price?.value} isBiddingAllowed={isBiddingAllowed} setIsBiddingModalOpen={setIsBiddingModalOpen} />
        <div style={{ display: "flex", justifyContent: "space-between", marginTop: "20px" }}>
            <div className='auction-details-table-section' style={props?.isUserOwner || !props?.registrationDetails ? { width: "100%" } : {}}>
                <Table bidTableHeading={['Bidder Details', 'Bid Amount', 'Increment Amount', 'Bid Time']} bidTableData={bidList} currentPage={pageNo} totalPage={totalPage} fetchTableData={fetchTableData} auctionData={props?.auctionData} isUserOwner={props?.isUserOwner} auctionStatus={props?.auctionStatus}/>
            </div>
            {!props?.isUserOwner && <div style={{ display: "flex", flexDirection: "column" }}>
                {user&&<RegistrationStatus {...props} isBiddingAllowed={isBiddingAllowed} setIsBiddingModalOpen={setIsBiddingModalOpen} userHighestBid={userHighestBid} userRank={userRank} />}
                {/* <AutomaticBidding /> */}
            </div>}
        </div>
        {
            isBiddingModalOpen && <Modal
                isOpen={isBiddingModalOpen}
                className="modal"
                overlayClassName="overlay"
            >
                <PlaceBidModal auctionId={props?.auctionData?._id} isModalOpen={setIsBiddingModalOpen} auctionData={props?.auctionData} />
            </Modal>
        }
    </div>)
};
export default AuctionDetails;
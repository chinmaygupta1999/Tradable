import { useRef } from 'react';
import PropertyPageNavbar from './property-page-navbar';
import Overview from '../overview/overview';
import Description from '../description/description';
import SectionSeparator from '../section-separator/section-separator';
import Amenities from '../amenities/amenities';
import Location from '../location/location';
import Documents from '../documents/documents';
import Frame from '../image-frame/frame';
import Heading from '../heading/heading';
import SellerInfo from '../seller-info/seller-info';

const PropertyDetails = (props) => {
    const overviewRef = useRef(null);
    const descriptionRef = useRef(null);
    const bankDetailsRef = useRef(null);
    const amenitiesRef = useRef(null);
    const documentsRef = useRef(null);
    const locationRef = useRef(null);
    const navbarItems = [{ name: 'Overview', ref: overviewRef }, { name: 'Description', ref: descriptionRef }, {name: 'Bank Details', ref: bankDetailsRef}, { name: 'Amenities', ref: amenitiesRef }, { name: 'Documents', ref: documentsRef }, { name: 'Location', ref: locationRef }];
    return (<div style={{marginBottom: "80px"}}>
        <PropertyPageNavbar navbarItems={navbarItems} />
        <div ref={overviewRef}>
            <Frame propertyData={props?.propertyData} />
            <Heading isUserOwner={props?.isUserOwner} propertyId={props?.propertyData?._id} heading={props?.propertyData?.name} address={props?.propertyData?.address} showActionBtn={props?.showActionBtn} ctaText="Register to Bid" openModal={props?.openModal} registrationDetails={props?.registrationDetails} auctionData={props?.auctionData} isAuctionEnded={props?.isAuctionEnded}/>
            <SectionSeparator />
            <Overview setShowPropertyDetails={props?.setShowPropertyDetails} auctionConfig={props?.auctionData?.config} price={props?.auctionData?.config?.price?.value} emd={props?.auctionData?.config?.emd?.value} auctionStartTime={props?.auctionData?.config?.start_time} auctionEndTime={props?.auctionData?.config?.end_time} isAuctionEnded={props?.isAuctionEnded} setSelectedBreadcrum={props?.setSelectedBreadcrum}/>
            <SectionSeparator />
        </div>
        <Description ref={descriptionRef} description={props?.propertyData?.description} />
        <SectionSeparator />
        <SellerInfo ref={bankDetailsRef} auctionData={props?.auctionData}/>
        <SectionSeparator />
        <Amenities ref={amenitiesRef} />
        <SectionSeparator />
        <Documents ref={documentsRef} propertyData={props?.propertyData} />
        <SectionSeparator />
        <Location ref={locationRef} center={props?.propertyData?.location} property_outline={props?.propertyData?.property_outline} />
        <SectionSeparator />
    </div>)
};
export default PropertyDetails;
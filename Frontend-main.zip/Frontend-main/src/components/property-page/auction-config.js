import { useEffect, useState } from 'react';
import CustomInput from '../custom-input/custom-input';
import locationLogo from '../../images/location-icon.svg';
import calendarBlackIcon from '../../images/calendar-black-icon.svg';
import clockIcon from '../../images/clock-icon.svg';
import DatePicker from 'react-datepicker';
import TimePicker from 'react-time-picker';
import 'react-time-picker/dist/TimePicker.css';
import 'react-datepicker/dist/react-datepicker.css';
import "./auction-config.css";
import { getAccountDetails } from '../../api/account';
import Modal from 'react-modal';
import closeBtn from '../../images/close-modal-icon.svg';
import editIcon from '../../images/edit-icon.svg';
import { editAuctionConfig, getAuctionDetails } from '../../api/auction';

const EditSellerDetailsFormSectionSeparator = (props) => {
    return (<div style={{ borderTop: "1px solid #D9D9D9", width: "100%", margin: "17px -20px 17px -20px", width: "calc(100% + 40px)" }}>
    </div>)
};

const EditSellerDetailsModal = (props) => {
    const [isSubmitEnabled, setIsSubmitEnabled] = useState(false);
    const [beneficiaryName, setBeneficiaryName] = useState("");
    const [accountNo, setAccountNo] = useState("");
    const [ifsc, setIfsc] = useState("");
    const [sellerName, setSellerName] = useState("");
    const [mobileNo, setMobileNo] = useState("");
    const [email, setEmail] = useState("");

    useEffect(() => {
        setBeneficiaryName(props?.auctionData?.config?.beneficiary_name);
        setAccountNo(props?.auctionData?.config?.bank_account_number);
        setIfsc(props?.auctionData?.config?.ifsc_code);
        setSellerName(props?.auctionData?.config?.seller_name);
        setMobileNo(props?.auctionData?.config?.seller_mobile_no);
        setEmail(props?.auctionData?.config?.seller_email);
    }, [])

    useEffect(() => {
        if ((beneficiaryName?.length <= 0) || (accountNo?.length <= 0) || (ifsc?.length <= 0) || (sellerName?.length <= 0) || (mobileNo?.length < 10) || (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email))) {
            setIsSubmitEnabled(false);
        }
        else {
            setIsSubmitEnabled(true);
        }
    })

    const onSubmitClick = async () => {
        let payload = {
            auction_id: props?.auctionData?._id,
            beneficiary_name: beneficiaryName,
            bank_account_number: accountNo,
            ifsc_code: ifsc,
            seller_name: sellerName,
            seller_mobile_no: String(mobileNo),
            seller_email: email
        }
        await editAuctionConfig(payload);
        props?.closeModal()
    }

    return (
        <div>
            <div style={{ display: "flex", justifyContent: "space-between", width: "700px" }}>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                    <div>
                        <div className='registration-from-heading'>Edit Details</div>
                    </div>
                </div>
                <img src={closeBtn} onClick={props.closeModal} style={{ cursor: "pointer" }} />
            </div>
            <EditSellerDetailsFormSectionSeparator />
            <div className='registration-form-scroll'>
                <div className='registration-form-input-section'>
                    <div className='amount-refund-section'>
                        EMD Deposit Account Details
                    </div>
                    <AuctionConfigInputBox text="Beneficiary Name" placeholder="Enter beneficiary name" handleTextInputChange={(e) => setBeneficiaryName(e.target.value)} value={beneficiaryName} showErrorMessage={beneficiaryName?.length <= 0} errorMessage="Beneficiary name is mandatory" />

                    <AuctionConfigInputBox text="Account Number" placeholder="Enter your account number" handleTextInputChange={(e) => setAccountNo(e.target.value)} value={accountNo} showErrorMessage={accountNo?.length <= 0} errorMessage="Account number is mandatory" />

                    <AuctionConfigInputBox text="IFSC Code" placeholder="Enter your bank's IFSC Code" handleTextInputChange={(e) => setIfsc(e.target.value)} value={ifsc} showErrorMessage={ifsc?.length <= 0} errorMessage="IFSC code is mandatory" />

                    <div className='amount-refund-section'>
                        Primary Contact Details
                    </div>

                    <AuctionConfigInputBox text="Seller's Name" placeholder="Enter seller's name" handleTextInputChange={(e) => setSellerName(e.target.value)} value={sellerName} showErrorMessage={sellerName?.length <= 0} errorMessage="Seller's name is mandatory" />

                    <AuctionConfigInputBox text="Mobile Number" placeholder="Enter mobile number" handleTextInputChange={(e) => setMobileNo(e.target.value.replace(/\D/g, ''))} value={mobileNo} showErrorMessage={mobileNo?.length < 10} errorMessage="Valid mobile number is mandatory" />

                    <AuctionConfigInputBox text="Email Id" placeholder="Enter email id" handleTextInputChange={(e) => setEmail(e.target.value)} value={email} showErrorMessage={!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)} errorMessage="Vaild email id is mandatory" />

                    <div className='auction-config-save-btn' style={isSubmitEnabled ? { marginTop: "15px" } : { marginTop: "15px", border: "none", background: "#ccc", color: "#ffffff", cursor: "not-allowed" }} onClick={isSubmitEnabled ? () => onSubmitClick() : () => { }}>Save</div>
                </div>
            </div>
        </div>
    )
};

const SellerDetails = (props) => {
    return (
        <div className='auction-result-bid-details'>
            <div className='auction-result-seller-details' style={{ display: "flex", justifyContent: "space-between", width: "-webkit-fill-available" }}>
                EMD Deposit Account Details
                <div style={{ cursor: "pointer", display: "flex", alignItems: "center" }} onClick={props?.openModal}><img src={editIcon} style={{ marginRight: "2px", width: '15px' }} />Edit</div>
            </div>
            <div>
                <span className='auction-result-seller-details-title'>
                    Beneficiary Name &nbsp;&nbsp;:&nbsp;&nbsp;
                </span>
                <span className='auction-result-seller-details-desc'>
                    {props?.auctionData?.config?.beneficiary_name}
                </span>
            </div>
            <div>
                <span className='auction-result-seller-details-title'>
                    Account Number&nbsp;&nbsp;:&nbsp;&nbsp;
                </span>
                <span className='auction-result-seller-details-desc'>
                    {props?.auctionData?.config?.bank_account_number}
                </span>
            </div>
            <div>
                <span className='auction-result-seller-details-title'>
                    IFSC Code&nbsp;&nbsp;:&nbsp;&nbsp;
                </span>
                <span className='auction-result-seller-details-desc'>
                    {props?.auctionData?.config?.ifsc_code}
                </span>
            </div>
            <div className='auction-result-seller-details'>
                Primary Contact Details
            </div>
            <div>
                <span className='auction-result-seller-details-title'>
                    Seller’s Name &nbsp;&nbsp;:&nbsp;&nbsp;
                </span>
                <span className='auction-result-seller-details-desc'>
                    {props?.auctionData?.config?.seller_name}
                </span>
            </div>
            <div>
                <span className='auction-result-seller-details-title'>
                    Mobile No &nbsp;&nbsp;:&nbsp;&nbsp;
                </span>
                <span className='auction-result-seller-details-desc'>
                    {props?.auctionData?.config?.seller_mobile_no}
                </span>
            </div>
            <div>
                <span className='auction-result-seller-details-title'>
                    Email Id &nbsp;&nbsp;:&nbsp;&nbsp;
                </span>
                <span className='auction-result-seller-details-desc'>
                    {props?.auctionData?.config?.seller_email}
                </span>
            </div>
        </div>
    );
};

const AuctionConfigDatePicker = (props) => {
    return (
        <div className='auction-config-input-wrapper' style={props?.freezeInput ? { pointerEvents: "none", background: "#F5F5F5" } : {}}>
            <img src={calendarBlackIcon} />
            <DatePicker
                selected={props?.selectedDate}
                onChange={(date) => props?.setSelectedDate(date)}
                dateFormat="dd/MM/yyyy"
                placeholderText="Select a date"
                customInput={<input style={{ background: "transparent" }} />}
            />
        </div>
    )
};

const AuctionConfigTimePicker = (props) => {
    return (
        <div className='auction-config-input-wrapper' style={props?.freezeInput ? { pointerEvents: "none", background: "#F5F5F5" } : {}}>
            <img src={clockIcon} />
            <TimePicker
                onChange={props?.setSelectedTime}
                value={props?.selectedTime}
                disableClock={true}
                clearIcon={true}
                style={{ background: "transparent" }} />
        </div>
    );
};

const AuctionConfigDateTimePicker = (props) => {
    const [selectedDate, setSelectedDate] = useState();
    const [selectedTime, setSelectedTime] = useState();

    useEffect(() => {
        let dateFromTimestamp = new Date(props?.timestamp);
        const hours = dateFromTimestamp.getHours();
        const minutes = dateFromTimestamp.getMinutes();
        const formattedTime = `${hours}:${minutes}`;
        setSelectedDate(dateFromTimestamp);
        setSelectedTime(formattedTime);
    }, []);

    useEffect(() => {
        if (selectedTime && selectedDate) {
            let dateTimestamp = selectedDate?.setHours(0,0,0,0)/1000;
            let hrs = parseInt(selectedTime?.split(':')[0], 10);
            let mins = parseInt(selectedTime?.split(':')[1], 10);
            let timestamp = dateTimestamp + hrs * 60 * 60 + mins * 60;
            console.log("asdad", selectedTime, hrs, mins, dateTimestamp, timestamp, selectedDate)
            props?.setTimestamp(timestamp*1000);
        }
        else {
            props?.setTimestamp(null);
        };
    }, [selectedTime, selectedDate]);
    return (
        <div>
            <div className='auction-config-input-title' style={{ margin: "15px 0px" }}>
                {props?.text}
            </div>
            <div style={{ display: "flex", justifyContent: "space-between" }}>
                <div style={{ width: "45%" }}>
                    <AuctionConfigDatePicker freezeInput={props?.freezeInput} selectedDate={selectedDate} setSelectedDate={setSelectedDate} />
                </div>
                <div style={{ width: "45%" }}>
                    <AuctionConfigTimePicker freezeInput={props?.freezeInput} selectedTime={selectedTime} setSelectedTime={setSelectedTime} />
                </div>
            </div>
        </div>
    )
};

const AuctionConfigInputBox = (props) => {
    return (
        <div>
            <div className='auction-config-input-title' style={{ margin: "15px 0px" }}>
                {props?.text}
            </div>
            <CustomInput {...props} />
        </div>
    )
};

const AuctionConfigInput = (props) => {
    return (
        <span className='auction-config-input-wrapper' style={props?.freezeInput ? { pointerEvents: "none", background: "#F5F5F5" } : {}}>
            <input className='auction-config-input'
                placeholder={props?.placeholder}
                value={props?.value}
                onChange={props?.handleTextInputChange}
                style={{ background: "transparent" }} />
            <div className='auction-config-input-title'>min</div>
        </span>
    )
};

const AuctionConfig = (props) => {
    const [imgUrl, setImgUrl] = useState([]);
    const [extendAuctionBy, setExtendAuctionBy] = useState();
    const [extendAuctionAfter, setExtendAuctionAfter] = useState();
    const [reservePrice, setReservePrice] = useState();
    const [emd, setEmd] = useState();
    const [minBidIncrement, setMinBidIncrement] = useState();
    const [auctionStartTime, setAuctionStartTime] = useState(Number(props?.auctionData?.config?.start_time) * 1000);
    const [auctionEndTime, setAuctionEndTime] = useState(Number(props?.auctionData?.config?.end_time) * 1000);
    const [sellerData, setSellerData] = useState();
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [auctionData, setAuctionData] = useState();
    const [areDetailsEditable, setAreDetailsEditable] = useState(false);
    const [isSubmitEnabled, setIsSubmitEnabled] = useState(false);

    useEffect(() => {
        const propertyImages = props?.propertyData?.property_images;
        const sortedFloors = Object.keys(propertyImages).sort((a, b) => {
            return propertyImages[a].order - propertyImages[b].order;
        });

        // Create a new object with sorted floors
        const sortedPropertyImages = {};
        sortedFloors.forEach(floor => {
            sortedPropertyImages[floor] = propertyImages[floor].url_list;
        });
        const valuesArray = Object.values(sortedPropertyImages).flat();
        const updatedObject = { All: valuesArray, ...sortedPropertyImages };
        setImgUrl(updatedObject?.All);

        const fetchData = async () => {
            let sellerDetails = await getAccountDetails(props?.propertyData?.owner_id);
            let auctionData = await getAuctionDetails(props?.auctionId);
            setSellerData(sellerDetails?.data);
            setAuctionData(auctionData?.data);
            setExtendAuctionBy(auctionData?.data?.config?.extend_auction_by);
            setExtendAuctionAfter(auctionData?.data?.config?.extend_auction_after);
            setReservePrice(auctionData?.data?.config?.price?.value);
            setEmd(auctionData?.data?.config?.emd?.value);
            setMinBidIncrement(auctionData?.data?.config?.min_bid_increment?.value);
            setAuctionStartTime(Number(auctionData?.data?.config?.start_time) * 1000);
            setAuctionEndTime(Number(auctionData?.data?.config?.end_time) * 1000);
        };
        fetchData();
    }, [isModalOpen]);

    useEffect(() => {
        if ((!auctionStartTime || !auctionEndTime || auctionStartTime > auctionEndTime) || (!extendAuctionAfter || extendAuctionAfter < 0 || !extendAuctionBy || extendAuctionBy < 0) || (!reservePrice || reservePrice < 0) || (!emd || emd < 0) || (!minBidIncrement || minBidIncrement < 0)) {
            setIsSubmitEnabled(false);
        }
        else {
            setIsSubmitEnabled(true);
        }
    });

    const openModal = () => {
        setIsModalOpen(true);
        document.body.style.overflow = 'hidden';
    };
    const closeModal = () => {
        setIsModalOpen(false);
        document.body.style.overflow = 'auto';
    };
    const onSubmitClick = async () => {
        let payload = {
            start_time: auctionStartTime / 1000,
            end_time: auctionEndTime / 1000,
            type: "ENGLISH_AUCTION",
            price: { "value": Number(reservePrice), "currency": "RUPEES" },
            min_bid_increment: { "value": Number(minBidIncrement), "currency": "RUPEES" },
            emd: { "value": Number(emd), "currency": "RUPEES" },
            extend_auction_after: extendAuctionAfter,
            extend_auction_by: extendAuctionBy,
            auction_id: props?.auctionData?._id
        }
        await editAuctionConfig(payload);
        setAreDetailsEditable(false);
        const fetchData = async () => {
            let sellerDetails = await getAccountDetails(props?.propertyData?.owner_id);
            let auctionData = await getAuctionDetails(props?.auctionId);
            setSellerData(sellerDetails?.data);
            setExtendAuctionBy(auctionData?.data?.config?.extend_auction_by);
            setExtendAuctionAfter(auctionData?.data?.config?.extend_auction_after);
            setReservePrice(auctionData?.data?.config?.price?.value);
            setEmd(auctionData?.data?.config?.emd?.value);
            setMinBidIncrement(auctionData?.data?.config?.min_bid_increment?.value);
            setAuctionStartTime(Number(auctionData?.data?.config?.start_time) * 1000);
            setAuctionEndTime(Number(auctionData?.data?.config?.end_time) * 1000);
        };
        fetchData();
    }

    return (
        <div className="auction-result-section" style={{marginBottom: "20px"}}>
            <div className="auction-result-img-section">
                <img className="auction-result-img" src={imgUrl[0]} />
                <div style={{ "marginTop": "20px" }}>
                    <SellerDetails sellerData={sellerData} openModal={openModal} auctionData={auctionData} />
                </div>
            </div>
            <div className="auction-result-display-section">
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                    <div className='auction-config-property-name'>{props?.propertyData?.name}</div>
                    {!areDetailsEditable && <div onClick={() => setAreDetailsEditable(true)} style={{ cursor: "pointer", display: "flex", alignItems: "center", color: "#AD4E00" }} ><img src={editIcon} style={{ marginRight: "2px", width: '15px' }} />Edit</div>}
                </div>
                <div className='auction-config-property-address'>
                    <img src={locationLogo} style={{ marginRight: "5px" }} />
                    {props?.propertyData?.address}
                </div>
                <div style={{ borderTop: "1px solid #D9D9D9", width: "100%", margin: "20px 0px 20px 0px" }}>
                </div>
                <AuctionConfigDateTimePicker freezeInput={!areDetailsEditable} text="Select auction start date and time(in 24 hr. format)" setTimestamp={setAuctionStartTime} timestamp={auctionStartTime} />
                <AuctionConfigDateTimePicker freezeInput={!areDetailsEditable} text="Select auction end date and time(in 24 hr. format)" setTimestamp={setAuctionEndTime} timestamp={auctionEndTime} />
                <div className='auction-config-input-error-message' style={(!auctionStartTime || !auctionEndTime || auctionStartTime > auctionEndTime) ? { visibility: "visible" } : { visibility: "hidden" }}>
                    Auction start time should be less than auction end time
                </div>
                <div style={{ margin: "15px 0px" }}>
                    <div style={{ display: "flex", alignItems: "center" }}>
                        <span className='auction-config-input-title' style={{ margin: "0px 10px 0px 0px" }}>Extend auction by </span>
                        <AuctionConfigInput freezeInput={!areDetailsEditable} handleTextInputChange={(e) => setExtendAuctionBy(e.target.value.replace(/\D/g, ''))} value={extendAuctionBy} />
                        <span className='auction-config-input-title' style={{ margin: "0px 10px 0px 10px" }}>if last bid in last</span>
                        <AuctionConfigInput freezeInput={!areDetailsEditable} handleTextInputChange={(e) => setExtendAuctionAfter(e.target.value.replace(/\D/g, ''))} value={extendAuctionAfter} />
                    </div>
                    <div className='auction-config-input-error-message' style={(!extendAuctionAfter || extendAuctionAfter < 0 || !extendAuctionBy || extendAuctionBy < 0) ? { visibility: "visible" } : { visibility: "hidden" }}>
                        This is Mandatory
                    </div>
                </div>
                <div style={{ marginTop: "10px" }}><AuctionConfigInputBox freezeInput={!areDetailsEditable} text="Reserve price(in INR)" placeholder="Enter opening bid price" handleTextInputChange={(e) => setReservePrice(e.target.value.replace(/\D/g, ''))} value={reservePrice} showErrorMessage={!reservePrice || reservePrice < 0} errorMessage="Reserve Price is Mandatory" /></div>
                <div style={{ marginTop: "10px" }}><AuctionConfigInputBox freezeInput={!areDetailsEditable} text="Earnest Money Deposit (EMD)(in INR)" placeholder="Enter EMD price" handleTextInputChange={(e) => setEmd(e.target.value.replace(/\D/g, ''))} value={emd} showErrorMessage={!emd || emd < 0} errorMessage="EMD is Mandatory" /></div>
                <div style={{ marginTop: "10px" }}><AuctionConfigInputBox freezeInput={!areDetailsEditable} text="Bid Increment amount(in INR)" placeholder="Enter min increment amount" handleTextInputChange={(e) => setMinBidIncrement(e.target.value.replace(/\D/g, ''))} value={minBidIncrement} showErrorMessage={!minBidIncrement || minBidIncrement < 0} errorMessage="Min Bid Increment is Mandatory" /></div>
                {areDetailsEditable && <div className='auction-config-save-btn' style={isSubmitEnabled ? { marginTop: "15px" } : { marginTop: "15px", border: "none", background: "#ccc", color: "#ffffff", cursor: "not-allowed" }} onClick={isSubmitEnabled ? () => onSubmitClick() : () => { }}>Save</div>}
            </div>
            {
                isModalOpen && <Modal
                    isOpen={isModalOpen}
                    className="modal"
                    overlayClassName="overlay"
                >
                    <EditSellerDetailsModal closeModal={closeModal} auctionData={auctionData} />
                </Modal>
            }
        </div>
    )
};

export default AuctionConfig;
import './section-heading.css';

const SectionHeading = (props) => {
  return (

    <div className='section-heading'>{props.heading}
      <div className='section-heading-underline' />
    </div>
  )

}
export default SectionHeading;
import noBidImg from "../../images/no-bid-img.svg";
import './no-bid.css';

const NoBid = () => {
    return (
        <div className="no-bid-container">
            <img src={noBidImg} />
            <div className='no-bid-heading'>
                Bid History will appear here
            </div>
            <div className="no-bid-description">
                Bid history will appear here once bidders start placing bids
            </div>
        </div>)
}
export default NoBid;
const initialState = {
    user: null,
};

const userReducer = (state = initialState, action) => {
    switch (action.type) {
        case 'SET_USER':
            return {
                ...state,
                user: action.payload,
            };
        case 'CLEAR_USER':
            return {
                ...state,
                user: null,
            };
        case 'SET_LOGIN_REDIRECT_URL':
            return {
                ...state,
                post_login_redirect_url: action.payload
            }
        case 'CLEAR_LOGIN_REDIRECT_URL':
            return {
                ...state,
                post_login_redirect_url: null,
            }
        case 'OPEN_REGISTRATION_MODAL':
            return {
                ...state,
                open_registration_modal: action.payload
            }
        default:
            return state;
    }
};

export default userReducer;

export const setUser = (user) => ({
    type: 'SET_USER',
    payload: user,
});

export const clearUser = () => ({
    type: 'CLEAR_USER',
});

export const setLoginRedirectUrl = (redirect_url) => ({
    type: 'SET_LOGIN_REDIRECT_URL',
    payload: redirect_url
});

export const clearLoginRedirectUrl = () => ({
    type: 'CLEAR_LOGIN_REDIRECT_URL',
})

export const setOpenRegistrationModal = (flag) => ({
    type: 'OPEN_REGISTRATION_MODAL',
    payload: flag
})
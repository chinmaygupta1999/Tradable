import {
  BrowserRouter,
  Route,
  Routes
} from "react-router-dom";
import { ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import PropertyPage from './components/property-page/property-page';
import LoginPage from './components/login/login';
import MapContainer from "./components/map-container/map-container";
import AutoCompleteSearch from "./components/search-bar/autocomplete"
import './app.css';
import Account from "./components/account/account";
import { Provider } from 'react-redux';
import { PersistGate } from 'redux-persist/integration/react';
import { store, persistor } from './store/store';
import Homepage from "./components/homepage/homepage";
import Header from "./components/header/header";
import Footer from "./components/footer/footer";
import { LoadScript } from '@react-google-maps/api';
import { ErrorBoundary } from "react-error-boundary";

const CustomErrorBoundary = () => {
  const styles = {
    errorContainer: {
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      justifyContent: 'center',
      height: '100vh',
      textAlign: 'center',
      backgroundColor: '#FFE7BA',
    },
    errorText: {
      fontSize: '2rem',
      color: '#434343',
    },
    errorMessage: {
      fontSize: '1rem',
      color: '#434343',
    },
  };
  return (<div style={styles.errorContainer}>
    <h1 style={styles.errorText}>Oops!! Something went wrong</h1>
    <p style={styles.errorMessage}>
    We're sorry, but it seems like there's a hiccup on our end. Our team has been notified, and our best minds working to fix it. Please try again later.
    </p>
  </div>)
}

const App = () => {
  return (
    <div>
      <ErrorBoundary fallback={<CustomErrorBoundary />}>
        <LoadScript
          googleMapsApiKey="AIzaSyBHKhA_C31CAgVkzNWswBuhIjgve81O6Tw"
          libraries={['places']}>
          <Provider store={store}>
            <PersistGate loading={null} persistor={persistor}>
              <ToastContainer />
              <BrowserRouter>
                <Header />
                <Routes>
                  <Route path="/login" element={<LoginPage />} />
                  <Route path="/property/:propertyId" element={<PropertyPage />} />
                  <Route path="/" element={<Homepage />} />
                  <Route path="/account" element={<Account />} />
                </Routes>
                <Footer />
              </BrowserRouter>
            </PersistGate>
          </Provider>
        </LoadScript>
      </ErrorBoundary>
    </div>
  )
}
export default App;
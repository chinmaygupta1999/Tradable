from models.wishlist import Wishlist
from models.property import Property
from models.auction import Auction

class WishlistController:
    def get_wishlist(self, user_id):
        wishlist = Wishlist.find(user_id=user_id)
        property_ids = [wish.property_id for wish in wishlist]
        property_list = Property.find(_id__in=property_ids)
        auction_list= Auction.find(property_id__in=[property._id for property in property_list])
        property_id_to_price_mapping = {auction.property_id: auction.config.price for auction in auction_list}
        propert_id_to_wishlist_mapping = {wish.property_id: wish for wish in wishlist}
        return [{**property.to_dict(), "wishlisted": propert_id_to_wishlist_mapping.get(property._id) is not None, "price": {"value": property_id_to_price_mapping.get(property._id).value}} for property in property_list if property_id_to_price_mapping.get(property._id)]
        
    def add_wishlist(self, user_id, property_id, deleted=False):
        if deleted:
            wishlist: Wishlist = Wishlist.find_one(user_id=user_id, property_id=property_id)
            wishlist.delete_one(delete_from_db=True)
            return "Deleted"
        wishlist = Wishlist(user_id=user_id, property_id=property_id)
        wishlist.update()
        return "added"

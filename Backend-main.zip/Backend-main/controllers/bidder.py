from models.auction_bid import AuctionBid
from models.auction_winner import AuctionWinner
from models.auction_registration import AuctionRegistration, RegistrationStatus
from models.auction import Auction
from models.user import User
from utils.bidder import BidderUtils
from core.error_code import ErrorCode
from models.auction_winner import AuctionWinnerStatus
from models.price import Price
from time import time
from core.socket import emit_from_socket

bidder_utils = BidderUtils()

class BidderController:
    def place_bid(self, params):
        auction_winner = bidder_utils.validate_bid(params["price"], params["auction_id"], params["user_id"]) 
        if isinstance(auction_winner, ErrorCode):
            return auction_winner
        if not auction_winner:
            auction_winner = AuctionWinner(price=params["price"], user_id=params["user_id"], auction_id=params["auction_id"], status="PROCESSED")
        auction_bid = AuctionBid(**params)
        auction_winner.user_id = params["user_id"]
        auction_winner.price.value = params["price"]["value"]
        auction_winner.status = AuctionWinnerStatus.PROCESSED
        auction_winner.insert()
        emit_from_socket("bid_update", {"auction_highest_bid": {"price": {"value": auction_winner.price.value}}})
        return auction_bid.to_dict()
    
    def get_highest_bid(self, auction_id):
        auction_winner = AuctionWinner.find_one(auction_id=auction_id)
        if auction_winner is None:
            auction = Auction.find_one(_id=auction_id)
            auction = auction.to_dict()
            return {"price": auction["config"]["price"], "user_id": None}
        auction_winner = auction_winner.to_dict()
        return {"price": auction_winner["price"], "user_id": auction_winner["user_id"]}
    
    def get_user_highest_bid(self, auction_id, user_id):
        auction_bid = AuctionBid.find(sorting=['-price__value'], auction_id=auction_id, user_id=user_id)
        if len(auction_bid)>0:
            return {"price": auction_bid[0].to_dict()["price"], "user_id": auction_bid[0].to_dict()["user_id"]}
        return None
    
    def get_all_bids(self, auction_id, skip, limit):
        auction_bids = AuctionBid.find(sorting=['-price__value'], skip=skip, limit=limit, auction_id=auction_id)
        user_ids = list(set([auction_bid.user_id for auction_bid in auction_bids]))
        user_id_to_user_mapping = {user._id: user for user in User.find(_id__in=user_ids)}
        total_bids = AuctionBid.count_documents(auction_id=auction_id)
        return [{**auction_bid.to_dict(), "user_name": user_id_to_user_mapping.get(auction_bid.user_id).user_name, "user_phone_no": user_id_to_user_mapping.get(auction_bid.user_id).phone_number} for auction_bid in auction_bids], total_bids
    
    def is_bidding_allowed(self, auction_id, user_id):
        auction_registration = AuctionRegistration.find_one(user_id=user_id, auction_id=auction_id)
        auction = Auction.find_one(_id=auction_id)
        if not auction:
            return False
        auction_start_time = auction.config.start_time
        auction_end_time = auction.config.end_time
        current_timestamp = time()
        is_auction_ongoing = auction_start_time<=current_timestamp<=auction_end_time
        return auction_registration and auction_registration.registration_status == RegistrationStatus.APPROVED and is_auction_ongoing
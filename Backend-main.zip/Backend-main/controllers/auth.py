from models.otp_info import OtpInfo
from models.user import User
from models.refresh_token import RefreshToken
import random
from time import time
import jwt
import datetime
from bson import ObjectId
from core.constants import JWT_SECRET_KEY, JWT_EXPIRY_TIME_IN_MINS

class AuthController():
    def generate_jwt_token(self, user_id, secret_key, expire_minutes):
        payload = {
            'user_id': user_id,
            'exp': datetime.datetime.utcnow() + datetime.timedelta(minutes=expire_minutes)
        }
        jwt_token = jwt.encode(payload, secret_key, algorithm='HS256')
        return jwt_token
    
    def _send_message_to_phone_number(phone_number):
        #TODO: Gupshup Integration
        pass
    
    def generate_otp(self, phone_number):
        otp = random.randint(100000, 999999)
        otp_info = OtpInfo.find_one(_id=phone_number)
        if otp_info:
            otp_generation_time = otp_info.u
            resend_time_in_sec = 10
            if otp_generation_time >= time() - resend_time_in_sec:
                return {"message": f"Try after {resend_time_in_sec} seconds"}
        otp_info = OtpInfo(_id=phone_number, otp=otp)
        otp_info.update()
        return {"otp": otp}
    
    def is_otp_valid(self, phone_number, otp):
        otp_info = OtpInfo.find_one(_id=phone_number)
        if otp_info is None:
            return False
        return otp_info.otp == otp
    
    def add_user(self, user_name, phone_number):
        user = User(phone_number=phone_number, user_name=user_name)
        user.insert()
        return user
    
    def fetch_user(self, phone_number):
        user = User.find_one(phone_number=phone_number)
        return user
    
    def login_user(self, phone_number, user=None):
        if not user:
            user = User.find_one(phone_number=phone_number)
        jwt = self.generate_jwt_token(str(user._id), JWT_SECRET_KEY, JWT_EXPIRY_TIME_IN_MINS)
        refresh_token = self.generate_jwt_token(str(user._id), JWT_SECRET_KEY, JWT_EXPIRY_TIME_IN_MINS)
        refresh_token_obj = RefreshToken(user_id=user._id, token=jwt, refresh_token=refresh_token)
        refresh_token_obj.insert()
        return jwt, refresh_token
    
    def delete_user_session(self):
        pass
    
    def check_login(self, token):
        try:
            decoded_token = jwt.decode(token, JWT_SECRET_KEY, algorithms=["HS256"])
        except jwt.InvalidTokenError:
            return None
        user = User.find_one(_id=ObjectId(decoded_token["user_id"]))
        return user
    
    def generate_new_jwt_token(self, user_id, refresh_token):
        refresh_token_obj = RefreshToken.find_one(user_id=ObjectId(user_id))
        if refresh_token_obj.refresh_token != refresh_token:
            return None
        refresh_token_obj.token = self.generate_jwt_token(user_id, JWT_SECRET_KEY, JWT_EXPIRY_TIME_IN_MINS)
        refresh_token_obj.update()
        return refresh_token_obj.token
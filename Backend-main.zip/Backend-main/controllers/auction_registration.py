from models.auction_registration import AuctionRegistration, RegistrationStatus
from models.auction_bid import AuctionBid
from models.auction_winner import AuctionWinner, AuctionWinnerStatus
from models.price import Price
from models.auction import Auction
from models.property import Property
from models.user import User
from core.error_code import ErrorCode

class AuctionRegistrationController:
    def register(self, params):
        if params.get('registration_status'):
            params.pop('registration_status')
        auction_registration = AuctionRegistration.find_one(user_id=params["user_id"], auction_id=params["auction_id"])
        if auction_registration:
            return ErrorCode.DUPLICATE_REGISTRATION
        auction_registration = AuctionRegistration(**params, registration_status=RegistrationStatus.APPROVAL_PENDING)
        auction_registration.insert()
        return auction_registration.to_dict()

    def get_registration_details(self, auction_id, user_id):
        auction_registration = AuctionRegistration.find_one(auction_id=auction_id, user_id=user_id)
        if auction_registration is None:
            return {"registration_status": RegistrationStatus.NOT_REGISTERED.value}
        return auction_registration.to_dict()
    
    def get_all_registration_details(self, auction_id, user_id):
        auction = Auction.find_one(_id=auction_id)
        if not auction:
            return []
        property = Property.find_one(_id=auction.property_id)
        if not property:
             return []
        if user_id != str(property.owner_id):
            return []
        auction_registrations = AuctionRegistration.find(auction_id=auction_id)
        user_ids = [auction_registration.user_id for auction_registration in auction_registrations]
        user_id_to_user_mapping = {user._id: user for user in User.find(_id__in = user_ids)}
        return [{**auction_registration.to_dict(), "user_name": user_id_to_user_mapping.get(auction_registration.user_id).user_name, "phone_no": user_id_to_user_mapping.get(auction_registration.user_id).phone_number, "img_url": user_id_to_user_mapping.get(auction_registration.user_id).image_url} for auction_registration in auction_registrations if user_id_to_user_mapping.get(auction_registration.user_id)]
    
    def change_approval_status(self, auction_id, user_id, seller_id, approval_status):
        auction = Auction.find_one(_id=auction_id)
        if not auction:
            return None
        auction_registration = AuctionRegistration.find_one(auction_id=auction_id, user_id=user_id)
        if not auction_registration:
            return None
        property = Property.find_one(_id=auction.property_id)
        if not property:
            return None
        if str(property.owner_id)!=seller_id:
            return None
        if approval_status == RegistrationStatus.APPROVED.value:
            auction_bid = AuctionBid(auction_id=auction_id, user_id=user_id, price=auction_registration.price)
            auction_winner = AuctionWinner.find_one(auction_id=auction_id)
            if not auction_winner:
                auction_winner = AuctionWinner(auction_id=auction_id, user_id=user_id, status="PROCESSED")
            auction_winner.user_id = user_id
            auction_winner.price = auction_registration.price
            auction_winner.update()
            auction_bid.update()
        elif approval_status == RegistrationStatus.REJECTED.value:
            auction_bid = AuctionBid.find_one(auction_id=auction_id, user_id=user_id, price=auction_registration.price)
            if auction_bid:
                auction_bid.deleted = True
                auction_bid.update()
                auction_bid = AuctionBid.find(auction_id=auction_id, sorting=['-price__value'])
                auction_winner = AuctionWinner.find_one(auction_id=auction_id, user_id=user_id)
                if len(auction_bid)>0:
                    if auction_winner:
                        auction_winner.user_id = auction_bid[0].user_id
                        auction_winner.price = auction_bid[0].price
                else:
                    auction_winner.deleted = True
                auction_winner.update()
        auction_registration.registration_status = RegistrationStatus(approval_status)
        auction_registration.update()
        return {"status": auction_registration.registration_status.value}
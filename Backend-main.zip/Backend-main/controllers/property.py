from models.property import Property
from models.auction import Auction
from models.wishlist import Wishlist
from models.auction_registration import AuctionRegistration, RegistrationStatus
from core.error_code import ErrorCode
from bson import ObjectId
class PropertyController:
    def get_property(self, property_id, user_id):
        property = Property.find_one(_id=property_id)
        if property is None:
            return ErrorCode.NOT_FOUND
        auction_details = Auction.find_one(property_id=property._id)
        wishlist = Wishlist.find(user_id=user_id)
        auction_registration_list = AuctionRegistration.find(auction_id = auction_details._id, registration_status = RegistrationStatus.APPROVED.value)
        return {"property": property.to_dict(), "auction": {**auction_details.to_dict(), "total_registrations": len(auction_registration_list)}}
    
    def add_property(self, params):
        property = Property(**params)
        property.insert()
        return property.to_dict()
    
    def get_map_property(self, north, south, east, west, user_id):
        property_list = Property.find(location__0__lte=north, location__0__gte=south, location__1__lte=east, location__1__gte=west)
        auction_list= Auction.find(property_id__in=[property._id for property in property_list])
        if not isinstance(user_id, ObjectId):
            wishlist = []
        else:
            wishlist = Wishlist.find(user_id=user_id)
        property_id_to_price_mapping = {auction.property_id: auction.config.price for auction in auction_list}
        property_id_to_wishlist_mapping = {wish.property_id: wish for wish in wishlist}
        return [{**property.to_dict(), "wishlisted": property_id_to_wishlist_mapping.get(property._id) is not None, "price": {"value": property_id_to_price_mapping.get(property._id).value}} for property in property_list if property_id_to_price_mapping.get(property._id)]
    
    def get_user_property_list(self, user_id):
        property_list = Property.find(owner_id=user_id)
        auction_list= Auction.find(property_id__in=[property._id for property in property_list])
        property_id_to_price_mapping = {auction.property_id: auction.config.price for auction in auction_list}
        return [{**property.to_dict(), "price": {"value": property_id_to_price_mapping.get(property._id).value}} for property in property_list if property_id_to_price_mapping.get(property._id)]
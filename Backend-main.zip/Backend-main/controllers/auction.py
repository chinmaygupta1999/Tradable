from models.auction import Auction, AuctionConfig, AuctionType
from models.auction_registration import AuctionRegistration, RegistrationStatus
from models.price import Price
from models.property import Property
from models.auction_winner import AuctionWinner
from models.auction_bid import AuctionBid
from models.user import User
from core.error_code import ErrorCode
from time import time

class AuctionController():
    def get_auction_details(self, auction_id):
        auction = Auction.find_one(_id=auction_id)
        if auction is None:
            return ErrorCode.NOT_FOUND
        return auction.to_dict()

    def create_auction(self, params):
        auction = Auction(**params)
        auction_winner = AuctionWinner(auction_id=auction._id, price=params["config"]["price"])
        auction.insert()
        auction_winner.insert()
        return auction.to_dict()
    
    def edit_auction(self, params):
        auction = Auction.find_one(_id=params["auction_id"])
        if params.get("start_time"):
            auction.config.start_time = float(params["start_time"])
        if params.get("end_time"):
            auction.config.end_time = float(params["end_time"])
        auction.config.type = AuctionType.ENGLISH_AUCTION
        if params.get("price"):
            auction.config.price = Price(value=params["price"]["value"], currency=params["price"]["currency"])
        if params.get("emd"):
            auction.config.emd = Price(value=params["emd"]["value"], currency=params["emd"]["currency"])
        if params.get("min_bid_increment"):
            auction.config.min_bid_increment = Price(value=params["min_bid_increment"]["value"], currency=params["min_bid_increment"]["currency"])
        if params.get("extend_auction_after"):
            auction.config.extend_auction_after = int(params["extend_auction_after"])
        if params.get("extend_auction_by"):
            auction.config.extend_auction_by = int(params["extend_auction_by"])
        if params.get("beneficiary_name"):
            auction.config.beneficiary_name = params["beneficiary_name"]
        if params.get("bank_account_number"):
            auction.config.bank_account_number = params["bank_account_number"]
        if params.get("ifsc_code"):
            auction.config.ifsc_code = params["ifsc_code"]
        if params.get("seller_name"):
            auction.config.seller_name = params["seller_name"]
        if params.get("seller_mobile_no"):
            auction.config.seller_mobile_no = params["seller_mobile_no"]
        if params.get("seller_email"):
            auction.config.seller_email = params["seller_email"]
        auction.update()
        return auction.to_dict()
    
    def delete_auction(self, params):
        auction = Auction.find_one(_id=params["_id"])
        auction.delete_one()
        return "Deleted"
    
    def get_auction_status(self, auction_id):
        auction = Auction.find_one(_id=auction_id)
        if auction is None:
            return False
        auction_start_time = auction.config.start_time
        auction_end_time = auction.config.end_time
        current_timestamp = time()
        if current_timestamp<auction_start_time:
            return {"auction_status": "Upcoming"}
        elif auction_start_time<=current_timestamp<=auction_end_time:
            return {"auction_status": "Ongoing"}
        elif current_timestamp>auction_end_time:
            return {"auction_status": "Completed"}
        return {"auction_status": None}
    
    def get_auction_winner(self, auction_id):
        auction_winner = AuctionWinner.find_one(auction_id=auction_id)
        if auction_winner is None:
            return None
        return auction_winner.to_dict()
    
    def get_user_auction_result(self, user_id, auction_id):
        all_bids = AuctionBid.find(auction_id=auction_id, sorting=['-price__value'])
        user_rank = None
        for index, bid in enumerate(all_bids):
            if str(bid.user_id) == user_id:
                user_rank = index + 1
                break
        auction_bid = AuctionBid.find(auction_id=auction_id, user_id=user_id, limit=1, sorting=['-price__value'])
        if not auction_bid:
            return {"user_highest_bid": None, "user_rank": None}
        return {"user_highest_bid": {"currency": auction_bid[0].price.currency.value, "value": auction_bid[0].price.value}, "user_rank": str(user_rank) if user_rank else "10+"}

    def get_auction_summary(self, seller_id, auction_id):
        auction = Auction.find_one(_id=auction_id)
        property = Property.find_one(_id=auction.property_id)
        if str(seller_id) != str(property.owner_id):
            return None
        auction_winner = AuctionWinner.find_one(auction_id=auction_id)
        if not auction_winner:
            return None
        winner = User.find_one(_id=auction_winner.user_id)
        total_registrations = AuctionRegistration.count_documents(auction_id=auction_id, registration_status=RegistrationStatus.APPROVED)
        total_bids = AuctionBid.count_documents(auction_id=auction_id)
        return {"winning_bid": {"value": auction_winner.price["value"], "currency": auction_winner.price["currency"].value},
        "winner": {"user_name": winner.user_name, "user_phone_number": winner.phone_number, "user_id": str(winner._id)},
        "total_bidders": total_registrations,
        "total_bids": total_bids,
        }
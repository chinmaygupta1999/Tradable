from core.bucket import generate_signed_url
from core.constants import BUCKET_NAME
class UploadController:
    def get_upload_url(self, file_path):
        return {"upload_signed_url": generate_signed_url(BUCKET_NAME, file_path)}
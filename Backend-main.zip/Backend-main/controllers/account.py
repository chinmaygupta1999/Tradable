from models.user import User
from core.error_code import ErrorCode

class AccountDetailsController:
    def get_account_details(self, user_id):
        account_details = User.find_one(_id=user_id)
        if account_details is None:
            return ErrorCode.NOT_FOUND
        return account_details.to_dict()
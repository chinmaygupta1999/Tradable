from models.auction_winner_form import AuctionWinnerForm

class AuctionWinnerFormController:
    def get_auction_winner_form_details(self, user_id, auction_id):
        auction_winner_form = AuctionWinnerForm.find_one(user_id=user_id, auction_id=auction_id)
        if not auction_winner_form:
            return {}
        return auction_winner_form.to_dict()
    
    def update_auction_winner_form(self, params):
        auction_winner_form = AuctionWinnerForm.find_one(user_id=params["user_id"])
        if not auction_winner_form:
            auction_winner_form = AuctionWinnerForm(**params)
        for field, value in params.items():
            if value is not None:
                setattr(auction_winner_form, field, value)
        auction_winner_form.update()
        return "Updated"
import datetime
from google.cloud import storage

def generate_signed_url(bucket_name, file_name, expiration_time=3600):
    """
    Generate a signed URL for uploading a file to a GCS bucket.

    :param bucket_name: Name of the GCS bucket.
    :param file_name: Name of the file to be uploaded.
    :param expiration_time: Expiration time of the signed URL in seconds (default is 1 hour).
    :return: The signed URL.
    """
    # Create a storage client
    client = storage.Client()

    # Get the bucket
    bucket = client.get_bucket(bucket_name)

    # Define the blob (object) name
    blob = bucket.blob(file_name)

    # Generate the signed URL
    expiration = datetime.datetime.utcnow() + datetime.timedelta(seconds=expiration_time)
    signed_url = blob.generate_signed_url(expiration=expiration, method='PUT', version='v4')
    return signed_url


from enum import Enum
class ErrorCode(Enum):
    NOT_FOUND = ("Object not found", 404)
    BID_CURRENCY_ERROR = ("Bid Currency Didn't match", 400)
    INVALID_BID = ("Bid value should be more than the current highest bid amount", 400)
    DUPLICATE_REGISTRATION = ("Bid registration already done", 500)
    USER_NOT_REGISTERED_FOR_AUCTION = ("User is not registered to take part in the auction", 404)


def return_error(error_code_obj):
    return ({"error": error_code_obj.value[0]}, error_code_obj.value[1])
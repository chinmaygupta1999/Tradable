import mongoengine

def connect_to_db():
    mongoengine.connect('models', host='mongodb://localhost:27018')
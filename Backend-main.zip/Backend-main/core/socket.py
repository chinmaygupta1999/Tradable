from flask import current_app

def emit_from_socket(event, data):
    socketio = current_app.extensions['socketio']
    socketio.emit(event, data)
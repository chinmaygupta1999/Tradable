from bson import ObjectId
from time import time
from mongoengine import fields

class Entity():
    _id = fields.ObjectIdField(default=lambda: ObjectId(), required=True)
    c = fields.FloatField(default=lambda: time(), required=True)
    u = fields.FloatField(default=lambda: time(), required=True)
    deleted = fields.BooleanField(default=False, required=True)    
    meta = {'allow_inheritance': True}
    
    @classmethod
    def find(cls, skip=None, limit=None, sorting=None, **kwargs):
        query = cls.objects(**kwargs, deleted=False)
        if sorting:
            query = query.order_by(*sorting)
        if skip:
            query = query.skip(skip)
        if limit:
            query = query.limit(limit)
        return query
    
    @classmethod
    def find_one(cls, **kwargs):
        return cls.objects(**kwargs, deleted=False).first()
    
    @classmethod
    def count_documents(cls, **kwargs):
        return cls.objects(**kwargs, deleted=False).count()

    def insert(self):
        self.save()
        return self
        
    def update(self):
        self.u = time()
        self.save()  
        return self 
    
    def delete_one(self, delete_from_db=False):
        if delete_from_db:
            self.delete()
            return self
        self.deleted = True
        self.update()
        return self
        
    def to_dict(self):
        obj_dict = self.to_mongo().to_dict()
        self.convert_object_ids_to_str(obj_dict)
        return obj_dict
    
    def convert_object_ids_to_str(self, d):
        if isinstance(d, dict):
            for key, value in d.items():
                if isinstance(value, dict):
                    self.convert_object_ids_to_str(value)
                elif isinstance(value, list):
                    for item in value:
                       self.convert_object_ids_to_str(item)
                elif isinstance(value, ObjectId):  # Replace 'ObjectId' with the actual type of your Object ID
                    d[key] = str(value)

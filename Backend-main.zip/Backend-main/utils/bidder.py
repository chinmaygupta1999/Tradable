from models.auction_winner import AuctionWinner
from models.auction import Auction
from models.auction_registration import AuctionRegistration, RegistrationStatus
from core.error_code import ErrorCode
class BidderUtils:
    def validate_bid(self, bid_amount, auction_id, user_id):
        auction_registration = AuctionRegistration.find_one(user_id=user_id, auction_id=auction_id, registration_status=RegistrationStatus.APPROVED)
        if not auction_registration:
            return ErrorCode.USER_NOT_REGISTERED_FOR_AUCTION
        auction_winner = AuctionWinner.find_one(auction_id=auction_id)
        auction = Auction.find_one(_id=auction_id)
        if not auction:
            return ErrorCode.NOT_FOUND
        if auction_winner:
            top_bid_amount = auction_winner.price
            if bid_amount["currency"] != top_bid_amount.currency.value:
                return ErrorCode.BID_CURRENCY_ERROR
            if bid_amount["value"] < top_bid_amount.value + auction.config.min_bid_increment.value:
                return ErrorCode.INVALID_BID
        return auction_winner



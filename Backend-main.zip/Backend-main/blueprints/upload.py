from flask import Blueprint, request
from controllers.upload import UploadController
from core.error_code import ErrorCode, return_error
from flask import jsonify
import json

upload_blueprint = Blueprint('upload', __name__)
upload_contoller_obj = UploadController()

@upload_blueprint.route("/get/upload/url", methods=["GET"])
def get_upload_url():
    file_path = request.args.get("file_path")
    resp = upload_contoller_obj.get_upload_url(file_path)
    if isinstance(resp, ErrorCode):
        return return_error(resp)
    return jsonify(resp), 200
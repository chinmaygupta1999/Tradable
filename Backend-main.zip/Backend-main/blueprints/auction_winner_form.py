from flask import Blueprint, request
from controllers.auction_winner_form import AuctionWinnerFormController
from core.error_code import ErrorCode, return_error
import json
from flask import jsonify

auction_winner_form_blueprint = Blueprint('auction_winner_form', __name__)
auction_details_contoller_obj = AuctionWinnerFormController()

@auction_winner_form_blueprint.route("/get/auction/winner/form/details", methods=["GET"])
def get_auction_winner_form_details():
    user_id = request.args.get("user_id")
    auction_id = request.args.get("auction_id")
    resp = auction_details_contoller_obj.get_auction_winner_form_details(user_id, auction_id)
    if isinstance(resp, ErrorCode):
        return return_error(resp)
    return jsonify(resp), 200

@auction_winner_form_blueprint.route("/auction/winner/form/update", methods=["POST"])
def register():
    resp = auction_details_contoller_obj.update_auction_winner_form(json.loads(request.data))
    return jsonify(resp), 201
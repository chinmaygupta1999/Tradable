from flask import Blueprint, request
from controllers.bidder import BidderController
from core.socket import emit_from_socket
from core.error_code import ErrorCode, return_error
from flask import jsonify
import json

bidder_blueprint = Blueprint('bidder', __name__)
bidder_contoller_obj = BidderController()

@bidder_blueprint.route("/place/bid", methods=["POST"])
def place_bid():
    resp = bidder_contoller_obj.place_bid(json.loads(request.data))
    if isinstance(resp, ErrorCode):
        return return_error(resp)
    return jsonify(resp), 201

@bidder_blueprint.route("/get/bid/details", methods=["GET"])
def get_highest_bid():
    auction_highest_bid = bidder_contoller_obj.get_highest_bid(request.args.get("auction_id"))
    user_highest_bid = bidder_contoller_obj.get_user_highest_bid(request.args.get("auction_id"), request.args.get("user_id"))
    if isinstance(auction_highest_bid, ErrorCode):
            return return_error(auction_highest_bid)
    return jsonify({"auction_highest_bid": auction_highest_bid, "user_highest_bid": user_highest_bid}), 200

@bidder_blueprint.route("/get/all/bids", methods=["GET"])
def get_all_bids():
    bid_list, total_bids = bidder_contoller_obj.get_all_bids(request.args.get("auction_id"), int(request.args.get("skip")), int(request.args.get("limit")))
    return {"bid_list": bid_list, "total_bids": total_bids}, 200

@bidder_blueprint.route("/check/bidding/allowed", methods=["GET"])
def check_if_bidding_is_allowed():
    is_bidding_allowed = bidder_contoller_obj.is_bidding_allowed(request.args.get("auction_id"), request.args.get("user_id"))      
    return {"is_bidding_allowed": is_bidding_allowed}, 200
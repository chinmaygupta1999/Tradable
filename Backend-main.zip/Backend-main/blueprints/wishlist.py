from flask import Blueprint, request
from controllers.wishlist import WishlistController
from flask import jsonify
import json

wishlist_blueprint = Blueprint('wishlist', __name__)
wishlist_contoller_obj = WishlistController()

@wishlist_blueprint.route("/get/wishlist", methods=['GET'])
def get_wishlist():
    resp = wishlist_contoller_obj.get_wishlist(request.args.get("user_id"))
    return jsonify(resp), 200

@wishlist_blueprint.route("/modify/wishlist", methods=['POST'])
def add_wishlist():
    request_data = json.loads(request.data)
    resp = wishlist_contoller_obj.add_wishlist(request_data["user_id"], request_data["property_id"], request_data.get("deleted"))
    return jsonify(resp), 201
from flask import Blueprint, request
from controllers.property import PropertyController
from core.error_code import ErrorCode, return_error
from flask import jsonify
import json

property_blueprint = Blueprint('property', __name__)
property_contoller_obj = PropertyController()

@property_blueprint.route("/get/property", methods=["GET"])
def get_property():
    property_id = request.args.get("property_id")
    user_id = request.args.get("user_id")
    resp = property_contoller_obj.get_property(property_id, user_id)
    if isinstance(resp, ErrorCode):
        return return_error(resp)
    return jsonify(resp), 200

@property_blueprint.route("/add/property", methods=["POST"])
def add_property():
    resp = property_contoller_obj.add_property(json.loads(request.data))
    return jsonify(resp), 201

@property_blueprint.route("/get/map/property", methods=["GET"])
def get_map_property():
    north = float(request.args.get("north"))
    south = float(request.args.get("south"))
    east = float(request.args.get("east"))
    west = float(request.args.get("west"))
    user_id = request.args.get("user_id")
    resp = property_contoller_obj.get_map_property(north, south, east, west, user_id)
    if isinstance(resp, ErrorCode):
        return return_error(resp)
    return jsonify(resp), 200

@property_blueprint.route("/get/user/property/list", methods=["GET"])
def get_user_property_list():
    user_id = request.args.get("user_id")
    resp = property_contoller_obj.get_user_property_list(user_id)
    if isinstance(resp, ErrorCode):
        return return_error(resp)
    return jsonify(resp), 200


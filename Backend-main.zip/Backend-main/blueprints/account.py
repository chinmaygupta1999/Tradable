from flask import Blueprint, request
from controllers.account import AccountDetailsController
from core.error_code import ErrorCode, return_error
import json
from flask import jsonify

account_details_blueprint = Blueprint('account_details', __name__)
auction_details_contoller_obj = AccountDetailsController()

@account_details_blueprint.route("/get/account/details", methods=["GET"])
def get_account_details():
    user_id = request.args.get("user_id")
    resp = auction_details_contoller_obj.get_account_details(user_id)
    if isinstance(resp, ErrorCode):
        return return_error(resp)
    return jsonify(resp), 200

# @account_details_blueprint.route("/register", methods=["POST"])
# def register():
#     resp = auction_details_contoller_obj.register(json.loads(request.data))
#     return jsonify(resp), 201
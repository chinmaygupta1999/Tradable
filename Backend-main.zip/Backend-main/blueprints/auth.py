from flask import Blueprint, request
from controllers.auth import AuthController
from flask import jsonify

auth_blueprint = Blueprint('auth', __name__)
auth_contoller_obj = AuthController()


@auth_blueprint.route("/request/otp", methods=["POST"])
def request_otp():
    phone_number = request.form.get("phone_number")
    resp = auth_contoller_obj.generate_otp(phone_number)
    resp_status = 200 if "message" in resp else 201
    return jsonify(resp), resp_status

@auth_blueprint.route("/verify/otp", methods=["POST"])
def verify_otp():
    phone_number = request.form.get("phone_number")
    otp = request.form.get("otp")
    resp = auth_contoller_obj.is_otp_valid(phone_number, int(otp))
    if not resp:
        return jsonify({"message": "Invalid OTP"}), 200
    user = auth_contoller_obj.fetch_user(phone_number)
    if user:
        jwt, refresh_token = auth_contoller_obj.login_user(phone_number)
    response = {"user": user.to_dict(), "token": jwt, "refresh_token": refresh_token} if user else {"user": None}
    return jsonify(response), 200

@auth_blueprint.route("/signup", methods=["POST"])
def signup():
    user_name = request.form.get("user_name")
    phone_number = request.form.get("phone_number")
    user = auth_contoller_obj.fetch_user(phone_number)
    if user:
        return jsonify({"message": "User already exists"}), 500
    user = auth_contoller_obj.add_user(user_name, phone_number)
    jwt, refresh_token = auth_contoller_obj.login_user(phone_number, user)
    response = {"user": user.to_dict(), "token": jwt, "refresh_token": refresh_token} if user else {"user": None}
    return jsonify(response), 201

@auth_blueprint.route("/logout", methods=["DELETE"])
def logout():
    auth_contoller_obj.delete_user_session()
    return jsonify({"message": "User Logged out"}), 200

@auth_blueprint.route("/check/login", methods=["GET"])
def check_login():
    token = request.headers.get("Authorization").split(" ")[-1]
    user = auth_contoller_obj.check_login(token)
    response = {"is_user_logged_in": False, "user": None}
    if user : 
        response = {"is_user_logged_in": True, "user": user.to_dict()}
    return jsonify(response), 200

@auth_blueprint.route("/new/token", methods=["POST"])
def new_token():
    user_id = request.form.get("user_id")
    refresh_token = request.form.get("refresh_token")
    token = auth_contoller_obj.generate_new_jwt_token(user_id, refresh_token)
    if token is None:
        jsonify({"message": "Invalid Token"}), 200
    return jsonify({"token": token}), 201
from flask import Blueprint, request
from controllers.auction_registration import AuctionRegistrationController
from core.error_code import ErrorCode, return_error
import json
from flask import jsonify

auction_registration_blueprint = Blueprint('auction_registration', __name__)
auction_registration_contoller_obj = AuctionRegistrationController()

@auction_registration_blueprint.route("/get/registration/details", methods=["GET"])
def get_registration_details():
    auction_id = request.args.get("auction_id")
    user_id = request.args.get("user_id")
    resp = auction_registration_contoller_obj.get_registration_details(auction_id, user_id)
    if isinstance(resp, ErrorCode):
        return return_error(resp)
    return jsonify(resp), 200

@auction_registration_blueprint.route("/register", methods=["POST"])
def register():
    resp = auction_registration_contoller_obj.register(json.loads(request.data))
    if isinstance(resp, ErrorCode):
        return return_error(resp)
    return jsonify(resp), 201

@auction_registration_blueprint.route("/get/all/registration/details", methods=["GET"])
def get_all_registration_details():
    auction_id = request.args.get("auction_id")
    user_id = request.args.get("user_id")
    resp = auction_registration_contoller_obj.get_all_registration_details(auction_id, user_id)
    if isinstance(resp, ErrorCode):
        return return_error(resp)
    return jsonify(resp), 200

@auction_registration_blueprint.route("/change/approval/status", methods=['GET'])
def change_approval_status():
    auction_id = request.args.get("auction_id")
    user_id = request.args.get("user_id")
    seller_id = request.args.get("seller_id")
    approval_status = request.args.get("approval_status")
    resp = auction_registration_contoller_obj.change_approval_status(auction_id, user_id, seller_id, approval_status)
    if isinstance(resp, ErrorCode):
        return return_error(resp)
    return jsonify(resp), 200
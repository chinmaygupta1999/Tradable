from flask import Blueprint, request
from controllers.auction import AuctionController
from core.error_code import ErrorCode, return_error
import json
from flask import jsonify

auction_blueprint = Blueprint('auction', __name__)
auction_contoller_obj = AuctionController()

@auction_blueprint.route("/get/auction/details", methods=["GET"])
def get_auction():
    auction_id = request.args.get("auction_id")
    resp = auction_contoller_obj.get_auction_details(auction_id)
    if isinstance(resp, ErrorCode):
        return return_error(resp)
    return jsonify(resp), 200

@auction_blueprint.route("/create/auction", methods=["POST"])
def create_auction():
    resp = auction_contoller_obj.create_auction(json.loads(request.data))
    return jsonify(resp), 201

@auction_blueprint.route("/edit/auction", methods=["POST"])
def edit_auction():
    resp = auction_contoller_obj.edit_auction(json.loads(request.data))
    return jsonify(resp), 201

@auction_blueprint.route("/get/auction/status", methods=["GET"])
def get_auction_status():
    auction_id = request.args.get("auction_id")
    resp = auction_contoller_obj.get_auction_status(auction_id)
    return jsonify(resp), 200

@auction_blueprint.route("/get/auction/winner", methods=["GET"])
def get_auction_winner():
    auction_id = request.args.get("auction_id")
    resp = auction_contoller_obj.get_auction_winner(auction_id)
    return jsonify(resp), 200

@auction_blueprint.route("/get/user/auction/result", methods=["GET"])
def get_user_auction_result():
    auction_id = request.args.get("auction_id")
    user_id = request.args.get("user_id")
    resp = auction_contoller_obj.get_user_auction_result(user_id, auction_id)
    return jsonify(resp), 200

@auction_blueprint.route("/get/auction/summary", methods=["GET"])
def get_auction_summary():
    auction_id = request.args.get("auction_id")
    seller_id = request.args.get("seller_id")
    resp = auction_contoller_obj.get_auction_summary(seller_id, auction_id)
    return jsonify(resp), 200

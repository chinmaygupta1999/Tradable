from flask import Flask, request
from flask_socketio import SocketIO, emit
from core.db import connect_to_db
from blueprints.auth import auth_blueprint
from blueprints.property import property_blueprint
from blueprints.auction import auction_blueprint
from blueprints.bidder import bidder_blueprint
from blueprints.wishlist import wishlist_blueprint
from blueprints.upload import upload_blueprint
from blueprints.auction_registration import auction_registration_blueprint
from blueprints.account import account_details_blueprint
from blueprints.auction_winner_form import auction_winner_form_blueprint



app = Flask(__name__)
socketio = SocketIO(app, cors_allowed_origins="http://127.0.0.1:3000")


app.register_blueprint(auth_blueprint)
app.register_blueprint(property_blueprint)
app.register_blueprint(auction_blueprint)
app.register_blueprint(bidder_blueprint)
app.register_blueprint(wishlist_blueprint)
app.register_blueprint(upload_blueprint)
app.register_blueprint(auction_registration_blueprint)
app.register_blueprint(account_details_blueprint)
app.register_blueprint(auction_winner_form_blueprint)

@app.after_request
def after_request(response):
    white_origin=[ "http://127.0.0.1:3000"]
    if request.headers.get('Origin') and request.headers['Origin'] in white_origin:
        response.headers['Access-Control-Allow-Origin'] = request.headers['Origin']
    response.headers.add('Access-Control-Allow-Headers', 'Content-Type,Authorization')
    return response

if __name__ == '__main__':
    connect_to_db()
    socketio.run(app, debug=True, port=5000)

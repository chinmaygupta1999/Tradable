from mongoengine import Document, fields
from core.entity import Entity

class Wishlist(Entity, Document):
    user_id = fields.ObjectIdField(required=True)
    property_id = fields.ObjectIdField(required=True)
    meta = {'allow_inheritance': False}
from mongoengine import Document, fields
from core.entity import Entity
from models.price import Price
from enum import Enum

class PaymentTransactionType(Enum):
    NEFT = "NEFT"
    DD = "DD"
    RTGS = "RTGS"
    CHALLAN = "CHALLAN"

class RegistrationStatus(Enum):
    NOT_REGISTERED = "NOT_REGISTERED"
    APPROVAL_PENDING = "APPROVAL_PENDING"
    APPROVED = "APPROVED"
    REJECTED = "REJECTED"

class AuctionRegistration(Entity, Document):
    user_id = fields.ObjectIdField(default=None)
    auction_id = fields.ObjectIdField(required=True)
    transaction_id = fields.StringField(required=True)
    transaction_type = fields.EnumField(PaymentTransactionType, required=True, default=lambda: PaymentTransactionType.NEFT.value)
    payment_proof_url = fields.StringField(required=True)
    address_proof_url = fields.StringField(required=True)
    bidder_details_form_url = fields.StringField(required=True)
    bidder_declaration_form_url = fields.StringField(required=True)
    bidder_training_confirmation_form_url = fields.StringField(required=True)
    price = fields.EmbeddedDocumentField(Price, required=True, default=Price())
    registration_status = fields.EnumField(RegistrationStatus, required=True, default=lambda: RegistrationStatus.APPROVAL_PENDING.value)
    registration_status_message = fields.StringField(default="")
    address = fields.StringField(default="", required=True)
    pan_no = fields.StringField(default="", required=True)
    account_holder_name = fields.StringField(default="", required=True)
    account_no = fields.StringField(default="", required=True)
    ifsc_code = fields.StringField(default="", required=True)
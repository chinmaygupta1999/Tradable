from mongoengine import Document, fields
from core.entity import Entity
from models.price import Price
from enum import Enum

class PaymentTransactionType(Enum):
    NEFT = "NEFT"
    DD = "DD"
    RTGS = "RTGS"
    CHALLAN = "CHALLAN"

class AuctionWinnerForm(Entity, Document):
    user_id = fields.ObjectIdField(default=None)
    auction_id = fields.ObjectIdField(required=True)
    transaction_id = fields.StringField()
    transaction_type = fields.EnumField(PaymentTransactionType, default=lambda: PaymentTransactionType.NEFT.value)
    price_confirmation_url = fields.StringField()
    advance_payment_receipt_url = fields.StringField()
    
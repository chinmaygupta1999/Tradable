from mongoengine import EmbeddedDocument, fields
from enum import Enum

class CurrencyUnit(Enum):
    RUPEE = "RUPEES"
    DOLLAR = "DOLLAR"
    EUROS = "EUROS"

class Price(EmbeddedDocument):
    value = fields.FloatField(required=True, default=0.0)
    currency = fields.EnumField(CurrencyUnit, required=True, default=lambda: CurrencyUnit.RUPEE)
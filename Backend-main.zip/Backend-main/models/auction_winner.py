from mongoengine import Document, fields
from core.entity import Entity
from models.auction_bid import AuctionBid
from models.price import Price
from enum import Enum
from time import sleep

class AuctionWinnerStatus(Enum):
    PROCESSING = "PROCESSING"
    PROCESSED = "PROCESSED"


class AuctionWinner(Entity, Document):
    price = fields.EmbeddedDocumentField(Price, required=True, default=Price())
    user_id = fields.ObjectIdField(default=None)
    auction_id = fields.ObjectIdField(required=True)
    status  = fields.EnumField(AuctionWinnerStatus, required=True, default=lambda: AuctionWinnerStatus.PROCESSED.value)

    @classmethod
    def find_one(cls, **kwargs):
        auction_winner = super().find_one(**kwargs)
        if not auction_winner:
            return None
        while not auction_winner.status == AuctionWinnerStatus.PROCESSED:
            sleep(1)
            auction_winner = super().find_one(**kwargs)
            #TODO : add max wait time limit
        return auction_winner

    def insert(self):
        auction_bid = AuctionBid(auction_id=self.auction_id, price=self.price, user_id=self.user_id)
        auction_bid.insert()
        return super().insert()
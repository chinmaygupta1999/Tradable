from mongoengine import Document, fields, EmbeddedDocument
from core.entity import Entity
from models.price import Price
from enum import Enum

    
class AuctionType(Enum):
    ENGLISH_AUCTION = "ENGLISH_AUCTION"
    SEAL_BID_AUCTION = "SEAL_BID_AUCTION"
    DUTCH_AUCTION = "DUTCH_AUCTION"
    
class AuctionConfig(EmbeddedDocument):
    start_time = fields.FloatField(required=True, default=0.0)
    end_time = fields.FloatField(required=True, default=0.0)
    type = fields.EnumField(AuctionType, required=True, default=lambda: AuctionType.ENGLISH_AUCTION)
    price = fields.EmbeddedDocumentField(Price, required=True, default=Price())
    min_bid_increment = fields.EmbeddedDocumentField(Price, required=True, default=Price())
    emd = fields.EmbeddedDocumentField(Price, required=True, default=Price())
    extend_auction_after = fields.IntField(required=True, default=0)
    extend_auction_by = fields.IntField(required=True, default=0)
    bank_account_number = fields.StringField(required=True, default="")
    beneficiary_name = fields.StringField(required=True, default="")
    ifsc_code = fields.StringField(required=True, default="")
    seller_name = fields.StringField(required=True, default="")
    seller_mobile_no = fields.StringField(required=True, default="")
    seller_email = fields.StringField(required=True, default="")



class AuctionWinner(EmbeddedDocument):
    price = fields.EmbeddedDocumentField(Price, required=True, default=Price())
    user_id = fields.ObjectIdField(required=True)

class Auction(Entity, Document):
    title = fields.StringField(required=True, default="")
    description = fields.StringField(required=True, default="")
    config = fields.EmbeddedDocumentField(AuctionConfig, required=True, default=AuctionConfig())
    created_by = fields.ObjectIdField(required=True)
    property_id = fields.ObjectIdField(required=True)
    

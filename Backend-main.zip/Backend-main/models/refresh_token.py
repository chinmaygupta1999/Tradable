from mongoengine import Document, fields
from core.entity import Entity

class RefreshToken(Document, Entity):
    user_id = fields.ObjectIdField(required=True)
    token = fields.StringField(required=True)
    refresh_token = fields.StringField(required=True)
    meta = {'allow_inheritance': False}
from mongoengine import Document, fields
from core.entity import Entity

class OtpInfo(Entity, Document):
    _id = fields.StringField(required=True)
    otp = fields.IntField(required=True)
    meta = {'allow_inheritance': False}
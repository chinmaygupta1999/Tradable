from mongoengine import Document, fields, EmbeddedDocument
from core.entity import Entity
from models.price import Price
from enum import Enum
from bson import ObjectId

class City(Enum):
    BANGALORE = "BANGALORE"
    HYDERABAD = "HYDERABAD"
    MUMBAI = "MUMBAI"
    GURUGRAM = "GURUGRAM"
    LUCKNOW = "LUCKNOW"

class ListingType(Enum):
    AUCTION = "AUCTION"
    FIXED_PRICE = "FIXED_PRICE"

class DistanceUnit(Enum):
    KM = "KM"
    MILES = "MILES"
    METERS = "METERS"

class Amenity(EmbeddedDocument):
    name = fields.StringField(required=True, default="")
    distance_from_property = fields.FloatField(required=True, default=0.0)
    distance_unit: fields.EnumField(DistanceUnit, required=True, default=lambda: DistanceUnit.KM)

class Property(Entity, Document):
    name = fields.StringField(required=True, default=lambda: "")
    description = fields.StringField(required=True, default=lambda: "")
    city = fields.EnumField(City, required=True, default=lambda: City.BANGALORE)
    address = fields.StringField(required=True, default=lambda: "")
    listing_type = fields.EnumField(ListingType, required=True, default=lambda: ListingType.FIXED_PRICE.value)
    details = fields.DictField(required=True, default=lambda: {})
    amenties = fields.ListField(fields.EmbeddedDocumentField(Amenity, required=True, default=lambda: Amenity()))
    location = fields.GeoPointField(required=True, default=lambda: [0.0, 0.0]) #[-122.419416, 37.774930]
    property_outline = fields.ListField(fields.GeoPointField(required=True, default=lambda: [0.0, 0.0]))
    property_images = fields.DictField(required=True, default=lambda: {})
    related_document_urls = fields.DictField(required=True, default=lambda: {})
    owner_id = fields.ObjectIdField(required=True, default=lambda: ObjectId())
    is_verified = fields.BooleanField(required=True, default=False)
    meta = {'allow_inheritance': False}
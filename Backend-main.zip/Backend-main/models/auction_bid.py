from mongoengine import Document, fields
from models.price import Price
from core.entity import Entity
from bson import ObjectId

class AuctionBid(Entity, Document):
   auction_id = fields.ObjectIdField(default=lambda: ObjectId(), required=True)
   user_id = fields.ObjectIdField(default=lambda: ObjectId(), required=True)
   price = fields.EmbeddedDocumentField(Price, required=True, default=Price())

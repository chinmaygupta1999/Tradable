from dataclasses import dataclass
from mongoengine import Document, fields
from core.entity import Entity
from enum import Enum

class AttachmentType(Enum):
    NONE = "NONE"
    JPEG = "JPEG"
    PNG = "PNG"
    GIF = "GIF"
    SVG = "SVG"
    WEBP = "WEBP"
    JPG = "JPG"
    PDF = "PDF"

@dataclass
class Attachment(Entity, Document):
    type : fields.EnumField(required=True, default=lambda: AttachmentType.NONE.value)
    path: fields.StringField(required=True)
    meta = {'allow_inheritance': False}
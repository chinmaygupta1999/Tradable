from mongoengine import Document, fields
from core.entity import Entity

class User(Entity, Document):
    user_name = fields.StringField(required=True)
    phone_number = fields.StringField(required=True)
    image_url = fields.StringField(default=None)
    address = fields.StringField(default=None)
    aadhar_no = fields.StringField(default=None)
    pan_no = fields.StringField(default=None)
    account_no = fields.StringField(default=None)
    ifsc_code = fields.StringField(default=None)
    email_id = fields.StringField(default=None)
    meta = {'allow_inheritance': False}